-- BLOCKSIEGE: polished, always-visible 3D weapon preview for Build and Battle.
-- A ViewportFrame owns its camera and WorldModel: world camera settings, fog and character
-- transparency cannot accidentally hide the local weapon presentation.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local player = Players.LocalPlayer
local Shared = ReplicatedStorage:WaitForChild("BlockSiege")
local Catalog = require(Shared:WaitForChild("Catalog"))
local WeaponModels = require(Shared:WaitForChild("WeaponModels"))
local state = Shared:WaitForChild("MatchState")

local C = {
	Background = Color3.fromRGB(17, 24, 32),
	Panel = Color3.fromRGB(28, 39, 49),
	Text = Color3.fromRGB(244, 246, 239),
	Muted = Color3.fromRGB(164, 184, 193),
	Gold = Color3.fromRGB(255, 199, 76),
	Cyan = Color3.fromRGB(100, 224, 255),
	Build = Color3.fromRGB(112, 219, 176),
	Battle = Color3.fromRGB(255, 142, 87),
}

local function new(className, properties, parent)
	local object = Instance.new(className)
	for key, value in pairs(properties or {}) do
		object[key] = value
	end
	object.Parent = parent
	return object
end

local function corner(object, radius)
	return new("UICorner", { CornerRadius = UDim.new(0, radius or 7) }, object)
end

local function label(parent, name, value, size, position, textSize, color)
	return new("TextLabel", {
		Name = name,
		BackgroundTransparency = 1,
		Size = size,
		Position = position or UDim2.new(),
		Font = Enum.Font.GothamBold,
		Text = value,
		TextColor3 = color or C.Text,
		TextSize = textSize or 16,
		TextWrapped = true,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextYAlignment = Enum.TextYAlignment.Center,
	}, parent)
end

local gui = new("ScreenGui", {
	Name = "BlockSiegeWeaponPreview",
	ResetOnSpawn = false,
	IgnoreGuiInset = false,
	DisplayOrder = 3,
	ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
}, player:WaitForChild("PlayerGui"))

local panel = new("Frame", {
	Name = "WeaponPreviewPanel",
	AnchorPoint = Vector2.new(1, 0.5),
	Position = UDim2.new(1, -18, 0.5, 12),
	Size = UDim2.new(0.27, 0, 0, 246),
	BackgroundColor3 = C.Background,
	BackgroundTransparency = 0.03,
	BorderSizePixel = 0,
	ClipsDescendants = true,
	Visible = false,
}, gui)
corner(panel, 9)
local panelStroke = new("UIStroke", {
	Name = "RarityBorder",
	Color = C.Cyan,
	Thickness = 1.5,
	Transparency = 0.12,
}, panel)
new("UIGradient", {
	Rotation = 115,
	Color = ColorSequence.new(Color3.fromRGB(42, 61, 72), C.Background),
}, panel)
new("UISizeConstraint", {
	MinSize = Vector2.new(218, 196),
	MaxSize = Vector2.new(350, 270),
}, panel)

label(panel, "PreviewHeader", "ARSENAL // 3D LOADOUT", UDim2.new(1, -104, 0, 22), UDim2.new(0, 13, 0, 8), 12, C.Muted)
local phaseLabel = label(panel, "PreviewPhase", "BUILD", UDim2.new(0, 78, 0, 22), UDim2.new(1, -91, 0, 8), 11, C.Build)
phaseLabel.TextXAlignment = Enum.TextXAlignment.Right
local accentBar = new("Frame", {
	Name = "AccentBar",
	Position = UDim2.new(0, 12, 0, 33),
	Size = UDim2.new(1, -24, 0, 2),
	BackgroundColor3 = C.Cyan,
	BorderSizePixel = 0,
}, panel)

local viewport = new("ViewportFrame", {
	Name = "WeaponViewport",
	Position = UDim2.new(0, 10, 0, 42),
	Size = UDim2.new(1, -20, 1, -104),
	BackgroundColor3 = Color3.fromRGB(12, 20, 29),
	BackgroundTransparency = 0.08,
	BorderSizePixel = 0,
	ClipsDescendants = true,
	Ambient = Color3.fromRGB(105, 119, 133),
	LightColor = Color3.fromRGB(255, 242, 218),
	LightDirection = Vector3.new(-0.65, -1, -0.8),
	ImageTransparency = 0,
}, panel)
corner(viewport, 6)
new("UIStroke", { Color = Color3.fromRGB(65, 91, 105), Thickness = 1, Transparency = 0.15 }, viewport)

local worldModel = new("WorldModel", { Name = "WeaponWorld" }, viewport)
local previewCamera = new("Camera", {
	Name = "WeaponPreviewCamera",
	CameraType = Enum.CameraType.Scriptable,
	FieldOfView = 38,
}, viewport)
viewport.CurrentCamera = previewCamera

local weaponName = label(panel, "WeaponName", "", UDim2.new(1, -28, 0, 27), UDim2.new(0, 14, 1, -62), 17, C.Text)
weaponName.Font = Enum.Font.GothamBlack
local rarityLabel = label(panel, "WeaponRarity", "", UDim2.new(0.56, -14, 0, 22), UDim2.new(0, 14, 1, -34), 11, C.Cyan)
local skinLabel = label(panel, "WeaponSkin", "", UDim2.new(0.44, -14, 0, 22), UDim2.new(0.56, 0, 1, -34), 10, C.Gold)
skinLabel.TextXAlignment = Enum.TextXAlignment.Right

local viewModel
local viewKey
local modelCenter = Vector3.zero
local modelDistance = 16
local modelReady = false
local lastPhase

local function clearViewmodel()
	if viewModel then
		viewModel:Destroy()
	end
	viewModel = nil
	viewKey = nil
	modelReady = false
	modelCenter = Vector3.zero
end

local function prepareParts(model)
	for _, part in ipairs(model:GetDescendants()) do
		if part:IsA("BasePart") then
			part.Anchored = true
			part.CanCollide = false
			part.CanTouch = false
			part.CanQuery = false
			part.CastShadow = false
			part.Transparency = 0
			part.LocalTransparencyModifier = 0
		end
	end
end

local function frameModel(model)
	-- Normalize only the local preview; server-side weapon scale and hit detection are untouched.
	model:PivotTo(CFrame.new())
	local _, initialSize = model:GetBoundingBox()
	local initialLargest = math.max(initialSize.X, initialSize.Y, initialSize.Z)
	if initialLargest > 0.01 and type(model.ScaleTo) == "function" then
		model:ScaleTo(8 / initialLargest)
	end
	model:PivotTo(CFrame.new())
	local bounds, size = model:GetBoundingBox()
	modelCenter = bounds.Position
	local largest = math.max(size.X, size.Y, size.Z, 1)
	local halfFov = math.rad(previewCamera.FieldOfView * 0.5)
	modelDistance = math.max(9, largest * 0.78 / math.tan(halfFov))
	previewCamera.Focus = CFrame.new()
	previewCamera.CFrame = CFrame.lookAt(Vector3.new(0, 1.7, modelDistance), Vector3.zero)
	modelReady = true
end

local function ensureViewmodel()
	local weaponId = player:GetAttribute("SelectedWeapon") or "Carbine"
	local weapon = Catalog.GetWeapon(weaponId) or Catalog.Weapons.Carbine
	local skin = player:GetAttribute("Cosmetic_WeaponSkin") or "Default"
	local key = weapon.Id .. ":" .. tostring(skin)
	if viewModel and viewKey == key and modelReady then
		return
	end
	clearViewmodel()

	local model = WeaponModels.Build(weapon.Id)
	model.Name = "LocalWeaponViewModel"
	model:SetAttribute("Viewmodel", true)
	model:SetAttribute("PreviewWeaponId", weapon.Id)
	WeaponModels.ApplySkin(model, skin)
	prepareParts(model)
	model.Parent = worldModel
	viewModel = model
	viewKey = key
	frameModel(model)
end

local function refreshLabels(phase)
	local weapon = Catalog.GetWeapon(player:GetAttribute("SelectedWeapon") or "Carbine") or Catalog.Weapons.Carbine
	local skin = player:GetAttribute("Cosmetic_WeaponSkin") or "Default"
	local rarityColor = Catalog.RarityColors[weapon.Rarity] or C.Cyan
	weaponName.Text = weapon.Name
	rarityLabel.Text = Catalog.RarityNames[weapon.Rarity] or string.upper(weapon.Rarity)
	rarityLabel.TextColor3 = rarityColor
	skinLabel.Text = skin == "GoldenArsenal" and "GOLDEN ARSENAL" or "STANDARD ISSUE"
	skinLabel.TextColor3 = skin == "GoldenArsenal" and C.Gold or C.Muted
	phaseLabel.Text = phase == "Build" and "BUILD" or "BATTLE"
	phaseLabel.TextColor3 = phase == "Build" and C.Build or C.Battle
	panelStroke.Color = rarityColor
	accentBar.BackgroundColor3 = rarityColor
end

local function updateLayout()
	-- Keep the card clear of the centered build controls and the touch fire button.
	local camera = Workspace.CurrentCamera
	local screen = camera and camera.ViewportSize or Vector2.new(1280, 720)
	if screen.X < 760 or screen.Y < 520 then
		panel.Size = UDim2.fromOffset(218, 196)
		panel.Position = UDim2.new(1, -10, 0.5, -14)
	else
		panel.Size = UDim2.new(0.27, 0, 0, 246)
		panel.Position = UDim2.new(1, -18, 0.5, 12)
	end
end

RunService.RenderStepped:Connect(function()
	local phase = state:GetAttribute("Phase") or "Lobby"
	local visible = phase == "Build" or phase == "Battle"
	panel.Visible = visible
	if not visible then
		if viewModel then
			clearViewmodel()
		end
		lastPhase = phase
		return
	end

	-- Do not gate this UI on a character or Workspace.CurrentCamera. During respawn the
	-- loadout must remain visible, and the viewport has its own scriptable camera.
	ensureViewmodel()
	refreshLabels(phase)
	if phase ~= lastPhase then
		updateLayout()
		lastPhase = phase
	end
	if not viewModel or not modelReady then
		return
	end

	local clock = os.clock()
	local yaw = 78 + math.sin(clock * 0.65) * 9
	local pitch = -7 + math.sin(clock * 0.9) * 2
	local roll = -3 + math.cos(clock * 0.55) * 1.5
	local rotation = CFrame.Angles(math.rad(pitch), math.rad(yaw), math.rad(roll))
	viewModel:PivotTo(rotation * CFrame.new(-modelCenter))
	previewCamera.CFrame = CFrame.lookAt(Vector3.new(0, 1.7 + math.sin(clock * 0.8) * 0.12, modelDistance), Vector3.zero)
end)

player:GetAttributeChangedSignal("SelectedWeapon"):Connect(clearViewmodel)
player:GetAttributeChangedSignal("Cosmetic_WeaponSkin"):Connect(clearViewmodel)
updateLayout()
