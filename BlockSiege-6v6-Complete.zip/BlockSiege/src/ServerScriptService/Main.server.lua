-- BLOCKSIEGE server entry point.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Shared = ReplicatedStorage:WaitForChild("BlockSiege")
local services = script.Parent:WaitForChild("Services")
local WorldBuilder = require(services:WaitForChild("WorldBuilder"))
local DataService = require(services:WaitForChild("DataService"))
local FortressService = require(services:WaitForChild("FortressService"))
local WeaponService = require(services:WaitForChild("WeaponService"))
local BotService = require(services:WaitForChild("BotService"))
local CaseService = require(services:WaitForChild("CaseService"))
local MatchService = require(services:WaitForChild("MatchService"))

local remotes = Instance.new("Folder")
remotes.Name = "Remotes"
for _, name in ipairs({
	"Notify", "ProfileUpdate", "CaseOpened", "Results", "CombatFX", "BuildFX",
	"LobbyAction", "CaseAction", "FireRequest", "BuildRequest", "OpenPanel",
}) do
	local remote = Instance.new("RemoteEvent")
	remote.Name = name
	remote.Parent = remotes
end
remotes.Parent = Shared

local state = Instance.new("Folder")
state.Name = "MatchState"
state.Parent = Shared

local world = WorldBuilder.Build()
DataService.Init({ Remotes = remotes })
FortressService.Init({ World = world, Remotes = remotes, State = state })
WeaponService.Init({ DataService = DataService, FortressService = FortressService, Remotes = remotes })
BotService.Init({ World = world, FortressService = FortressService, WeaponService = WeaponService })
CaseService.Init({ DataService = DataService, Remotes = remotes })
MatchService.Init({
	World = world,
	DataService = DataService,
	FortressService = FortressService,
	WeaponService = WeaponService,
	BotService = BotService,
	Remotes = remotes,
	State = state,
})
CaseService.SetEquipHandler(WeaponService.EquipPlayer)

local function onPlayerAdded(player)
	MatchService.OnPlayerAdded(player)
	task.spawn(function()
		DataService.Load(player)
		if player.Parent then
			MatchService.OnProfileLoaded(player)
		end
	end)
end

Players.PlayerAdded:Connect(onPlayerAdded)
Players.PlayerRemoving:Connect(function(player)
	MatchService.OnPlayerRemoving(player)
	DataService.SaveAndClear(player)
end)

remotes.LobbyAction.OnServerEvent:Connect(function(player, action)
	MatchService.HandleLobbyAction(player, action)
end)
remotes.CaseAction.OnServerEvent:Connect(function(player, action, value)
	CaseService.HandleAction(player, action, value)
end)
remotes.FireRequest.OnServerEvent:Connect(function(player, targetPosition)
	WeaponService.FirePlayer(player, targetPosition)
end)
remotes.BuildRequest.OnServerEvent:Connect(function(player, kind, position)
	MatchService.HandleBuild(player, kind, position)
end)
world.LootPrompt.Triggered:Connect(function(player)
	remotes.OpenPanel:FireClient(player, "Cases")
end)
world.StartPrompt.Triggered:Connect(function(player)
	MatchService.HandleLobbyAction(player, "QuickStart")
end)

local accumulator = 0
RunService.Heartbeat:Connect(function(deltaTime)
	accumulator = accumulator + math.min(deltaTime, 0.15)
	while accumulator >= 1 / 20 do
		MatchService.Step(1 / 20)
		BotService.Step(1 / 20)
		DataService.Step(1 / 20)
		accumulator = accumulator - 1 / 20
	end
end)

for _, player in ipairs(Players:GetPlayers()) do
	onPlayerAdded(player)
end

print("[BLOCKSIEGE] 6x6 готов · строительство, боты и разрушаемые крепости")
