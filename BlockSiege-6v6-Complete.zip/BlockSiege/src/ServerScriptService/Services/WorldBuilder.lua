-- Симметричная voxel-арена и свободное лобби с витриной оружия и лутбоксом.
local Lighting = game:GetService("Lighting")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("BlockSiege")
local Config = require(Shared:WaitForChild("Config"))
local Catalog = require(Shared:WaitForChild("Catalog"))
local WeaponModels = require(Shared:WaitForChild("WeaponModels"))

local WorldBuilder = {}
local C = {
	Grass = Color3.fromRGB(91, 145, 73),
	Dirt = Color3.fromRGB(114, 79, 48),
	Stone = Color3.fromRGB(107, 118, 112),
	StoneDark = Color3.fromRGB(63, 73, 70),
	Wood = Color3.fromRGB(159, 111, 57),
	Leaf = Color3.fromRGB(63, 119, 61),
	Sand = Color3.fromRGB(190, 170, 111),
	White = Color3.fromRGB(239, 240, 215),
	Gold = Color3.fromRGB(239, 179, 52),
}

local function makePart(parent, name, size, cframe, color, material, collide, className)
	local part = Instance.new(className or "Part")
	part.Name = name
	part.Size = size
	part.CFrame = cframe
	part.Color = color
	part.Material = material or Enum.Material.SmoothPlastic
	part.Anchored = true
	part.CanCollide = collide ~= false
	part.CanTouch = false
	part.CanQuery = true
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	part.Parent = parent
	return part
end

local function billboard(parent, text, color, offset, size)
	local gui = Instance.new("BillboardGui")
	gui.Name = "WorldLabel"
	gui.Size = UDim2.fromOffset(260, 58)
	gui.StudsOffset = offset or Vector3.new(0, 5, 0)
	gui.AlwaysOnTop = true
	gui.MaxDistance = 180
	gui.Parent = parent
	local label = Instance.new("TextLabel")
	label.Size = size or UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.Font = Enum.Font.Code
	label.Text = text
	label.TextColor3 = color
	label.TextStrokeTransparency = 0.35
	label.TextScaled = true
	label.Parent = gui
	return gui
end

local function prompt(parent, action, object)
	local proximity = Instance.new("ProximityPrompt")
	proximity.ActionText = action
	proximity.ObjectText = object
	proximity.HoldDuration = 0.25
	proximity.MaxActivationDistance = 14
	proximity.RequiresLineOfSight = false
	proximity.Parent = parent
	return proximity
end

local function buildTree(parent, position, scale)
	local model = Instance.new("Model")
	model.Name = "VoxelTree"
	model.Parent = parent
	makePart(model, "Trunk", Vector3.new(2.4, 9, 2.4) * scale, CFrame.new(position + Vector3.new(0, 4.5 * scale, 0)), C.Wood, Enum.Material.WoodPlanks, true)
	for _, offset in ipairs({ Vector3.new(0, 10, 0), Vector3.new(2.5, 8.5, 0), Vector3.new(-2.5, 8.5, 0), Vector3.new(0, 8.5, 2.5), Vector3.new(0, 8.5, -2.5) }) do
		makePart(model, "Leaves", Vector3.new(5, 5, 5) * scale, CFrame.new(position + offset * scale), C.Leaf, Enum.Material.Grass, true)
	end
	return model
end

local function buildBase(arena, structures, team)
	local color = Config.Teams[team].Color
	local base = Config.BasePosition(team)
	local baseCFrame = Config.BaseCFrame(team)
	local platform = makePart(arena, team .. "BasePlatform", Vector3.new(100, 4, 116), CFrame.new(base.X, 2, 0), C.Stone, Enum.Material.Cobblestone, true)
	platform:SetAttribute("Team", team)
	makePart(arena, team .. "BaseGrass", Vector3.new(94, 0.5, 110), CFrame.new(base.X, 4.15, 0), C.Grass, Enum.Material.Grass, true)
	for _, side in ipairs({ -1, 1 }) do
		for _, forward in ipairs({ -42, 42 }) do
			local position = (baseCFrame * CFrame.new(side * 44, 5, forward)).Position
			makePart(arena, team .. "CornerTower", Vector3.new(8, 10, 8), CFrame.new(position), C.StoneDark, Enum.Material.Cobblestone, true)
			makePart(arena, team .. "CornerBanner", Vector3.new(8.5, 1.2, 8.5), CFrame.new(position + Vector3.new(0, 5.5, 0)), color, Enum.Material.Fabric, true)
		end
	end
	local marker = makePart(arena, team .. "BaseMarker", Vector3.new(1, 1, 1), CFrame.new(base + Vector3.new(0, 25, 0)), color, Enum.Material.SmoothPlastic, false)
	marker.Transparency = 1
	marker.CanQuery = false
	billboard(marker, Config.Teams[team].Name .. " // КРЕПОСТЬ", color, Vector3.zero, UDim2.fromScale(1, 1))
	local spawnCFrame = baseCFrame * CFrame.new(0, 4, 34)
	local spawn = makePart(arena, team .. "Spawn", Vector3.new(12, 1, 12), spawnCFrame, color, Enum.Material.Neon, false, "SpawnLocation")
	spawn.Neutral = true
	spawn.CanQuery = false
	return spawnCFrame + Vector3.new(0, 3, 0)
end

local function buildLobby(lobby)
	makePart(lobby, "LobbyStone", Vector3.new(170, 8, 130), CFrame.new(0, 36, 330), C.StoneDark, Enum.Material.Cobblestone, true)
	makePart(lobby, "LobbyDirt", Vector3.new(166, 5, 126), CFrame.new(0, 41, 330), C.Dirt, Enum.Material.Ground, true)
	makePart(lobby, "LobbyGrass", Vector3.new(164, 1, 124), CFrame.new(0, 44, 330), C.Grass, Enum.Material.Grass, true)
	local spawnCFrame = CFrame.lookAt(Vector3.new(0, 48, 365), Vector3.new(0, 48, 330))
	local spawn = makePart(lobby, "LobbySpawn", Vector3.new(12, 1, 12), spawnCFrame, C.White, Enum.Material.Neon, false, "SpawnLocation")
	spawn.Neutral = true
	spawn.CanQuery = false

	local crate = makePart(lobby, "LobbyLootbox", Vector3.new(9, 7, 9), CFrame.new(0, 48, 318), C.Gold, Enum.Material.Metal, true)
	makePart(lobby, "LootboxBand", Vector3.new(9.5, 1.2, 9.5), CFrame.new(0, 49, 318), C.StoneDark, Enum.Material.Metal, true)
	billboard(crate, "GEAR // ЛУТБОКС", C.Gold)
	local lootPrompt = prompt(crate, "ОТКРЫТЬ", "Игровые кейсы · шансы 65 / 30 / 5")

	local board = makePart(lobby, "StartBoard", Vector3.new(18, 12, 1.5), CFrame.new(-30, 51, 318), C.StoneDark, Enum.Material.WoodPlanks, true)
	billboard(board, "BLOCK // БОЙ 6×6", C.White, Vector3.new(0, 0, 0))
	local startPrompt = prompt(board, "В БОЙ", "Быстрый старт · боты заполняют команды")

	for index, weaponId in ipairs(Catalog.WeaponOrder) do
		local x = -63 + (index - 1) * 21
		makePart(lobby, "WeaponPedestal", Vector3.new(10, 3, 10), CFrame.new(x, 46, 292), C.Stone, Enum.Material.Cobblestone, true)
		local weapon = WeaponModels.Build(weaponId)
		weapon.Name = "Display_" .. weaponId
		weapon.Parent = lobby
		weapon:PivotTo(CFrame.new(x, 50, 292) * CFrame.Angles(0, math.rad(90), 0))
		for _, item in ipairs(weapon:GetDescendants()) do
			if item:IsA("BasePart") then
				item.Anchored = true
			end
		end
		local labelAnchor = makePart(lobby, "WeaponLabelAnchor", Vector3.new(1, 1, 1), CFrame.new(x, 52, 292), C.White, Enum.Material.SmoothPlastic, false)
		labelAnchor.Transparency = 1
		labelAnchor.CanQuery = false
		local definition = Catalog.GetWeapon(weaponId)
		billboard(labelAnchor, definition.Name, Catalog.RarityColors[definition.Rarity], Vector3.zero)
	end

	for _, position in ipairs({ Vector3.new(-70, 44.5, 370), Vector3.new(70, 44.5, 370), Vector3.new(-70, 44.5, 280), Vector3.new(70, 44.5, 280) }) do
		buildTree(lobby, position, 0.8)
	end
	return spawnCFrame, lootPrompt, startPrompt
end

function WorldBuilder.Build()
	local old = Workspace:FindFirstChild("BlockSiegeWorld")
	if old then
		old:Destroy()
	end
	local root = Instance.new("Folder")
	root.Name = "BlockSiegeWorld"
	root.Parent = Workspace
	local arena = Instance.new("Folder")
	arena.Name = "Arena"
	arena.Parent = root
	local structures = Instance.new("Folder")
	structures.Name = "Structures"
	structures.Parent = root
	local bots = Instance.new("Folder")
	bots.Name = "Bots"
	bots.Parent = root
	local lobby = Instance.new("Folder")
	lobby.Name = "Lobby"
	lobby.Parent = root

	makePart(arena, "ArenaDirt", Vector3.new(420, 8, 190), CFrame.new(0, -6, 0), C.Dirt, Enum.Material.Ground, true)
	makePart(arena, "ArenaGrass", Vector3.new(420, 2, 190), CFrame.new(0, -1, 0), C.Grass, Enum.Material.Grass, true)
	makePart(arena, "CenterLane", Vector3.new(210, 0.35, 18), CFrame.new(0, 0.15, 0), C.Sand, Enum.Material.Ground, true)
	for _, z in ipairs({ -62, 62 }) do
		makePart(arena, "SideLane", Vector3.new(230, 0.3, 10), CFrame.new(0, 0.12, z), C.Sand, Enum.Material.Ground, true)
	end

	local teamSpawns = {}
	for _, team in ipairs(Config.TeamOrder) do
		teamSpawns[team] = buildBase(arena, structures, team)
	end

	for _, position in ipairs({
		Vector3.new(-70, 0, -72), Vector3.new(-35, 0, 73), Vector3.new(35, 0, -73), Vector3.new(70, 0, 72),
		Vector3.new(-10, 0, -78), Vector3.new(10, 0, 78), Vector3.new(-90, 0, 62), Vector3.new(90, 0, -62),
	}) do
		buildTree(arena, position, 0.85)
	end
	for _, entry in ipairs({
		{ Vector3.new(-45, 3, -35), Vector3.new(12, 6, 8) },
		{ Vector3.new(45, 3, 35), Vector3.new(12, 6, 8) },
		{ Vector3.new(-45, 3, 35), Vector3.new(12, 6, 8) },
		{ Vector3.new(45, 3, -35), Vector3.new(12, 6, 8) },
	}) do
		makePart(arena, "StoneCover", entry[2], CFrame.new(entry[1]), C.Stone, Enum.Material.Cobblestone, true)
	end

	local lobbySpawn, lootPrompt, startPrompt = buildLobby(lobby)
	Lighting.Brightness = 2
	Lighting.ClockTime = 14.5
	Lighting.EnvironmentDiffuseScale = 0.35
	Lighting.EnvironmentSpecularScale = 0.25
	if not Lighting:FindFirstChild("BlockSiegeAtmosphere") then
		local atmosphere = Instance.new("Atmosphere")
		atmosphere.Name = "BlockSiegeAtmosphere"
		atmosphere.Density = 0.28
		atmosphere.Haze = 0.7
		atmosphere.Parent = Lighting
	end

	return {
		Root = root,
		Arena = arena,
		Structures = structures,
		Bots = bots,
		Lobby = lobby,
		LobbySpawn = lobbySpawn,
		TeamSpawns = teamSpawns,
		LootPrompt = lootPrompt,
		StartPrompt = startPrompt,
	}
end

return WorldBuilder
