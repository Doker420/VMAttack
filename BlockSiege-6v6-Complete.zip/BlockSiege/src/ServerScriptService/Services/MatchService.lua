-- Очередь, команды 6x6, фазы Build/Battle/Results и возврат в лобби.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("BlockSiege")
local Config = require(Shared:WaitForChild("Config"))
local Catalog = require(Shared:WaitForChild("Catalog"))

local MatchService = {}
local world
local dataService
local fortressService
local weaponService
local botService
local progressionService
local captureService
local abilityService
local neutralService
local bonusService
local expeditionService
local remotes
local state
local phase = "Lobby"
local timer = 0
local intermission
local queued = {}
local participants = {}
local pendingSpawns = {}
local matchId = 0
local lastSecond = -1
local matchStats = {}
local regenClock = 0
local rewardMultiplierProvider = function() return 1 end

local function notify(player, text)
	if player and player.Parent then
		remotes.Notify:FireClient(player, text)
	end
end

local function queueCount()
	local count = 0
	for userId in pairs(queued) do
		if Players:GetPlayerByUserId(userId) then
			count = count + 1
		else
			queued[userId] = nil
		end
	end
	return count
end

local function participantCount()
	local count = 0
	for userId in pairs(participants) do
		if Players:GetPlayerByUserId(userId) then
			count = count + 1
		end
	end
	return count
end

local function updateCounts()
	local humans = { Blue = 0, Orange = 0 }
	for _, player in ipairs(Players:GetPlayers()) do
		local team = participants[player.UserId]
		if team then
			humans[team] = humans[team] + 1
		end
	end
	for _, team in ipairs(Config.TeamOrder) do
		state:SetAttribute(team .. "Humans", humans[team])
		state:SetAttribute(team .. "Bots", botService and botService.Count(team) or 0)
	end
	state:SetAttribute("QueueCount", queueCount())
end

local function updateClock(force)
	local second = math.max(0, math.ceil(timer))
	if force or second ~= lastSecond then
		lastSecond = second
		state:SetAttribute("Time", second)
	end
end

local function updateTacticalLights()
	local enabled = phase ~= "Build"
	for _, player in ipairs(Players:GetPlayers()) do
		local character = player.Character
		local root = character and character:FindFirstChild("HumanoidRootPart")
		local light = root and root:FindFirstChild("BlockSiegeTacticalLight")
		if light then
			light.Enabled = enabled
		end
	end
	if world and world.Bots then
		for _, model in ipairs(world.Bots:GetChildren()) do
			local root = model:FindFirstChild("HumanoidRootPart")
			local light = root and root:FindFirstChild("BlockSiegeTacticalLight")
			if light then
				light.Enabled = enabled
			end
		end
	end
end

local function setPhase(nextPhase, duration)
	phase = nextPhase
	timer = duration or 0
	state:SetAttribute("Phase", phase)
	updateClock(true)
	updateCounts()
	updateTacticalLights()
end

local function spawnPlayer(player, cframe)
	if player and player.Parent then
		pendingSpawns[player.UserId] = cframe
		player:LoadCharacter()
	end
end

local function teamSpawn(team)
	return world.TeamSpawns[team]
end

local function playerLevel(player)
	local data = dataService and dataService.Get(player)
	return data and Catalog.LevelForXP(data.XP) or tonumber(player:GetAttribute("Level")) or 1
end

local function statsFor(player)
	local stats = matchStats[player.UserId]
	if not stats then
		stats = { Builds = 0, Kills = 0, Structures = 0, Captures = 0, Coins = 0, XP = 0, LevelCoins = 0, Unlocks = {} }
		matchStats[player.UserId] = stats
	end
	return stats
end

local function publishStat(player, name, value)
	player:SetAttribute("Match" .. name, value)
end

local function recordProgress(player, progress)
	if not progress then
		return
	end
	local stats = statsFor(player)
	stats.LevelCoins = stats.LevelCoins + (progress.LevelCoins or 0)
	for _, unlock in ipairs(progress.Unlocks or {}) do
		table.insert(stats.Unlocks, unlock)
	end
end

local function currentRewardMultiplier()
	return math.clamp(tonumber(rewardMultiplierProvider()) or 1, 1, 2)
end

local function actionReward(player, coins, xp, reason)
	local multiplier = currentRewardMultiplier()
	local awardedCoins = math.floor((tonumber(coins) or 0) * multiplier + 0.5)
	local awardedXP = math.floor((tonumber(xp) or 0) * multiplier + 0.5)
	if multiplier > 1 then
		reason = tostring(reason or "Полезное действие") .. " · ×2 ИВЕНТ"
	end
	local stats = statsFor(player)
	stats.Coins = stats.Coins + awardedCoins
	stats.XP = stats.XP + awardedXP
	local progress = dataService.Award(player, awardedCoins, awardedXP, reason)
	recordProgress(player, progress)
	return progress
end

function MatchService.GetPhase()
	return phase
end

function MatchService.GetTeam(player)
	return participants[player.UserId]
end

function MatchService.IsParticipant(player)
	return participants[player.UserId] ~= nil
end

function MatchService.GetTargets(team)
	local enemy = Config.OtherTeam(team)
	local result = botService.GetModels(enemy)
	for _, player in ipairs(Players:GetPlayers()) do
		if participants[player.UserId] == enemy then
			local character = player.Character
			local humanoid = character and character:FindFirstChildOfClass("Humanoid")
			local root = character and character:FindFirstChild("HumanoidRootPart")
			if character and humanoid and humanoid.Health > 0 and root then
				table.insert(result, character)
			end
		end
	end
	return result
end

function MatchService.OnStructureDamage(player, amount, kind, destroyed)
	if phase ~= "Battle" or not MatchService.IsParticipant(player) then
		return
	end
	dataService.AddStructureDamage(player, amount)
	if destroyed and kind ~= "Core" then
		local rewards = {
			LaneTower = { 12, 30, "Башня линии уничтожена" },
			Tower = { 8, 20, "Вражеская башня уничтожена" },
			Wall = { 5, 12, "Проход в стене открыт" },
			Barricade = { 4, 10, "Баррикада уничтожена" },
			SpikeTrap = { 3, 8, "Ловушка обезврежена" },
			FrostMine = { 3, 8, "Мина обезврежена" },
		}
		local reward = rewards[kind] or { 3, 8, "Вражеское сооружение уничтожено" }
		local stats = statsFor(player)
		stats.Structures = stats.Structures + 1
		publishStat(player, "Structures", stats.Structures)
		actionReward(player, reward[1], reward[2], reward[3])
		if bonusService then
			bonusService.OnAction(player, "Structure")
		end
	end
end

function MatchService.OnKill(player, victim)
	if phase == "Battle" and MatchService.IsParticipant(player) then
		local multiplier = currentRewardMultiplier()
		local coins = math.floor(2 * multiplier + 0.5)
		local xp = math.floor(8 * multiplier + 0.5)
		local reason = multiplier > 1 and "Противник выведен из боя · ×2 ИВЕНТ" or "Противник выведен из боя"
		local progress = dataService.AddKill(player, coins, xp, reason)
		recordProgress(player, progress)
		local stats = statsFor(player)
		stats.Kills = stats.Kills + 1
		stats.Coins = stats.Coins + coins
		stats.XP = stats.XP + xp
		publishStat(player, "Kills", stats.Kills)
		if bonusService then
			bonusService.OnAction(player, "Kill")
		end
	end
end

function MatchService.OnActionReward(player, coins, xp, reason)
	if phase == "Battle" and MatchService.IsParticipant(player) then
		actionReward(player, coins, xp, reason)
	end
end

function MatchService.OnBonusReward(player, coins, xp, reason)
	if (phase == "Build" or phase == "Battle") and MatchService.IsParticipant(player) then
		actionReward(player, coins, xp, reason)
	end
end

function MatchService.OnCapture67(team)
	if phase ~= "Battle" or not Config.Teams[team] then
		return
	end
	for _, player in ipairs(Players:GetPlayers()) do
		if participants[player.UserId] == team then
			local stats = statsFor(player)
			stats.Captures = stats.Captures + 1
			publishStat(player, "Captures", stats.Captures)
			actionReward(player, 10, 25, "67 захвачена · команда получает +1 HP/s")
			if bonusService then
				bonusService.OnAction(player, "Capture")
			end
		end
	end
end

function MatchService.EndMatch(winner, reason)
	if phase ~= "Battle" then
		return
	end
	setPhase("Results", Config.ResultsDuration)
	-- Results should show the fortress, not live mines/projectiles or a frozen
	-- jungle encounter. The next match will draft fresh classes and camps.
	if abilityService then
		abilityService.Reset()
	end
	if neutralService then
		neutralService.Reset()
	end
	if expeditionService then
		expeditionService.Reset()
	end
	if bonusService then
		bonusService.EndMatch()
	end
	state:SetAttribute("Winner", winner or "")
	state:SetAttribute("Reason", reason or "Ядро уничтожено")
	for _, player in ipairs(Players:GetPlayers()) do
		local team = participants[player.UserId]
		if team then
			local draw = not winner or winner == ""
			local reward = dataService.RecordMatch(player, team == winner, draw)
			local stats = statsFor(player)
			remotes.Results:FireClient(player, {
				Winner = winner or "",
				Team = team,
				Reason = reason or "",
				Reward = reward,
				Stats = {
					Builds = stats.Builds,
					Kills = stats.Kills,
					Structures = stats.Structures,
					Captures = stats.Captures,
					Coins = stats.Coins,
					XP = stats.XP,
					LevelCoins = stats.LevelCoins,
					Unlocks = stats.Unlocks,
				},
			})
		end
	end
	updateCounts()
end

function MatchService.OnCoreDestroyed(losingTeam, attackingTeam)
	if Config.Teams[losingTeam] and Config.Teams[attackingTeam] and losingTeam ~= attackingTeam then
		MatchService.EndMatch(attackingTeam, "Ядро крепости " .. Config.Teams[losingTeam].Name .. " уничтожено")
	end
end

function MatchService.StartMatch()
	if phase ~= "Lobby" then
		return false
	end
	local players = {}
	for _, player in ipairs(Players:GetPlayers()) do
		if queued[player.UserId] then
			table.insert(players, player)
		end
	end
	if #players == 0 then
		return false
	end
	-- Snake/level-aware draft: high levels are distributed by total team power, not join order.
	table.sort(players, function(a, b)
		local levelA = playerLevel(a)
		local levelB = playerLevel(b)
		if levelA == levelB then
			return a.UserId < b.UserId
		end
		return levelA > levelB
	end)
	for index = #players, Config.TeamSize * 2 + 1, -1 do
		local overflow = table.remove(players, index)
		queued[overflow.UserId] = nil
		overflow:SetAttribute("Queued", false)
		notify(overflow, "Матч 6×6 уже заполнен · попробуйте следующий")
	end
	matchId = matchId + 1
	participants = {}
	matchStats = {}
	regenClock = 0
	local counts = { Blue = 0, Orange = 0 }
	local power = { Blue = 0, Orange = 0 }
	for _, player in ipairs(players) do
		local team
		if counts.Blue >= Config.TeamSize then
			team = "Orange"
		elseif counts.Orange >= Config.TeamSize then
			team = "Blue"
		elseif power.Blue == power.Orange then
			team = counts.Blue <= counts.Orange and "Blue" or "Orange"
		else
			team = power.Blue < power.Orange and "Blue" or "Orange"
		end
		local level = playerLevel(player)
		participants[player.UserId] = team
		counts[team] = counts[team] + 1
		power[team] = power[team] + level
		queued[player.UserId] = nil
		player:SetAttribute("Queued", false)
		player:SetAttribute("Team", team)
		player:SetAttribute("MatchLevel", level)
		player:SetAttribute("InMatch", true)
		statsFor(player)
		for _, name in ipairs({ "Builds", "Kills", "Structures", "Captures" }) do
			publishStat(player, name, 0)
		end
	end
	if abilityService then
		abilityService.StartMatch(matchId, participants)
	end
	if bonusService then
		bonusService.StartMatch(matchId, participants)
	end
	for _, player in ipairs(players) do
		local stats = progressionService and progressionService.GetStats(player) or nil
		local capacity = (stats and stats.BuildCapacity or Config.Arena.MaxBuildPerPlayer) + (abilityService and abilityService.GetBuildBonus(player) or 0)
		player:SetAttribute("BuildRemaining", capacity)
	end
	state:SetAttribute("BluePower", power.Blue)
	state:SetAttribute("OrangePower", power.Orange)
	state:SetAttribute("MatchLevelDraft", true)
	intermission = nil
	if captureService then
		captureService.Reset()
	end
	fortressService.Reset()
	if neutralService then
		neutralService.StartMatch()
	end
	setPhase("Build", Config.BuildDuration)
	for _, player in ipairs(players) do
		spawnPlayer(player, teamSpawn(participants[player.UserId]))
		notify(player, "СТРОИТЕЛЬСТВО · укрепите свою крепость")
	end
	botService.Start(matchId, participants)
	updateCounts()
	return true
end

function MatchService.HandleLobbyAction(player, action)
	if phase ~= "Lobby" then
		notify(player, "Матч уже идёт · дождитесь возврата в лобби")
		return false
	end
	if not player:GetAttribute("ProfileLoaded") then
		notify(player, "Профиль загружается · секунду...")
		return false
	end
	if action == "QuickStart" then
		queued[player.UserId] = true
		player:SetAttribute("Queued", true)
		return MatchService.StartMatch()
	elseif action == "Queue" then
		if queued[player.UserId] then
			queued[player.UserId] = nil
			player:SetAttribute("Queued", false)
		else
			queued[player.UserId] = true
			player:SetAttribute("Queued", true)
			if not intermission then
				intermission = Config.IntermissionDuration
			end
		end
		if queueCount() == 0 then
			intermission = nil
			state:SetAttribute("Time", 0)
		else
			timer = intermission
			updateClock(true)
		end
		updateCounts()
		return true
	end
	return false
end

function MatchService.HandleBuild(player, kind, position, rotation)
	local team = participants[player.UserId]
	if phase ~= "Build" or not team then
		notify(player, "Строить можно только во время подготовки")
		return false
	end
	local success, reason = fortressService.BuildPlayer(player, team, kind, position, rotation)
	if not success then
		notify(player, reason)
		return false, reason
	end
	local stats = statsFor(player)
	stats.Builds = stats.Builds + 1
	publishStat(player, "Builds", stats.Builds)
	if stats.Builds == 1 then
		actionReward(player, 5, 15, "Первая постройка · крепость растёт")
	elseif stats.Builds == 3 then
		actionReward(player, 6, 14, "3 укрепления · базовая защита готова")
	else
		actionReward(player, 1, 4, "Укрепление установлено")
	end
	if bonusService then
		bonusService.OnAction(player, "Build")
	end
	return true, reason
end

function MatchService.HandleBuildPreview(player, kind, position, rotation, requestId)
	local team = participants[player.UserId]
	local cframe, reason = fortressService.GetPlayerPlacement(player, team, kind, position, rotation)
	local valid = cframe ~= nil
	remotes.BuildPreview:FireClient(player, {
		Kind = kind,
		RequestId = type(requestId) == "number" and requestId or nil,
		Rotation = fortressService.GetRotationDegrees(rotation),
		Valid = valid,
		Reason = reason or "Можно строить",
		Position = cframe and cframe.Position or position,
		CFrame = cframe,
		Team = team,
	})
	return valid, reason
end

local function onCharacter(player, character)
	local humanoid = character:WaitForChild("Humanoid")
	humanoid.JumpPower = 50
	if progressionService then
		progressionService.ApplyCharacter(player, character)
	else
		humanoid.WalkSpeed = 20
		humanoid.MaxHealth = 120
		humanoid.Health = 120
	end
	local team = participants[player.UserId]
	character:SetAttribute("Team", team or "")
	local root = character:WaitForChild("HumanoidRootPart")
	local oldLight = root:FindFirstChild("BlockSiegeTacticalLight")
	if oldLight then
		oldLight:Destroy()
	end
	local tacticalLight = Instance.new("SpotLight")
	tacticalLight.Name = "BlockSiegeTacticalLight"
	tacticalLight.Color = Color3.fromRGB(185, 220, 255)
	tacticalLight.Face = Enum.NormalId.Front
	tacticalLight.Angle = 68
	tacticalLight.Range = 34
	tacticalLight.Brightness = 1.15
	tacticalLight.Shadows = false
	tacticalLight.Enabled = phase ~= "Build"
	tacticalLight.Parent = root
	if abilityService then
		abilityService.ApplyCharacter(player, character)
	end
	weaponService.EquipPlayer(player)
	local spawn = pendingSpawns[player.UserId] or world.LobbySpawn
	task.defer(function()
		if character.Parent then
			character:PivotTo(spawn)
			-- Re-equip after the avatar finishes loading so R15 hands and the server
			-- weapon weld cannot be lost during character assembly or respawn.
			if player.Character == character then
				weaponService.EquipPlayer(player)
			end
		end
	end)
	local deathMatch = matchId
	humanoid.Died:Connect(function()
		local lastDamage = tonumber(character:GetAttribute("LastDamageClock")) or -math.huge
		local recentDamage = os.clock() - lastDamage <= 10
		local killerId = recentDamage and character:GetAttribute("LastAttackerUserId") or nil
		local killer = killerId and Players:GetPlayerByUserId(killerId) or nil
		if remotes.DeathFX then
			remotes.DeathFX:FireAllClients({
				VictimUserId = player.UserId,
				VictimName = player.DisplayName,
				KillerUserId = killerId,
				KillerName = recentDamage and (killer and killer.DisplayName or character:GetAttribute("LastAttackerName") or "") or "",
				Source = recentDamage and (character:GetAttribute("LastDamageSource") or "Unknown") or "Unknown",
				RespawnDuration = Config.RespawnDuration,
				InExpedition = player:GetAttribute("InExpedition") == true,
			})
		end
		if participants[player.UserId] and (phase == "Build" or phase == "Battle") then
			task.delay(Config.RespawnDuration, function()
				local currentTeam = participants[player.UserId]
				if currentTeam and matchId == deathMatch and (phase == "Build" or phase == "Battle") and player.Parent then
					spawnPlayer(player, teamSpawn(currentTeam))
				end
			end)
		end
	end)
end

function MatchService.OnPlayerAdded(player)
	player:SetAttribute("Queued", false)
	player:SetAttribute("Team", "")
	player:SetAttribute("InMatch", false)
	player:SetAttribute("ProfileLoaded", false)
	player:SetAttribute("BuildRemaining", 0)
	for _, name in ipairs({ "Builds", "Kills", "Structures", "Captures" }) do
		publishStat(player, name, 0)
	end
	player.CharacterAdded:Connect(function(character)
		onCharacter(player, character)
	end)
	spawnPlayer(player, world.LobbySpawn)
end

function MatchService.OnProfileLoaded(player)
	if player.Character then
		if progressionService then
			progressionService.ApplyCharacter(player, player.Character, player:GetAttribute("InMatch") == true)
		end
		if abilityService then
			abilityService.ApplyCharacter(player, player.Character)
		end
		weaponService.EquipPlayer(player)
	end
end

local function resetToLobby()
	botService.Stop()
	if abilityService then
		abilityService.Reset()
	end
	if neutralService then
		neutralService.Reset()
	end
	if expeditionService then
		expeditionService.Reset()
	end
	if bonusService then
		bonusService.Reset()
	end
	fortressService.Clear()
	if captureService then
		captureService.Reset()
	end
	participants = {}
	matchStats = {}
	queued = {}
	intermission = nil
	regenClock = 0
	for _, player in ipairs(Players:GetPlayers()) do
		player:SetAttribute("Team", "")
		player:SetAttribute("Queued", false)
		player:SetAttribute("InMatch", false)
		player:SetAttribute("BuildRemaining", 0)
		for _, name in ipairs({ "Builds", "Kills", "Structures", "Captures" }) do
			publishStat(player, name, 0)
		end
		spawnPlayer(player, world.LobbySpawn)
	end
	state:SetAttribute("Winner", "")
	state:SetAttribute("Reason", "")
	state:SetAttribute("BluePower", 0)
	state:SetAttribute("OrangePower", 0)
	state:SetAttribute("MatchLevelDraft", false)
	setPhase("Lobby", 0)
end

function MatchService.OnPlayerRemoving(player)
	local userId = player.UserId
	if weaponService and weaponService.OnPlayerRemoving then
		weaponService.OnPlayerRemoving(player)
	end
	queued[userId] = nil
	pendingSpawns[userId] = nil
	matchStats[userId] = nil
	local team = participants[userId]
	if abilityService then
		abilityService.OnPlayerRemoving(player)
	end
	if bonusService then
		bonusService.OnPlayerRemoving(player)
	end
	if team then
		participants[userId] = nil
		if participantCount() == 0 then
			matchId = matchId + 1
			resetToLobby()
			return
		elseif phase == "Build" or phase == "Battle" then
			botService.AddBot(team)
		end
	end
	updateCounts()
end

function MatchService.Init(dependencies)
	world = dependencies.World
	dataService = dependencies.DataService
	fortressService = dependencies.FortressService
	weaponService = dependencies.WeaponService
	botService = dependencies.BotService
	progressionService = dependencies.ProgressionService
	captureService = dependencies.CaptureService
	abilityService = dependencies.AbilityService
	neutralService = dependencies.NeutralService
	bonusService = dependencies.BonusService
	expeditionService = dependencies.ExpeditionService
	if dependencies.EventService then
		rewardMultiplierProvider = dependencies.EventService.GetRewardMultiplier
	end
	remotes = dependencies.Remotes
	state = dependencies.State
	fortressService.SetPhaseProvider(MatchService.GetPhase)
	fortressService.SetCoreHandler(MatchService.OnCoreDestroyed)
	fortressService.SetDamageHandler(MatchService.OnStructureDamage)
	fortressService.SetBuildCapacityProvider(function(player)
		local stats = progressionService and progressionService.GetStats(player)
		local baseCapacity = stats and stats.BuildCapacity or Config.Arena.MaxBuildPerPlayer
		return baseCapacity + (abilityService and abilityService.GetBuildBonus(player) or 0)
	end)
	fortressService.SetBuildAccessProvider(function(player, kind)
		return not progressionService or progressionService.CanBuildDefense(player, kind)
	end)
	fortressService.SetTargetsProvider(MatchService.GetTargets)
	weaponService.SetProviders(MatchService.GetPhase, MatchService.GetTeam, MatchService.OnKill)
	botService.SetProviders(MatchService.GetPhase, MatchService.GetTargets)
	if abilityService then
		abilityService.SetProviders(MatchService.GetPhase, MatchService.GetTeam, MatchService.GetTargets)
		abilityService.SetRewardHandler(MatchService.OnActionReward)
	end
	if neutralService then
		neutralService.SetPhaseProvider(MatchService.GetPhase)
		neutralService.SetRewardHandler(MatchService.OnActionReward)
	end
	if captureService then
		captureService.SetPhaseProvider(MatchService.GetPhase)
		captureService.SetCaptureHandler(MatchService.OnCapture67)
	end
	state:SetAttribute("Phase", "Lobby")
	state:SetAttribute("Time", 0)
	state:SetAttribute("Winner", "")
	state:SetAttribute("Reason", "")
	state:SetAttribute("BluePower", 0)
	state:SetAttribute("OrangePower", 0)
	state:SetAttribute("MatchLevelDraft", false)
	for _, team in ipairs(Config.TeamOrder) do
		state:SetAttribute(team .. "Core", 0)
		state:SetAttribute(team .. "CoreMax", Config.Arena.CoreHealth)
	end
	updateCounts()
end

function MatchService.Step(deltaTime)
	if bonusService then
		bonusService.Step(deltaTime)
	end
	if phase == "Lobby" then
		if intermission then
			if queueCount() == 0 then
				intermission = nil
				setPhase("Lobby", 0)
				return
			end
			intermission = math.max(0, intermission - deltaTime)
			timer = intermission
			updateClock()
			if intermission <= 0 then
				MatchService.StartMatch()
			end
		end
		return
	end
	if phase == "Battle" then
		regenClock = regenClock + deltaTime
		local ticks = math.floor(regenClock)
		if ticks > 0 then
			regenClock = regenClock - ticks
			local owner = captureService and captureService.GetOwner() or nil
			if owner then
				local function heal(model)
					local humanoid = model and model:FindFirstChildOfClass("Humanoid") or nil
					if humanoid and humanoid.Health > 0 then
						humanoid.Health = math.min(humanoid.MaxHealth, humanoid.Health + ticks)
					end
				end
				for _, player in ipairs(Players:GetPlayers()) do
					if participants[player.UserId] == owner then
						heal(player.Character)
					end
				end
				if botService then
					for _, model in ipairs(botService.GetModels(owner)) do
						heal(model)
					end
				end
			end
		end
	end
	timer = math.max(0, timer - deltaTime)
	updateClock()
	if timer > 0 then
		return
	end
	if phase == "Build" then
		setPhase("Battle", Config.BattleDuration)
		for _, player in ipairs(Players:GetPlayers()) do
			if participants[player.UserId] then
				-- Reassert the selected weapon and skin at the combat boundary.
				weaponService.EquipPlayer(player)
				notify(player, "ШТУРМ · уничтожьте вражеское ядро")
			end
		end
	elseif phase == "Battle" then
		local blue = fortressService.GetCoreHealth("Blue")
		local orange = fortressService.GetCoreHealth("Orange")
		if blue == orange then
			MatchService.EndMatch("", "Время вышло · ничья")
		else
			local winner = blue > orange and "Blue" or "Orange"
			MatchService.EndMatch(winner, "Время вышло · сохранено больше здоровья ядра")
		end
	elseif phase == "Results" then
		resetToLobby()
	end
end

return MatchService
