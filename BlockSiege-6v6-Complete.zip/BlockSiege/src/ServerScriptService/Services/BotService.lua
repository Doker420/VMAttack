-- Боты заполняют обе команды до шести, строят и штурмуют по тем же правилам, что и игроки.
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Shared = ReplicatedStorage:WaitForChild("BlockSiege")
local Config = require(Shared:WaitForChild("Config"))
local Catalog = require(Shared:WaitForChild("Catalog"))

local BotService = {}
local world
local fortressService
local weaponService
local phaseProvider = function()
	return "Lobby"
end
local targetsProvider = function()
	return {}
end
local bots = {}
local active = false
local matchId = 0
local nextBotId = 0

local botWeapons = { "Carbine", "SMG", "Scatter", "Marksman", "Demolisher", "Vortex" }

local function bodyPart(model, root, name, size, offset, color)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.CFrame = root.CFrame * CFrame.new(offset)
	part.Color = color
	part.Material = Enum.Material.SmoothPlastic
	part.Anchored = false
	part.CanCollide = false
	part.CanTouch = false
	part.CanQuery = true
	part.Massless = true
	part.Parent = model
	local weld = Instance.new("WeldConstraint")
	weld.Part0 = root
	weld.Part1 = part
	weld.Parent = part
	return part
end

local function addNameTag(head, entry)
	local gui = Instance.new("BillboardGui")
	gui.Name = "BotTag"
	gui.Size = UDim2.fromOffset(180, 42)
	gui.StudsOffset = Vector3.new(0, 2.2, 0)
	gui.AlwaysOnTop = true
	gui.MaxDistance = 150
	gui.Parent = head
	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.Font = Enum.Font.Code
	label.Text = string.format("%s BOT %02d", string.upper(entry.Team), entry.Slot)
	label.TextColor3 = Config.Teams[entry.Team].Color
	label.TextStrokeTransparency = 0.3
	label.TextScaled = true
	label.Parent = gui
end

local function spawnModel(entry)
	local spawn = world.TeamSpawns[entry.Team] * CFrame.new((entry.Slot - 3.5) * 3, 0, 0)
	local model = Instance.new("Model")
	model.Name = "Bot_" .. entry.Id
	model:SetAttribute("Team", entry.Team)
	model:SetAttribute("BotId", entry.Id)
	model:SetAttribute("IsBot", true)
	model.Parent = world.Bots
	local root = Instance.new("Part")
	root.Name = "HumanoidRootPart"
	root.Size = Vector3.new(3, 4.5, 3)
	root.CFrame = spawn
	root.Transparency = 1
	root.Anchored = false
	root.CanCollide = true
	root.CanTouch = false
	root.CanQuery = false
	root.Parent = model
	model.PrimaryPart = root
	local humanoid = Instance.new("Humanoid")
	humanoid.MaxHealth = 120
	humanoid.Health = 120
	humanoid.WalkSpeed = 18
	humanoid.JumpPower = 50
	humanoid.HipHeight = 0
	humanoid.RequiresNeck = false
	humanoid.BreakJointsOnDeath = false
	humanoid.Parent = model
	local color = Config.Teams[entry.Team].Color
	bodyPart(model, root, "Torso", Vector3.new(3, 2.2, 1.8), Vector3.new(0, 0.3, 0), color)
	bodyPart(model, root, "Head", Vector3.new(2.1, 1.8, 2.1), Vector3.new(0, 2.5, 0), Color3.fromRGB(224, 190, 145))
	bodyPart(model, root, "Left Arm", Vector3.new(1, 2.4, 1.4), Vector3.new(-2, 0.3, 0), color)
	bodyPart(model, root, "Right Arm", Vector3.new(1, 2.4, 1.4), Vector3.new(2, 0.3, 0), color)
	bodyPart(model, root, "Left Leg", Vector3.new(1.2, 2, 1.5), Vector3.new(-0.8, -1.8, 0), Config.Teams[entry.Team].Dark)
	bodyPart(model, root, "Right Leg", Vector3.new(1.2, 2, 1.5), Vector3.new(0.8, -1.8, 0), Config.Teams[entry.Team].Dark)
	addNameTag(model:FindFirstChild("Head"), entry)
	entry.Model = model
	entry.Humanoid = humanoid
	entry.LastPosition = root.Position
	entry.StuckTime = 0
	weaponService.EquipCharacter(model, entry.WeaponId)
	local spawnMatch = entry.MatchId
	humanoid.Died:Connect(function()
		task.delay(2, function()
			if entry.Model == model then
				model:Destroy()
			end
		end)
		task.delay(Config.RespawnDuration, function()
			if active and entry.MatchId == spawnMatch and matchId == spawnMatch and (phaseProvider() == "Battle" or phaseProvider() == "Build") then
				spawnModel(entry)
			end
		end)
	end)
	return model
end

local function addBot(team, slot)
	nextBotId = nextBotId + 1
	local entry = {
		Id = nextBotId,
		Team = team,
		Slot = slot,
		WeaponId = botWeapons[((slot - 1) % #botWeapons) + 1],
		MatchId = matchId,
		Builds = 0,
		NextBuild = os.clock() + 1 + slot * 0.15,
		NextThink = 0,
	}
	bots[entry.Id] = entry
	spawnModel(entry)
	return entry
end

function BotService.Init(dependencies)
	world = dependencies.World
	fortressService = dependencies.FortressService
	weaponService = dependencies.WeaponService
end

function BotService.SetProviders(phase, targets)
	phaseProvider = phase
	targetsProvider = targets
end

function BotService.Start(newMatchId, participants)
	BotService.Stop()
	matchId = newMatchId
	active = true
	local humanCounts = { Blue = 0, Orange = 0 }
	for _, team in pairs(participants) do
		if humanCounts[team] then
			humanCounts[team] = humanCounts[team] + 1
		end
	end
	for _, team in ipairs(Config.TeamOrder) do
		local needed = Config.TeamSize - humanCounts[team]
		for index = 1, needed do
			addBot(team, humanCounts[team] + index)
		end
	end
end

function BotService.AddBot(team)
	if not active then
		return nil
	end
	local used = {}
	for _, entry in pairs(bots) do
		if entry.Team == team then
			used[entry.Slot] = true
		end
	end
	for slot = 1, Config.TeamSize do
		if not used[slot] then
			return addBot(team, slot)
		end
	end
	return nil
end

function BotService.Stop()
	active = false
	for _, entry in pairs(bots) do
		if entry.Model then
			entry.Model:Destroy()
		end
	end
	bots = {}
end

function BotService.Count(team)
	local count = 0
	for _, entry in pairs(bots) do
		if entry.Team == team and entry.Model and entry.Model.Parent then
			count = count + 1
		end
	end
	return count
end

function BotService.GetModels(team)
	local result = {}
	for _, entry in pairs(bots) do
		local humanoid = entry.Model and entry.Model:FindFirstChildOfClass("Humanoid")
		if entry.Team == team and entry.Model and entry.Model.Parent and humanoid and humanoid.Health > 0 then
			table.insert(result, entry.Model)
		end
	end
	return result
end

local function nearestEnemy(entry, position)
	local best
	local bestDistance = math.huge
	for _, model in ipairs(targetsProvider(entry.Team)) do
		local root = model and model:FindFirstChild("HumanoidRootPart")
		local humanoid = model and model:FindFirstChildOfClass("Humanoid")
		if root and humanoid and humanoid.Health > 0 then
			local distance = (root.Position - position).Magnitude
			if distance < bestDistance then
				best = model
				bestDistance = distance
			end
		end
	end
	return best, bestDistance
end

function BotService.Step(deltaTime)
	if not active then
		return
	end
	local phase = phaseProvider()
	local now = os.clock()
	for _, entry in pairs(bots) do
		local model = entry.Model
		local humanoid = model and model:FindFirstChildOfClass("Humanoid")
		local root = model and model:FindFirstChild("HumanoidRootPart")
		if model and model.Parent and humanoid and humanoid.Health > 0 and root then
			if phase == "Build" then
				if entry.Builds < Config.Arena.BotBuildsPerBot and now >= entry.NextBuild then
					fortressService.BuildBot(entry.Team, entry.Slot, entry.Builds + 1)
					entry.Builds = entry.Builds + 1
					entry.NextBuild = now + 2.2
				end
				if entry.Builds >= Config.Arena.BotBuildsPerBot then
					humanoid:MoveTo(root.Position)
				end
			elseif phase == "Battle" and now >= entry.NextThink then
				entry.NextThink = now + 0.25
				local enemy, enemyDistance = nearestEnemy(entry, root.Position)
				local targetPosition = fortressService.GetCorePosition(Config.OtherTeam(entry.Team))
				if enemy and enemyDistance < 95 then
					local enemyRoot = enemy:FindFirstChild("HumanoidRootPart")
					targetPosition = enemyRoot.Position + Vector3.new(0, 1.5, 0)
				end
				local distance = (targetPosition - root.Position).Magnitude
				local weapon = Catalog.GetWeapon(entry.WeaponId)
				if distance > weapon.Range * 0.55 then
					humanoid:MoveTo(targetPosition)
				else
					humanoid:MoveTo(root.Position)
				end
				if distance <= weapon.Range * 0.95 then
					weaponService.FireBot(model, entry.WeaponId, targetPosition)
				end
				if entry.LastPosition and (root.Position - entry.LastPosition).Magnitude < 0.35 and distance > 20 then
					entry.StuckTime = entry.StuckTime + 0.25
					if entry.StuckTime > 1.2 then
						humanoid.Jump = true
						entry.StuckTime = 0
					end
				else
					entry.StuckTime = 0
				end
				entry.LastPosition = root.Position
			else
				humanoid:MoveTo(root.Position)
			end
		end
	end
end

return BotService
