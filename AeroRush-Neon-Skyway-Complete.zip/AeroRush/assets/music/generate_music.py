#!/usr/bin/env python3
"""Deterministic original AERORUSH soundtrack generator (Python stdlib only).

The compositions, synthesis and arrangement in this file were created for
AERORUSH: Neon Skyway. No samples or third-party recordings are used.
Output: seamless-loop 22,050 Hz, 16-bit stereo PCM WAV files.
"""

from __future__ import annotations

import array
import hashlib
import json
import math
from pathlib import Path
import random
import sys
import wave

SAMPLE_RATE = 22_050
TABLE_SIZE = 4096
TAU = math.tau
OUTPUT_DIR = Path(__file__).resolve().parent


def build_wave(kind: str) -> list[float]:
    values: list[float] = []
    for index in range(TABLE_SIZE):
        phase = index / TABLE_SIZE
        if kind == "sine":
            value = math.sin(TAU * phase)
        elif kind == "bass":
            value = (
                math.sin(TAU * phase)
                + 0.30 * math.sin(TAU * 2 * phase)
                + 0.12 * math.sin(TAU * 3 * phase)
            )
        elif kind == "pad":
            value = sum(
                amplitude * math.sin(TAU * harmonic * phase)
                for harmonic, amplitude in ((1, 1.0), (2, 0.23), (3, 0.13), (4, 0.07), (5, 0.04))
            )
        elif kind == "pluck":
            value = sum(
                amplitude * math.sin(TAU * harmonic * phase)
                for harmonic, amplitude in ((1, 1.0), (2, 0.34), (3, 0.16), (5, 0.08), (7, 0.035))
            )
        elif kind == "saw":
            value = sum(math.sin(TAU * harmonic * phase) / harmonic for harmonic in range(1, 11))
        elif kind == "square":
            value = sum(math.sin(TAU * harmonic * phase) / harmonic for harmonic in (1, 3, 5, 7, 9, 11))
        elif kind == "lead":
            value = (
                math.sin(TAU * phase)
                + 0.42 * math.sin(TAU * 2 * phase)
                + 0.24 * math.sin(TAU * 3 * phase)
                + 0.16 * math.sin(TAU * 5 * phase)
                + 0.08 * math.sin(TAU * 7 * phase)
            )
        else:
            raise ValueError(f"Unknown oscillator: {kind}")
        values.append(value)
    peak = max(abs(value) for value in values)
    return [value / peak for value in values]


WAVES = {kind: build_wave(kind) for kind in ("sine", "bass", "pad", "pluck", "saw", "square", "lead")}


def oscillator(kind: str, phase: float) -> float:
    table = WAVES[kind]
    position = phase * TABLE_SIZE
    first = int(position) & (TABLE_SIZE - 1)
    second = (first + 1) & (TABLE_SIZE - 1)
    fraction = position - int(position)
    return table[first] + (table[second] - table[first]) * fraction


def midi_frequency(note: float) -> float:
    return 440.0 * 2.0 ** ((note - 69.0) / 12.0)


class Song:
    def __init__(self, title: str, bpm: float, bars: int, seed: int):
        self.title = title
        self.bpm = bpm
        self.bars = bars
        self.beat = 60.0 / bpm
        self.bar = self.beat * 4
        self.duration = self.bar * bars
        self.length = round(self.duration * SAMPLE_RATE)
        self.left = array.array("f", [0.0]) * self.length
        self.right = array.array("f", [0.0]) * self.length
        self.random = random.Random(seed)

    def tone(
        self,
        start: float,
        duration: float,
        note: float,
        amplitude: float,
        kind: str,
        pan: float = 0.0,
        attack: float = 0.008,
        release: float = 0.12,
        decay: float = 0.0,
        detune: float = 0.0,
    ) -> None:
        start_sample = round(start * SAMPLE_RATE)
        release_samples = max(1, round(release * SAMPLE_RATE))
        attack_samples = max(1, round(attack * SAMPLE_RATE))
        total = max(1, round(duration * SAMPLE_RATE)) + release_samples
        frequency = midi_frequency(note)
        phase = 0.0
        phase_detuned = 0.0
        increment = frequency / SAMPLE_RATE
        detuned_increment = frequency * 2.0 ** (detune / 1200.0) / SAMPLE_RATE
        left_gain = math.sqrt((1.0 - pan) * 0.5)
        right_gain = math.sqrt((1.0 + pan) * 0.5)
        sustain_samples = total - release_samples
        for offset in range(total):
            if offset < attack_samples:
                envelope = offset / attack_samples
            elif offset >= sustain_samples:
                envelope = max(0.0, (total - offset) / release_samples)
            else:
                envelope = 1.0
            if decay:
                envelope *= math.exp(-decay * offset / SAMPLE_RATE)
            value = oscillator(kind, phase)
            if detune:
                value = value * 0.72 + oscillator(kind, phase_detuned) * 0.28
                phase_detuned += detuned_increment
                if phase_detuned >= 1.0:
                    phase_detuned -= 1.0
            phase += increment
            if phase >= 1.0:
                phase -= 1.0
            sample = value * amplitude * envelope
            index = (start_sample + offset) % self.length
            self.left[index] += sample * left_gain
            self.right[index] += sample * right_gain

    def kick(self, start: float, amplitude: float = 0.24) -> None:
        start_sample = round(start * SAMPLE_RATE)
        length = round(0.30 * SAMPLE_RATE)
        phase = 0.0
        for offset in range(length):
            time = offset / SAMPLE_RATE
            frequency = 43.0 + 112.0 * math.exp(-time * 25.0)
            phase += frequency / SAMPLE_RATE
            envelope = math.exp(-time * 15.0)
            click = self.random.uniform(-1.0, 1.0) * math.exp(-time * 160.0) * 0.12
            sample = (math.sin(TAU * phase) + click) * envelope * amplitude
            index = (start_sample + offset) % self.length
            self.left[index] += sample
            self.right[index] += sample

    def snare(self, start: float, amplitude: float = 0.13) -> None:
        start_sample = round(start * SAMPLE_RATE)
        length = round(0.22 * SAMPLE_RATE)
        previous_noise = 0.0
        for offset in range(length):
            time = offset / SAMPLE_RATE
            noise = self.random.uniform(-1.0, 1.0)
            bright_noise = noise - previous_noise * 0.72
            previous_noise = noise
            envelope = math.exp(-time * 20.0)
            sample = (bright_noise * 0.68 + math.sin(TAU * 178.0 * time) * 0.32) * envelope * amplitude
            index = (start_sample + offset) % self.length
            self.left[index] += sample * 0.96
            self.right[index] += sample

    def hat(self, start: float, amplitude: float = 0.045, open_hat: bool = False, pan: float = 0.0) -> None:
        start_sample = round(start * SAMPLE_RATE)
        length = round((0.19 if open_hat else 0.055) * SAMPLE_RATE)
        previous_noise = 0.0
        left_gain = math.sqrt((1.0 - pan) * 0.5)
        right_gain = math.sqrt((1.0 + pan) * 0.5)
        for offset in range(length):
            time = offset / SAMPLE_RATE
            noise = self.random.uniform(-1.0, 1.0)
            high = noise - previous_noise
            previous_noise = noise
            envelope = math.exp(-time * (24.0 if open_hat else 68.0))
            sample = high * envelope * amplitude
            index = (start_sample + offset) % self.length
            self.left[index] += sample * left_gain
            self.right[index] += sample * right_gain

    def add_loop_delay(self, amount: float, left_seconds: float, right_seconds: float) -> None:
        dry_left = self.left
        dry_right = self.right
        self.left = array.array("f", dry_left)
        self.right = array.array("f", dry_right)
        left_delay = round(left_seconds * SAMPLE_RATE)
        right_delay = round(right_seconds * SAMPLE_RATE)
        long_delay = round((left_seconds + right_seconds) * 1.37 * SAMPLE_RATE)
        for index in range(self.length):
            left_index = index - left_delay
            if left_index < 0:
                left_index += self.length
            right_index = index - right_delay
            if right_index < 0:
                right_index += self.length
            long_index = index - long_delay
            if long_index < 0:
                long_index += self.length
            self.left[index] = dry_left[index] + amount * (dry_right[left_index] * 0.72 + dry_left[long_index] * 0.28)
            self.right[index] = dry_right[index] + amount * (dry_left[right_index] * 0.72 + dry_right[long_index] * 0.28)

    def write(self, filename: str) -> dict[str, object]:
        peak = max(max(abs(value) for value in self.left), max(abs(value) for value in self.right))
        gain = 0.91 / max(peak, 0.0001)
        pcm = array.array("h")
        squared_sum = 0.0
        for left, right in zip(self.left, self.right):
            for value in (left * gain, right * gain):
                # Gentle saturation, followed by hard safety bounds.
                value = math.tanh(value * 1.08) / math.tanh(1.08)
                value = max(-0.98, min(0.98, value))
                squared_sum += value * value
                pcm.append(round(value * 32767.0))
        if sys.byteorder != "little":
            pcm.byteswap()
        path = OUTPUT_DIR / filename
        with wave.open(str(path), "wb") as output:
            output.setnchannels(2)
            output.setsampwidth(2)
            output.setframerate(SAMPLE_RATE)
            output.writeframes(pcm.tobytes())
        rms = math.sqrt(squared_sum / len(pcm))
        return {
            "file": filename,
            "title": self.title,
            "bpm": self.bpm,
            "bars": self.bars,
            "durationSeconds": self.length / SAMPLE_RATE,
            "sampleRate": SAMPLE_RATE,
            "channels": 2,
            "bitsPerSample": 16,
            "peakBeforeSaturation": round(peak, 6),
            "rms": round(rms, 6),
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }


def compose_lobby() -> Song:
    song = Song("Skyway Afterglow", 100, 16, 420101)
    progression = [
        (45, (57, 60, 64, 67, 71)),  # Am9
        (41, (53, 57, 60, 64, 67)),  # Fmaj9
        (48, (55, 60, 62, 64, 67)),  # Cadd9
        (43, (55, 59, 62, 64, 67)),  # G6
    ]
    arp_pattern = (0, 2, 1, 3, 2, 4, 3, 1)
    for bar in range(song.bars):
        root, chord = progression[bar % len(progression)]
        start = bar * song.bar
        for index, note in enumerate(chord):
            song.tone(
                start,
                song.bar * 0.90,
                note,
                0.030,
                "pad",
                pan=(index - 2) * 0.22,
                attack=0.34,
                release=0.72,
                detune=5.0,
            )
        bass_pattern = ((0.0, root), (1.5, root), (2.0, root + 7), (3.25, root + 12))
        for beat, note in bass_pattern:
            song.tone(start + beat * song.beat, 0.31, note, 0.080, "bass", release=0.09, decay=2.2)
        for step, chord_index in enumerate(arp_pattern):
            note = chord[chord_index] + 12
            song.tone(
                start + step * song.beat * 0.5,
                0.13,
                note,
                0.052 if step % 2 == 0 else 0.042,
                "pluck",
                pan=(-0.48 if step % 2 == 0 else 0.48),
                release=0.30,
                decay=5.0,
            )
        if bar % 2 == 1:
            for index, chord_index in enumerate((4, 3, 2, 1)):
                song.tone(
                    start + (index + 0.5) * song.beat,
                    0.24,
                    chord[chord_index] + 24,
                    0.022,
                    "sine",
                    pan=0.30,
                    release=0.50,
                    decay=3.0,
                )
        for beat in (0.0, 2.0):
            song.kick(start + beat * song.beat, 0.17)
        if bar % 4 == 3:
            song.kick(start + 3.5 * song.beat, 0.12)
        for beat in (1.0, 3.0):
            song.snare(start + beat * song.beat, 0.075)
        for step in range(8):
            song.hat(
                start + step * song.beat * 0.5,
                0.022 if step % 2 else 0.032,
                open_hat=(step == 7 and bar % 2 == 1),
                pan=0.22 if step % 2 else -0.18,
            )
    song.add_loop_delay(0.23, 0.30, 0.45)
    return song


def compose_race() -> Song:
    song = Song("Neon Slipstream", 150, 32, 420102)
    progression = [
        (40, (52, 55, 59, 64)),  # Em7
        (36, (48, 52, 55, 60)),  # C
        (43, (55, 59, 62, 67)),  # G
        (38, (50, 54, 57, 62)),  # D
    ]
    arp_pattern = (0, 1, 2, 3, 2, 1, 3, 1, 0, 2, 1, 3, 2, 3, 1, 2)
    bass_pattern = (0, 0, 12, 0, 7, 0, 12, 7)
    for bar in range(song.bars):
        root, chord = progression[bar % len(progression)]
        start = bar * song.bar
        section_energy = 1.0 + (0.10 if bar >= 24 else 0.0)
        for step in range(8):
            song.tone(
                start + step * song.beat * 0.5,
                0.16,
                root + bass_pattern[step],
                0.082 * section_energy,
                "bass",
                release=0.055,
                decay=2.0,
            )
        for step, chord_index in enumerate(arp_pattern):
            song.tone(
                start + step * song.beat * 0.25,
                0.065,
                chord[chord_index] + 12,
                (0.039 if step % 4 == 0 else 0.029) * section_energy,
                "square",
                pan=(-0.38 if step % 2 == 0 else 0.38),
                release=0.11,
                decay=8.0,
            )
        for beat in (0.0, 1.5, 2.0, 3.5):
            for index, note in enumerate(chord):
                song.tone(
                    start + beat * song.beat,
                    0.10,
                    note + 12,
                    0.017,
                    "saw",
                    pan=(index - 1.5) * 0.25,
                    release=0.17,
                    decay=3.0,
                )
        for beat in range(4):
            song.kick(start + beat * song.beat, 0.235)
        if bar % 4 == 3:
            song.kick(start + 3.75 * song.beat, 0.15)
        for beat in (1.0, 3.0):
            song.snare(start + beat * song.beat, 0.145)
        for step in range(16):
            song.hat(
                start + step * song.beat * 0.25,
                (0.038 if step % 4 == 0 else 0.024) * section_energy,
                open_hat=(step == 15 and bar % 2 == 1),
                pan=0.30 if step % 2 else -0.24,
            )
        if bar % 4 in (2, 3):
            melody = (3, 2, 1, 2, 3, 1, 0, 2)
            for step, chord_index in enumerate(melody):
                song.tone(
                    start + step * song.beat * 0.5,
                    0.16,
                    chord[chord_index] + 24,
                    0.032,
                    "lead",
                    pan=0.12,
                    attack=0.012,
                    release=0.20,
                    decay=2.8,
                    detune=7.0,
                )
    song.add_loop_delay(0.18, 0.20, 0.30)
    return song


def main() -> None:
    tracks = [compose_lobby(), compose_race()]
    filenames = ["AeroRush_Lobby_SkywayAfterglow.wav", "AeroRush_Race_NeonSlipstream.wav"]
    manifest = {
        "project": "AERORUSH: Neon Skyway",
        "license": "Original project audio; created without third-party samples or recordings.",
        "generator": "generate_music.py",
        "tracks": [song.write(filename) for song, filename in zip(tracks, filenames)],
    }
    (OUTPUT_DIR / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    for track in manifest["tracks"]:
        print(f"{track['file']}: {track['durationSeconds']:.3f}s, {track['bytes']} bytes, RMS {track['rms']}")


if __name__ == "__main__":
    main()
