-- Замкнутая трасса Neon Skyway. Координаты задают центр каждого гейта.
local Track = {}

Track.Gates = {
	{ Position = Vector3.new(0, 60, 220), Width = 38, Height = 24 },
	{ Position = Vector3.new(0, 76, 90), Width = 34, Height = 22 },
	{ Position = Vector3.new(82, 94, 12), Width = 32, Height = 22 },
	{ Position = Vector3.new(174, 76, -48), Width = 34, Height = 24 },
	{ Position = Vector3.new(220, 55, -154), Width = 30, Height = 20 },
	{ Position = Vector3.new(148, 46, -254), Width = 32, Height = 22 },
	{ Position = Vector3.new(18, 70, -286), Width = 36, Height = 24 },
	{ Position = Vector3.new(-104, 98, -232), Width = 32, Height = 22 },
	{ Position = Vector3.new(-194, 114, -108), Width = 30, Height = 20 },
	{ Position = Vector3.new(-224, 82, 32), Width = 34, Height = 24 },
	{ Position = Vector3.new(-158, 64, 154), Width = 32, Height = 22 },
	{ Position = Vector3.new(-72, 56, 220), Width = 34, Height = 22 },
}

Track.LobbySpawn = CFrame.new(0, 88, 338)
Track.WorldCenter = Vector3.new(0, 40, -20)

function Track.GetGateCFrame(index)
	local gate = Track.Gates[index]
	local nextGate = Track.Gates[index % #Track.Gates + 1]
	return CFrame.lookAt(gate.Position, nextGate.Position)
end

function Track.GetGridCFrame(gridIndex)
	-- Три дрона в ряд; более поздние ряды стоят дальше за стартовой линией.
	local row = math.floor((gridIndex - 1) / 3)
	local column = (gridIndex - 1) % 3 - 1
	return Track.GetGateCFrame(1) * CFrame.new(column * 11, 0, 28 + row * 13)
end

return Track
