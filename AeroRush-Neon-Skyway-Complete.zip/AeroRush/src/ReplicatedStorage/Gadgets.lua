-- Нелетальные гоночные гаджеты. Все открываются только игрой, не за Robux.
local Gadgets = {}

Gadgets.Rarities = {
	Green = { Name = "ЗЕЛЁНЫЙ", Color = Color3.fromRGB(91, 255, 151) },
	Blue = { Name = "СИНИЙ", Color = Color3.fromRGB(74, 157, 255) },
	Legendary = { Name = "ЛЕГЕНДАРНЫЙ", Color = Color3.fromRGB(255, 207, 70) },
}

Gadgets.List = {
	{ Id = "PulseLaser", Name = "ИМПУЛЬС", Description = "Энергетический луч до 110 м. 16 урона и небольшое замедление.", Rarity = "Green", Slot = "Attack", Cooldown = 5, Free = true },
	{ Id = "SpikeTrap", Name = "НЕОН-ШИПЫ", Description = "Оставляет энергетические шипы. 12 урона и замедление на 1.8 сек.", Rarity = "Green", Slot = "Attack", Cooldown = 7, Free = true },
	{ Id = "RepairPulse", Name = "РЕМОНТ", Description = "Восстанавливает 30 прочности дрона.", Rarity = "Green", Slot = "Defense", Cooldown = 14, Free = true },

	{ Id = "GlueMine", Name = "ЛИПУЧКА", Description = "Клейкая мина: 6 урона и сильное замедление на 2.8 сек.", Rarity = "Blue", Slot = "Attack", Cooldown = 8, UnlockRaces = 3 },
	{ Id = "EMPBurst", Name = "EMP-ВОЛНА", Description = "Поражает дроны в радиусе 45 м и отключает boost на 3 сек.", Rarity = "Blue", Slot = "Attack", Cooldown = 10, UnlockRaces = 5 },
	{ Id = "AegisShield", Name = "ЩИТ AEGIS", Description = "Добавляет 40 единиц щита на 6 секунд.", Rarity = "Blue", Slot = "Defense", Cooldown = 14, UnlockRaces = 7 },

	{ Id = "RailLaser", Name = "RAIL-LASER", Description = "Пробивает несколько дронов на дистанции до 170 м. 22 урона.", Rarity = "Legendary", Slot = "Attack", Cooldown = 9, UnlockRaces = 10 },
	{ Id = "GravityWell", Name = "ГРАВИ-ЛОВУШКА", Description = "Притягивает соперников и замедляет их внутри поля.", Rarity = "Legendary", Slot = "Attack", Cooldown = 12, UnlockRaces = 15 },
	{ Id = "PhoenixProtocol", Name = "ФЕНИКС", Description = "Восстанавливает 35 прочности и добавляет 20 щита.", Rarity = "Legendary", Slot = "Defense", Cooldown = 18, UnlockRaces = 20 },
}

for _, gadget in ipairs(Gadgets.List) do
	local rarity = Gadgets.Rarities[gadget.Rarity]
	gadget.Color = rarity.Color
	gadget.RarityName = rarity.Name
end

Gadgets.Case = {
	Name = "ТЕХНО-КЕЙС",
	Odds = { Green = 65, Blue = 30, Legendary = 5 },
	LegendaryPity = 20,
	DuplicateCredits = { Green = 60, Blue = 150, Legendary = 400 },
}

function Gadgets.Get(gadgetId)
	for _, gadget in ipairs(Gadgets.List) do
		if gadget.Id == gadgetId then
			return gadget
		end
	end
	return nil
end

function Gadgets.ForRarity(rarity)
	local result = {}
	for _, gadget in ipairs(Gadgets.List) do
		if gadget.Rarity == rarity then
			table.insert(result, gadget)
		end
	end
	return result
end

return Gadgets
