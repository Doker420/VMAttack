-- Единый каталог магазина, косметики и бесплатных активностей.
-- Перед публикацией замените нулевые ProductId на ID из Creator Dashboard.
local Catalog = {}

Catalog.ShopItems = {
	{
		Id = "AeroClub",
		Kind = "GamePass",
		ProductId = 0,
		PriceRobux = 149,
		Tag = "CLUB",
		Name = "AERO CLUB",
		Description = "Значок профиля, золотая рамка и скин Club. Только стиль, без бонуса к скорости.",
	},
	{
		Id = "ChromaPack",
		Kind = "GamePass",
		ProductId = 0,
		PriceRobux = 199,
		Tag = "SKINS",
		Name = "CHROMA PACK",
		Description = "Неоновые скины Chroma и Aurora для всех будущих заездов.",
	},
	{
		Id = "TrailPack",
		Kind = "GamePass",
		ProductId = 0,
		PriceRobux = 149,
		Tag = "FX",
		Name = "TRAIL PACK",
		Description = "Радужный и кометный следы. Визуальный эффект не меняет характеристики.",
	},
	{
		Id = "Boost3",
		Kind = "DeveloperProduct",
		ProductId = 0,
		PriceRobux = 49,
		Tag = "2X",
		Name = "BOOST ПРОКАЧКИ ×3",
		Description = "2× кредиты и 1.5× XP за следующие 3 финиша. Скорость дрона не меняется.",
		Action = "CreditBoost",
		Amount = 3,
		Multiplier = 2,
	},
	{
		Id = "Boost10",
		Kind = "DeveloperProduct",
		ProductId = 0,
		PriceRobux = 129,
		Tag = "2X",
		Name = "BOOST ПРОКАЧКИ ×10",
		Description = "2× кредиты и 1.5× XP за следующие 10 финишей. Можно накапливать до 30.",
		Action = "CreditBoost",
		Amount = 10,
		Multiplier = 2,
	},
	{
		Id = "CreditPack750",
		Kind = "DeveloperProduct",
		ProductId = 0,
		PriceRobux = 79,
		Tag = "+750",
		Name = "ПАК КРЕДИТОВ",
		Description = "750 кредиты для косметики из гаража. Не даёт преимущества в гонке.",
		Action = "Credits",
		Amount = 750,
	},
	{
		Id = "Tip25",
		Kind = "DeveloperProduct",
		ProductId = 0,
		PriceRobux = 25,
		Tag = "THX",
		Name = "МАЛЕНЬКИЙ ДОНАТ",
		Description = "Добровольная поддержка разработчика. Награды и преимущества не входят.",
		Action = "Donation",
	},
	{
		Id = "Tip99",
		Kind = "DeveloperProduct",
		ProductId = 0,
		PriceRobux = 99,
		Tag = "THX",
		Name = "ДОНАТ ПИЛОТА",
		Description = "Добровольная поддержка разработчика. Награды и преимущества не входят.",
		Action = "Donation",
	},
	{
		Id = "Tip249",
		Kind = "DeveloperProduct",
		ProductId = 0,
		PriceRobux = 249,
		Tag = "THX",
		Name = "ДОНАТ СПОНСОРА",
		Description = "Добровольная поддержка разработчика. Награды и преимущества не входят.",
		Action = "Donation",
	},
}

Catalog.Cosmetics = {
	{ Id = "SkinCyan", Type = "Skin", Name = "CYAN", Accent = Color3.fromRGB(25, 232, 255), Secondary = Color3.fromRGB(255, 45, 150), Free = true },
	{ Id = "SkinPink", Type = "Skin", Name = "PULSE", Accent = Color3.fromRGB(255, 82, 156), Secondary = Color3.fromRGB(25, 232, 255), Free = true },
	{ Id = "SkinYellow", Type = "Skin", Name = "SOLAR", Accent = Color3.fromRGB(255, 197, 61), Secondary = Color3.fromRGB(255, 82, 156), Free = true },
	{ Id = "SkinPurple", Type = "Skin", Name = "VIOLET", Accent = Color3.fromRGB(146, 104, 255), Secondary = Color3.fromRGB(25, 232, 255), Free = true },
	{ Id = "SkinMint", Type = "Skin", Name = "MINT", Accent = Color3.fromRGB(91, 255, 151), Secondary = Color3.fromRGB(25, 232, 255), Free = true },
	{ Id = "SkinOrange", Type = "Skin", Name = "EMBER", Accent = Color3.fromRGB(255, 126, 61), Secondary = Color3.fromRGB(255, 197, 61), Free = true },
	{ Id = "SkinSunset", Type = "Skin", Name = "SUNSET", Accent = Color3.fromRGB(255, 77, 109), Secondary = Color3.fromRGB(255, 190, 70), CreditPrice = 500 },
	{ Id = "SkinWave", Type = "Skin", Name = "DEEP WAVE", Accent = Color3.fromRGB(40, 112, 255), Secondary = Color3.fromRGB(50, 255, 207), CreditPrice = 900 },
	{ Id = "SkinLevel3", Type = "Skin", Name = "PRO PILOT", Accent = Color3.fromRGB(235, 247, 255), Secondary = Color3.fromRGB(25, 232, 255), UnlockLevel = 3 },
	{ Id = "SkinChroma", Type = "Skin", Name = "CHROMA", Accent = Color3.fromRGB(255, 56, 210), Secondary = Color3.fromRGB(45, 255, 240), GamePass = "ChromaPack" },
	{ Id = "SkinAurora", Type = "Skin", Name = "AURORA", Accent = Color3.fromRGB(93, 255, 178), Secondary = Color3.fromRGB(174, 92, 255), GamePass = "ChromaPack" },
	{ Id = "SkinClub", Type = "Skin", Name = "CLUB GOLD", Accent = Color3.fromRGB(255, 207, 70), Secondary = Color3.fromRGB(255, 255, 235), GamePass = "AeroClub" },

	{ Id = "TrailCyan", Type = "Trail", Name = "ION", ColorA = Color3.fromRGB(25, 232, 255), ColorB = Color3.fromRGB(255, 45, 150), Free = true },
	{ Id = "TrailPink", Type = "Trail", Name = "CANDY", ColorA = Color3.fromRGB(255, 89, 177), ColorB = Color3.fromRGB(255, 190, 225), CreditPrice = 650 },
	{ Id = "TrailStar", Type = "Trail", Name = "STARLIGHT", ColorA = Color3.fromRGB(255, 220, 85), ColorB = Color3.fromRGB(255, 255, 240), CreditPrice = 1200 },
	{ Id = "TrailLevel5", Type = "Trail", Name = "ELITE", ColorA = Color3.fromRGB(235, 247, 255), ColorB = Color3.fromRGB(25, 232, 255), UnlockLevel = 5 },
	{ Id = "TrailRainbow", Type = "Trail", Name = "RAINBOW", ColorA = Color3.fromRGB(255, 70, 130), ColorB = Color3.fromRGB(70, 235, 255), GamePass = "TrailPack" },
	{ Id = "TrailComet", Type = "Trail", Name = "COMET", ColorA = Color3.fromRGB(255, 135, 45), ColorB = Color3.fromRGB(255, 235, 135), GamePass = "TrailPack" },
}

Catalog.DefaultSkins = { "SkinCyan", "SkinPink", "SkinYellow", "SkinPurple", "SkinMint", "SkinOrange" }

Catalog.DailyRewards = {
	{ Credits = 100 },
	{ Credits = 150 },
	{ Credits = 200, CaseTokens = 1 },
	{ Credits = 250 },
	{ Credits = 300, CaseTokens = 1 },
	{ Credits = 400 },
	{ Credits = 700, BoostRaces = 1 },
}

Catalog.Quests = {
	{ Id = "Gates", Name = "ВОЗДУШНЫЙ МАРШРУТ", Description = "Пройди 36 гейтов", Target = 36, Reward = 200, XP = 60 },
	{ Id = "Finishes", Name = "ФИНИШЕР", Description = "Заверши 2 заезда", Target = 2, Reward = 250, XP = 80 },
	{ Id = "BoostSeconds", Name = "ПОЛНЫЙ ИМПУЛЬС", Description = "Используй boost 45 секунд", Target = 45, Reward = 200, XP = 60 },
	{ Id = "SocialRaces", Name = "КОМАНДНЫЙ ВЫЛЕТ", Description = "Финишируй в сервере с другом", Target = 1, Reward = 300, XP = 100 },
}

Catalog.Badges = {
	FirstFinish = 0,
	FirstWin = 0,
	Level5 = 0,
}

function Catalog.GetShopItem(itemId)
	for _, item in ipairs(Catalog.ShopItems) do
		if item.Id == itemId then
			return item
		end
	end
	return nil
end

function Catalog.GetProduct(productId)
	for _, item in ipairs(Catalog.ShopItems) do
		if item.Kind == "DeveloperProduct" and item.ProductId == productId and productId > 0 then
			return item
		end
	end
	return nil
end

function Catalog.GetCosmetic(cosmeticId)
	for _, cosmetic in ipairs(Catalog.Cosmetics) do
		if cosmetic.Id == cosmeticId then
			return cosmetic
		end
	end
	return nil
end

function Catalog.LevelForXP(xp)
	return math.floor(math.max(0, xp) / 500) + 1
end

function Catalog.XPForLevel(level)
	return math.max(0, level - 1) * 500
end

return Catalog
