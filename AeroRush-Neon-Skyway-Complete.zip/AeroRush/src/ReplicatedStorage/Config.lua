-- AERORUSH: общие настройки гонки. Все игровые параметры собраны здесь.
local Config = {
	GameName = "AERORUSH",
	TrackName = "NEON SKYWAY",
	MaxRacers = 12,
	MinRacers = 1, -- 1 позволяет тестировать заезд в одиночку; на продакшене можно поставить 2.
	Laps = 3,
	IntermissionDuration = 20,
	CountdownDuration = 5,
	RaceTimeLimit = 240,
	PostRaceDuration = 15,
	ResetCooldown = 2,

	Drone = {
		MaxSpeed = 95,
		BoostSpeed = 145,
		ReverseSpeed = 38,
		VerticalSpeed = 46,
		Acceleration = 4.2,
		VerticalAcceleration = 5.5,
		YawSpeed = 2.1,
		CollisionRadius = 3.2,
		BoostCapacity = 100,
		BoostDrain = 30,
		BoostRecharge = 19,
		KillY = -110,
	},

	DataStoreName = "AeroRush_PlayerData_v1",
	PersistInStudio = false,
	AutosaveInterval = 90,

	-- Магазин и удержание. Тестовые покупки работают только в Studio.
	EnableStudioTestPurchases = true,
	StartingCredits = 300,
	DailyCooldown = 20 * 60 * 60,
	FriendBonusPerFriend = 0.10,
	FriendBonusCap = 0.30,
	MaxStoredBoostRaces = 30,
}

function Config.FormatTime(seconds)
	if not seconds or seconds <= 0 then
		return "--:--.---"
	end

	local minutes = math.floor(seconds / 60)
	local remainder = seconds - minutes * 60
	return string.format("%02d:%06.3f", minutes, remainder)
end

return Config
