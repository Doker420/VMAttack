-- AERORUSH: общие настройки гонки. Все игровые параметры собраны здесь.
local Config = {
	GameName = "AERORUSH",
	TrackName = "NEON SKYWAY",
	MaxRacers = 12,
	MinRacers = 1, -- 1 позволяет тестировать заезд в одиночку; на продакшене можно поставить 2.
	Laps = 3,
	IntermissionDuration = 20,
	CountdownDuration = 5,
	RaceTimeLimit = 240,
	PostRaceDuration = 15,
	ResetCooldown = 2,

	Drone = {
		MaxSpeed = 95,
		BoostSpeed = 145,
		ReverseSpeed = 38,
		VerticalSpeed = 46,
		Acceleration = 4.2,
		VerticalAcceleration = 5.5,
		YawSpeed = 2.1,
		CollisionRadius = 3.2,
		BoostCapacity = 100,
		BoostDrain = 30,
		BoostRecharge = 19,
		KillY = -110,
	},

	-- Основной предел — трёхмерный коридор вдоль сегментов трассы.
	-- Общий бокс остаётся только аварийной защитой координат мира.
	Boundary = {
		Center = Vector3.new(0, 60, -20),
		HalfSize = Vector3.new(310, 140, 430),
		SoftZone = 38,
		Pushback = 92,
		TrackRadius = 32,
		TrackSoftZone = 12,
		TrackReturnSpeed = 110,
	},

	Blaster = {
		Damage = 12,
		Cooldown = 0.85,
		Range = 120,
		Width = 5.5,
	},

	Rating = {
		StartingRating = 1000,
		KFactor = 32,
		Minimum = 100,
		Maximum = 10000,
	},

	Coins = {
		PerSegment = 3,
		PickupRadius = 6.5,
		RespawnDelay = 18,
		MaxPerRacer = 24,
		ComboDuration = 4.5,
		BaseBoost = 8,
	},

	DataStoreName = "AeroRush_PlayerData_v1",
	PersistInStudio = false,
	AutosaveInterval = 90,

	-- Магазин и удержание. Тестовые покупки работают только в Studio.
	EnableStudioTestPurchases = true,
	StartingCredits = 300,
	DailyCooldown = 20 * 60 * 60,
	FriendBonusPerFriend = 0.10,
	FriendBonusCap = 0.30,
	MaxStoredBoostRaces = 30,

	-- Оригинальные треки из assets загружаются в Roblox отдельно; 0 = без звука.
	Music = {
		LobbySoundId = 0,
		RaceSoundId = 0,
		LobbyVolume = 0.26,
		RaceVolume = 0.18,
		DefaultEnabled = true,
	},
}

function Config.FormatTime(seconds)
	if not seconds or seconds <= 0 then
		return "--:--.---"
	end

	local minutes = math.floor(seconds / 60)
	local remainder = seconds - minutes * 60
	return string.format("%02d:%06.3f", minutes, remainder)
end

return Config
