-- Игровой тюнинг без Robux: TECH добывается только монетами и финишами.
local Tuning = {}

Tuning.MaxModuleLevel = 3
Tuning.ModuleCosts = { 10, 30, 60 }

Tuning.Presets = {
	{
		Id = "Balanced",
		Name = "БАЛАНС",
		Description = "Заводская настройка без слабых мест.",
		Speed = 1,
		BoostSpeed = 1,
		Acceleration = 1,
		Yaw = 1,
		Capacity = 1,
		Drain = 1,
		Recharge = 1,
	},
	{
		Id = "Sprint",
		Name = "СПРИНТ",
		Description = "+5% скорость, +8% boost · медленнее разгон, выше расход.",
		Speed = 1.05,
		BoostSpeed = 1.08,
		Acceleration = 0.93,
		Yaw = 0.96,
		Capacity = 1,
		Drain = 1.08,
		Recharge = 1,
	},
	{
		Id = "Agile",
		Name = "МАНЁВР",
		Description = "+10% разгон, +14% поворот · −4% максимальная скорость.",
		Speed = 0.96,
		BoostSpeed = 0.97,
		Acceleration = 1.10,
		Yaw = 1.14,
		Capacity = 1,
		Drain = 0.98,
		Recharge = 1,
	},
	{
		Id = "Endurance",
		Name = "ВЫНОСЛИВОСТЬ",
		Description = "+18% батарея, +12% восстановление · −2% скорость.",
		Speed = 0.98,
		BoostSpeed = 0.98,
		Acceleration = 1,
		Yaw = 1,
		Capacity = 1.18,
		Drain = 0.94,
		Recharge = 1.12,
	},
}

Tuning.Modules = {
	{
		Id = "Engine",
		Name = "ДВИГАТЕЛЬ",
		Description = "За уровень: +2.5% скорость и +3% мощность boost.",
	},
	{
		Id = "Battery",
		Name = "БАТАРЕЯ",
		Description = "За уровень: +10% заряд и +4% восстановление.",
	},
	{
		Id = "Handling",
		Name = "УПРАВЛЕНИЕ",
		Description = "За уровень: +5% разгон и +5% скорость поворота.",
	},
}

function Tuning.GetPreset(id)
	for _, preset in ipairs(Tuning.Presets) do
		if preset.Id == id then
			return preset
		end
	end
	return Tuning.Presets[1]
end

function Tuning.GetModule(id)
	for _, module in ipairs(Tuning.Modules) do
		if module.Id == id then
			return module
		end
	end
	return nil
end

function Tuning.GetLevel(profile, id)
	local levels = type(profile) == "table" and profile.UpgradeLevels or nil
	local value = type(levels) == "table" and levels[id] or 0
	if type(value) ~= "number" or value ~= value then
		return 0
	end
	return math.clamp(math.floor(value), 0, Tuning.MaxModuleLevel)
end

function Tuning.GetStats(profile)
	local preset = Tuning.GetPreset(type(profile) == "table" and profile.TuningPreset or "Balanced")
	local engine = Tuning.GetLevel(profile, "Engine")
	local battery = Tuning.GetLevel(profile, "Battery")
	local handling = Tuning.GetLevel(profile, "Handling")
	return {
		Speed = (1 + engine * 0.025) * preset.Speed,
		BoostSpeed = (1 + engine * 0.03) * preset.BoostSpeed,
		Acceleration = (1 + handling * 0.05) * preset.Acceleration,
		Yaw = (1 + handling * 0.05) * preset.Yaw,
		Capacity = (1 + battery * 0.10) * preset.Capacity,
		Drain = preset.Drain,
		Recharge = (1 + battery * 0.04) * preset.Recharge,
	}
end

return Tuning
