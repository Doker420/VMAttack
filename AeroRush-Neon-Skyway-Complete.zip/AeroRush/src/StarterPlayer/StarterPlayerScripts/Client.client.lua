-- AERORUSH client: HUD, камера, ввод и локальные визуальные эффекты.
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Track = require(Shared:WaitForChild("Track"))
local Gadgets = require(Shared:WaitForChild("Gadgets"))
local remotes = Shared:WaitForChild("Remotes")
local raceState = ReplicatedStorage:WaitForChild("AeroRushState")

local COLORS = {
	Navy = Color3.fromRGB(6, 11, 25),
	Panel = Color3.fromRGB(13, 23, 42),
	Cyan = Color3.fromRGB(31, 232, 255),
	Pink = Color3.fromRGB(255, 52, 153),
	Purple = Color3.fromRGB(143, 92, 255),
	White = Color3.fromRGB(235, 247, 255),
	Muted = Color3.fromRGB(139, 158, 183),
	Yellow = Color3.fromRGB(255, 214, 74),
}

local function create(className, properties, parent)
	local instance = Instance.new(className)
	for property, value in pairs(properties or {}) do
		instance[property] = value
	end
	instance.Parent = parent
	return instance
end

local function corner(parent, radius)
	return create("UICorner", { CornerRadius = UDim.new(0, radius or 10) }, parent)
end

local function stroke(parent, color, transparency)
	return create("UIStroke", {
		Color = color or COLORS.Cyan,
		Transparency = transparency or 0.55,
		Thickness = 1,
	}, parent)
end

local function textLabel(parent, name, text, size, position, fontSize, color, font)
	return create("TextLabel", {
		Name = name,
		Size = size,
		Position = position or UDim2.new(),
		BackgroundTransparency = 1,
		Font = font or Enum.Font.Gotham,
		Text = text,
		TextColor3 = color or COLORS.White,
		TextSize = fontSize or 16,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextYAlignment = Enum.TextYAlignment.Center,
	}, parent)
end

local screen = create("ScreenGui", {
	Name = "AeroRushHUD",
	ResetOnSpawn = false,
	IgnoreGuiInset = true,
	DisplayOrder = 20,
	ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
}, playerGui)

-- Бренд и название трассы.
local brand = create("Frame", {
	Name = "Brand",
	Size = UDim2.fromOffset(258, 66),
	Position = UDim2.fromOffset(22, 20),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.12,
}, screen)
corner(brand, 12)
stroke(brand, COLORS.Cyan, 0.72)
create("Frame", { Size = UDim2.fromOffset(4, 42), Position = UDim2.fromOffset(12, 12), BackgroundColor3 = COLORS.Cyan, BorderSizePixel = 0 }, brand)
textLabel(brand, "Title", Config.GameName, UDim2.fromOffset(220, 33), UDim2.fromOffset(27, 7), 27, COLORS.White, Enum.Font.GothamBlack)
textLabel(brand, "Track", Config.TrackName .. "  /  MULTIPLAYER", UDim2.fromOffset(225, 22), UDim2.fromOffset(29, 39), 11, COLORS.Cyan, Enum.Font.GothamBold)

-- Текущая фаза матча.
local phasePill = create("Frame", {
	Name = "Phase",
	AnchorPoint = Vector2.new(0.5, 0),
	Position = UDim2.new(0.5, 0, 0, 20),
	Size = UDim2.fromOffset(310, 58),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.12,
}, screen)
corner(phasePill, 29)
stroke(phasePill, COLORS.Purple, 0.65)
local phaseTitle = textLabel(phasePill, "Title", "ПОДГОТОВКА", UDim2.new(1, -20, 0, 25), UDim2.fromOffset(10, 5), 14, COLORS.White, Enum.Font.GothamBold)
phaseTitle.TextXAlignment = Enum.TextXAlignment.Center
local phaseDetail = textLabel(phasePill, "Detail", "Синхронизация...", UDim2.new(1, -20, 0, 20), UDim2.fromOffset(10, 30), 12, COLORS.Muted)
phaseDetail.TextXAlignment = Enum.TextXAlignment.Center

-- Круг, следующий гейт и время.
local raceStats = create("Frame", {
	Name = "RaceStats",
	Size = UDim2.fromOffset(238, 146),
	Position = UDim2.fromOffset(22, 98),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.16,
	Visible = false,
}, screen)
corner(raceStats, 12)
stroke(raceStats, COLORS.Cyan, 0.78)
local lapLabel = textLabel(raceStats, "Lap", "КРУГ 1 / 3", UDim2.fromOffset(205, 29), UDim2.fromOffset(16, 10), 22, COLORS.White, Enum.Font.GothamBlack)
local gateLabel = textLabel(raceStats, "Gate", "СЛЕДУЮЩИЙ ГЕЙТ 02 / 12", UDim2.fromOffset(205, 20), UDim2.fromOffset(16, 42), 12, COLORS.Cyan, Enum.Font.GothamBold)
local timerLabel = textLabel(raceStats, "Timer", "00:00.000", UDim2.fromOffset(205, 34), UDim2.fromOffset(16, 67), 26, COLORS.White, Enum.Font.GothamBold)
local bestLabel = textLabel(raceStats, "Best", "ЛУЧШИЙ КРУГ  --:--.---", UDim2.fromOffset(205, 20), UDim2.fromOffset(16, 108), 12, COLORS.Muted)
local distanceLabel = textLabel(raceStats, "Distance", "", UDim2.fromOffset(205, 18), UDim2.fromOffset(16, 126), 11, COLORS.Muted)

-- Общая live-таблица.
local leaderboard = create("Frame", {
	Name = "Leaderboard",
	AnchorPoint = Vector2.new(1, 0),
	Position = UDim2.new(1, -22, 0, 98),
	Size = UDim2.fromOffset(292, 396),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.14,
	Visible = false,
}, screen)
corner(leaderboard, 12)
stroke(leaderboard, COLORS.Purple, 0.75)
textLabel(leaderboard, "Header", "LIVE  /  ПОЗИЦИИ", UDim2.fromOffset(260, 28), UDim2.fromOffset(14, 7), 13, COLORS.Cyan, Enum.Font.GothamBold)
local leaderboardList = create("Frame", { Size = UDim2.fromOffset(266, 348), Position = UDim2.fromOffset(12, 40), BackgroundTransparency = 1 }, leaderboard)
create("UIListLayout", { Padding = UDim.new(0, 4), SortOrder = Enum.SortOrder.LayoutOrder }, leaderboardList)
local leaderboardRows = {}
for index = 1, Config.MaxRacers do
	local row = create("Frame", {
		Size = UDim2.new(1, 0, 0, 25),
		BackgroundColor3 = COLORS.Panel,
		BackgroundTransparency = 0.18,
		Visible = false,
		LayoutOrder = index,
	}, leaderboardList)
	corner(row, 5)
	local place = textLabel(row, "Place", tostring(index), UDim2.fromOffset(28, 25), UDim2.fromOffset(7, 0), 13, COLORS.Muted, Enum.Font.GothamBold)
	local name = textLabel(row, "Pilot", "", UDim2.fromOffset(137, 25), UDim2.fromOffset(37, 0), 12, COLORS.White, Enum.Font.GothamBold)
	name.TextTruncate = Enum.TextTruncate.AtEnd
	local detail = textLabel(row, "Detail", "", UDim2.fromOffset(80, 25), UDim2.fromOffset(180, 0), 10, COLORS.Muted)
	detail.TextXAlignment = Enum.TextXAlignment.Right
	leaderboardRows[index] = { Row = row, Place = place, Name = name, Detail = detail }
end

-- Большой центральный отсчёт.
local countdown = textLabel(screen, "Countdown", "", UDim2.fromOffset(620, 150), UDim2.new(0.5, -310, 0.34, -75), 104, COLORS.White, Enum.Font.GothamBlack)
countdown.TextXAlignment = Enum.TextXAlignment.Center
countdown.TextStrokeColor3 = COLORS.Navy
countdown.TextStrokeTransparency = 0.25
countdown.Visible = false
local countdownSub = textLabel(screen, "CountdownSub", "", UDim2.fromOffset(500, 36), UDim2.new(0.5, -250, 0.34, 72), 16, COLORS.Cyan, Enum.Font.GothamBold)
countdownSub.TextXAlignment = Enum.TextXAlignment.Center
countdownSub.Visible = false

-- Скорость и заряд ускорения.
local speedPanel = create("Frame", {
	Name = "Speed",
	AnchorPoint = Vector2.new(0.5, 1),
	Position = UDim2.new(0.5, 0, 1, -24),
	Size = UDim2.fromOffset(264, 116),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.12,
	Visible = false,
}, screen)
corner(speedPanel, 14)
stroke(speedPanel, COLORS.Cyan, 0.7)
local speedValue = textLabel(speedPanel, "Value", "0", UDim2.fromOffset(168, 58), UDim2.fromOffset(16, 4), 48, COLORS.White, Enum.Font.GothamBlack)
local speedUnit = textLabel(speedPanel, "Unit", "КМ/Ч", UDim2.fromOffset(58, 24), UDim2.fromOffset(184, 26), 12, COLORS.Cyan, Enum.Font.GothamBold)
local boostCaption = textLabel(speedPanel, "BoostCaption", "BOOST", UDim2.fromOffset(130, 18), UDim2.fromOffset(17, 69), 11, COLORS.Muted, Enum.Font.GothamBold)
local boostNumber = textLabel(speedPanel, "BoostNumber", "100%", UDim2.fromOffset(80, 18), UDim2.fromOffset(166, 69), 11, COLORS.Cyan, Enum.Font.GothamBold)
boostNumber.TextXAlignment = Enum.TextXAlignment.Right
local boostBack = create("Frame", { Size = UDim2.fromOffset(230, 9), Position = UDim2.fromOffset(17, 94), BackgroundColor3 = Color3.fromRGB(34, 47, 68), BorderSizePixel = 0 }, speedPanel)
corner(boostBack, 5)
local boostBar = create("Frame", { Size = UDim2.fromScale(1, 1), BackgroundColor3 = COLORS.Cyan, BorderSizePixel = 0 }, boostBack)
corner(boostBar, 5)

local healthPanel = create("Frame", {
	Name = "DroneHealth",
	AnchorPoint = Vector2.new(0.5, 1),
	Position = UDim2.new(0.5, 0, 1, -150),
	Size = UDim2.fromOffset(264, 50),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.1,
	Visible = false,
}, screen)
corner(healthPanel, 12)
stroke(healthPanel, Color3.fromRGB(54, 64, 103), 0.3)
textLabel(healthPanel, "Caption", "ПРОЧНОСТЬ ДРОНА", UDim2.new(1, -20, 0, 18), UDim2.fromOffset(10, 4), 11, COLORS.White, Enum.Font.GothamBold)
local healthBack = create("Frame", {
	Position = UDim2.fromOffset(12, 25),
	Size = UDim2.new(1, -24, 0, 12),
	BackgroundColor3 = Color3.fromRGB(35, 39, 60),
	BorderSizePixel = 0,
}, healthPanel)
corner(healthBack, 6)
local healthBar = create("Frame", { Size = UDim2.fromScale(1, 1), BackgroundColor3 = COLORS.Cyan, BorderSizePixel = 0 }, healthBack)
corner(healthBar, 6)
local healthText = textLabel(healthBack, "Value", "100", UDim2.fromScale(1, 1), UDim2.new(), 11, COLORS.White, Enum.Font.GothamBold)
healthText.TextXAlignment = Enum.TextXAlignment.Center
local shieldLabel = textLabel(healthPanel, "Shield", "", UDim2.fromOffset(100, 18), UDim2.new(1, -110, 0, 4), 11, COLORS.Cyan, Enum.Font.GothamBold)
shieldLabel.TextXAlignment = Enum.TextXAlignment.Right

local gadgetPanel = create("Frame", {
	Name = "GadgetControls",
	AnchorPoint = Vector2.new(0.5, 1),
	Position = UDim2.new(0.5, 154, 1, -24),
	Size = UDim2.fromOffset(170, 116),
	BackgroundTransparency = 1,
	Visible = false,
}, screen)
local attackButton = create("TextButton", {
	Name = "AttackGadget",
	Size = UDim2.new(1, 0, 0, 52),
	BackgroundColor3 = COLORS.Panel,
	Font = Enum.Font.GothamBold,
	Text = "F · ИМПУЛЬС",
	TextColor3 = COLORS.Cyan,
	TextSize = 13,
	AutoButtonColor = true,
}, gadgetPanel)
corner(attackButton, 12)
stroke(attackButton, COLORS.Cyan, 0.25)
local defenseButton = create("TextButton", {
	Name = "DefenseGadget",
	Position = UDim2.fromOffset(0, 62),
	Size = UDim2.new(1, 0, 0, 52),
	BackgroundColor3 = COLORS.Panel,
	Font = Enum.Font.GothamBold,
	Text = "G · РЕМОНТ",
	TextColor3 = COLORS.Cyan,
	TextSize = 13,
	AutoButtonColor = true,
}, gadgetPanel)
corner(defenseButton, 12)
stroke(defenseButton, COLORS.Cyan, 0.25)
if UserInputService.TouchEnabled then
	gadgetPanel.Position = UDim2.new(0.5, 0, 1, -212)
end

local controlsHint = create("Frame", {
	Size = UDim2.fromOffset(390, 62),
	Position = UDim2.new(0, 22, 1, -82),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.28,
}, screen)
corner(controlsHint, 10)
textLabel(controlsHint, "Line1", "WASD — движение · Q/E — поворот · F/G — гаджеты", UDim2.fromOffset(370, 22), UDim2.fromOffset(12, 8), 11, COLORS.White, Enum.Font.GothamBold)
textLabel(controlsHint, "Line2", "SPACE / CTRL — высота   ·   SHIFT — boost   ·   R — reset", UDim2.fromOffset(370, 20), UDim2.fromOffset(12, 33), 10, COLORS.Muted)

attackButton.Activated:Connect(function()
	remotes.CombatAction:FireServer("UseAttack")
end)
defenseButton.Activated:Connect(function()
	remotes.CombatAction:FireServer("UseDefense")
end)

local resetButton = create("TextButton", {
	Name = "Reset",
	AnchorPoint = Vector2.new(1, 1),
	Position = UDim2.new(1, -22, 1, -26),
	Size = UDim2.fromOffset(128, 44),
	BackgroundColor3 = COLORS.Panel,
	BackgroundTransparency = 0.08,
	Text = "R  /  RESET",
	Font = Enum.Font.GothamBold,
	TextSize = 13,
	TextColor3 = COLORS.White,
	AutoButtonColor = true,
	Visible = false,
}, screen)
corner(resetButton, 10)
stroke(resetButton, COLORS.Pink, 0.55)
resetButton.Activated:Connect(function()
	remotes.Reset:FireServer()
end)
UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed then
		return
	end
	if input.KeyCode == Enum.KeyCode.R or input.KeyCode == Enum.KeyCode.ButtonY then
		remotes.Reset:FireServer()
	elseif input.KeyCode == Enum.KeyCode.F or input.KeyCode == Enum.KeyCode.ButtonR1 then
		remotes.CombatAction:FireServer("UseAttack")
	elseif input.KeyCode == Enum.KeyCode.G or input.KeyCode == Enum.KeyCode.ButtonL1 then
		remotes.CombatAction:FireServer("UseDefense")
	end
end)

local notification = textLabel(screen, "Notification", "", UDim2.fromOffset(600, 44), UDim2.new(0.5, -300, 0, 92), 16, COLORS.White, Enum.Font.GothamBold)
notification.TextXAlignment = Enum.TextXAlignment.Center
notification.BackgroundTransparency = 0.16
notification.BackgroundColor3 = COLORS.Navy
notification.Visible = false
corner(notification, 12)
notification.TextWrapped = true
local notificationQueue = {}
local notificationWorking = false
local function showNotification(text, kind)
	if #notificationQueue >= 8 then
		table.remove(notificationQueue, 1)
	end
	table.insert(notificationQueue, { Text = text, Kind = kind })
	if notificationWorking then
		return
	end
	notificationWorking = true
	task.spawn(function()
		while #notificationQueue > 0 do
			local item = table.remove(notificationQueue, 1)
			notification.Text = item.Text
			notification.TextColor3 = item.Kind == "success" and COLORS.Cyan or (item.Kind == "warning" and COLORS.Yellow or COLORS.White)
			notification.Visible = true
			task.wait(item.Kind == "checkpoint" and 1 or 3.2)
		end
		notification.Visible = false
		notificationWorking = false
	end)
end

-- Таблица результатов.
local resultsOverlay = create("Frame", { Name = "ResultsOverlay", Size = UDim2.fromScale(1, 1), BackgroundColor3 = COLORS.Navy, BackgroundTransparency = 0.35, Visible = false, Active = true }, screen)
local resultsModal = create("Frame", { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(570, 492), BackgroundColor3 = COLORS.Panel, BackgroundTransparency = 0.03 }, resultsOverlay)
corner(resultsModal, 18)
stroke(resultsModal, COLORS.Cyan, 0.35)
local resultsTitle = textLabel(resultsModal, "Title", "РЕЗУЛЬТАТЫ", UDim2.fromOffset(510, 48), UDim2.fromOffset(28, 20), 32, COLORS.White, Enum.Font.GothamBlack)
local resultsSubtitle = textLabel(resultsModal, "Subtitle", Config.TrackName, UDim2.fromOffset(510, 24), UDim2.fromOffset(30, 68), 13, COLORS.Cyan, Enum.Font.GothamBold)
local resultHeaders = textLabel(resultsModal, "Headers", "МЕСТО        ПИЛОТ                              ВРЕМЯ          ЛУЧШИЙ КРУГ", UDim2.fromOffset(510, 24), UDim2.fromOffset(30, 108), 11, COLORS.Muted, Enum.Font.GothamBold)
resultHeaders.TextXAlignment = Enum.TextXAlignment.Left
local resultsList = create("ScrollingFrame", {
	Position = UDim2.fromOffset(28, 140),
	Size = UDim2.fromOffset(514, 270),
	BackgroundTransparency = 1,
	BorderSizePixel = 0,
	CanvasSize = UDim2.new(),
	AutomaticCanvasSize = Enum.AutomaticSize.Y,
	ScrollBarThickness = 4,
	ScrollBarImageColor3 = COLORS.Cyan,
}, resultsModal)
create("UIListLayout", { Padding = UDim.new(0, 5), SortOrder = Enum.SortOrder.LayoutOrder }, resultsList)
local resultRows = {}
for index = 1, Config.MaxRacers do
	local row = create("Frame", { Size = UDim2.new(1, -8, 0, 38), BackgroundColor3 = COLORS.Navy, BackgroundTransparency = 0.12, LayoutOrder = index, Visible = false }, resultsList)
	corner(row, 7)
	local place = textLabel(row, "Place", "", UDim2.fromOffset(60, 38), UDim2.fromOffset(12, 0), 15, COLORS.Cyan, Enum.Font.GothamBlack)
	local name = textLabel(row, "Name", "", UDim2.fromOffset(175, 38), UDim2.fromOffset(72, 0), 14, COLORS.White, Enum.Font.GothamBold)
	name.TextTruncate = Enum.TextTruncate.AtEnd
	local time = textLabel(row, "Time", "", UDim2.fromOffset(120, 38), UDim2.fromOffset(252, 0), 12, COLORS.White, Enum.Font.GothamBold)
	local best = textLabel(row, "Best", "", UDim2.fromOffset(120, 38), UDim2.fromOffset(382, 0), 11, COLORS.Muted)
	resultRows[index] = { Row = row, Place = place, Name = name, Time = time, Best = best }
end
local closeResults = create("TextButton", { AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 430), Size = UDim2.fromOffset(220, 42), BackgroundColor3 = COLORS.Cyan, Text = "ГОТОВ К РЕВАНШУ", Font = Enum.Font.GothamBlack, TextSize = 14, TextColor3 = COLORS.Navy }, resultsModal)
corner(closeResults, 10)
closeResults.Activated:Connect(function()
	resultsOverlay.Visible = false
end)

local function showResults(results)
	local ownPlace = 0
	for index, entry in ipairs(results) do
		local row = resultRows[index]
		if row then
			row.Row.Visible = true
			row.Place.Text = entry.Finished and ("#" .. entry.Place) or "DNF"
			row.Name.Text = entry.Name
			row.Time.Text = entry.Finished and Config.FormatTime(entry.FinishTime) or "—"
			row.Best.Text = Config.FormatTime(entry.BestLap)
			row.Name.TextColor3 = entry.UserId == player.UserId and COLORS.Cyan or (entry.AeroClub and COLORS.Yellow or COLORS.White)
			if entry.UserId == player.UserId then
				ownPlace = entry.Finished and entry.Place or 0
			end
		end
	end
	for index = #results + 1, Config.MaxRacers do
		resultRows[index].Row.Visible = false
	end
	resultsTitle.Text = ownPlace == 1 and "ПОБЕДА!" or "РЕЗУЛЬТАТЫ"
	resultsTitle.TextColor3 = ownPlace == 1 and COLORS.Cyan or COLORS.White
	resultsOverlay.Visible = true
end

-- Короткое обучение при первом входе.
local helpOverlay = create("Frame", { Name = "WelcomeOverlay", Size = UDim2.fromScale(1, 1), BackgroundColor3 = COLORS.Navy, BackgroundTransparency = 0.25, Visible = true, Active = true }, screen)
local helpModal = create("Frame", { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(600, 430), BackgroundColor3 = COLORS.Panel, BackgroundTransparency = 0.02 }, helpOverlay)
corner(helpModal, 18)
stroke(helpModal, COLORS.Cyan, 0.35)
textLabel(helpModal, "Eyebrow", "ДОБРО ПОЖАЛОВАТЬ В NEON SKYWAY", UDim2.fromOffset(540, 24), UDim2.fromOffset(30, 26), 12, COLORS.Cyan, Enum.Font.GothamBold)
textLabel(helpModal, "Title", "ГОНКИ НА ДРОНАХ", UDim2.fromOffset(540, 52), UDim2.fromOffset(28, 56), 34, COLORS.White, Enum.Font.GothamBlack)
local helpBody = UserInputService.TouchEnabled
	and "Левый стик — движение и поворот по трассе.\nКнопки справа — высота и ускорение.\nДве кнопки гаджетов — атака и защита.\nПроходи гейты по порядку. При нуле прочности дрон перезагрузится у гейта."
	or "WASD — движение   Q / E — поворот   SPACE / CTRL — высота\nSHIFT — ускорение   R — вернуться к последнему гейту\nF / G — гаджеты   R1 / L1 — гаджеты на геймпаде\nПроходи гейты по порядку. При нуле прочности дрон перезагрузится у гейта."
local helpText = textLabel(helpModal, "Body", helpBody, UDim2.fromOffset(530, 145), UDim2.fromOffset(30, 128), 17, COLORS.White, Enum.Font.GothamBold)
helpText.TextWrapped = true
helpText.TextYAlignment = Enum.TextYAlignment.Top
local tip = textLabel(helpModal, "Tip", "Сервер управляет физикой и гейтами — все пилоты соревнуются в одном живом заезде.", UDim2.fromOffset(530, 54), UDim2.fromOffset(30, 286), 13, COLORS.Muted)
tip.TextWrapped = true
local flyButton = create("TextButton", { Position = UDim2.fromOffset(30, 358), Size = UDim2.fromOffset(540, 46), BackgroundColor3 = COLORS.Cyan, Text = "ГОТОВ К СТАРТУ", Font = Enum.Font.GothamBlack, TextSize = 15, TextColor3 = COLORS.Navy }, helpModal)
corner(flyButton, 10)
flyButton.Activated:Connect(function()
	helpOverlay.Visible = false
end)

-- Сенсорное управление: левый стик и три кнопки справа.
local touchMove = Vector2.zero
local touchFlags = { Up = false, Down = false, Boost = false }
local touchControls = create("Frame", { Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1, Visible = UserInputService.TouchEnabled }, screen)
local joystick = create("Frame", { AnchorPoint = Vector2.new(0, 1), Position = UDim2.new(0, 24, 1, -104), Size = UDim2.fromOffset(142, 142), BackgroundColor3 = COLORS.Navy, BackgroundTransparency = 0.35, Active = true }, touchControls)
corner(joystick, 71)
stroke(joystick, COLORS.Cyan, 0.55)
local knob = create("Frame", { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(58, 58), BackgroundColor3 = COLORS.Cyan, BackgroundTransparency = 0.18 }, joystick)
corner(knob, 29)
local joystickInput

local function updateJoystick(input)
	local center = Vector2.new(joystick.AbsolutePosition.X + joystick.AbsoluteSize.X / 2, joystick.AbsolutePosition.Y + joystick.AbsoluteSize.Y / 2)
	local position = Vector2.new(input.Position.X, input.Position.Y)
	local delta = position - center
	local radius = math.max(30, joystick.AbsoluteSize.X * 0.34)
	if delta.Magnitude > radius then
		delta = delta.Unit * radius
	end
	touchMove = Vector2.new(delta.X / radius, -delta.Y / radius)
	knob.Position = UDim2.new(0.5, delta.X, 0.5, delta.Y)
end

joystick.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
		joystickInput = input
		updateJoystick(input)
	end
end)
UserInputService.InputChanged:Connect(function(input)
	if input == joystickInput then
		updateJoystick(input)
	end
end)
UserInputService.InputEnded:Connect(function(input)
	if input == joystickInput then
		joystickInput = nil
		touchMove = Vector2.zero
		knob.Position = UDim2.fromScale(0.5, 0.5)
	end
end)

local function actionButton(text, position, color, action)
	local button = create("TextButton", { AnchorPoint = Vector2.new(1, 1), Position = position, Size = UDim2.fromOffset(82, 68), BackgroundColor3 = COLORS.Navy, BackgroundTransparency = 0.22, Text = text, Font = Enum.Font.GothamBlack, TextSize = 14, TextColor3 = color, AutoButtonColor = false, Active = true }, touchControls)
	corner(button, 16)
	stroke(button, color, 0.4)
	button.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
			touchFlags[action] = true
			button.BackgroundTransparency = 0
		end
	end)
	button.InputEnded:Connect(function()
		touchFlags[action] = false
		button.BackgroundTransparency = 0.22
	end)
	return button
end

actionButton("ВВЕРХ", UDim2.new(1, -24, 1, -232), COLORS.Cyan, "Up")
actionButton("ВНИЗ", UDim2.new(1, -24, 1, -104), COLORS.White, "Down")
actionButton("BOOST", UDim2.new(1, -118, 1, -168), COLORS.Pink, "Boost")

if UserInputService.TouchEnabled then
	controlsHint.Visible = false
	resetButton.Position = UDim2.new(1, -218, 1, -30)
end

-- Подсветка только следующего обязательного гейта.
local targetHighlight = create("Highlight", { FillColor = COLORS.Cyan, FillTransparency = 0.86, OutlineColor = COLORS.Cyan, OutlineTransparency = 0, DepthMode = Enum.HighlightDepthMode.AlwaysOnTop, Enabled = false }, Workspace)
local highlightedGate
local function updateTargetHighlight()
	local gateIndex = player:GetAttribute("Gate") or 0
	local world = Workspace:FindFirstChild("AeroRushWorld")
	local gates = world and world:FindFirstChild("Gates")
	local gate = gates and gates:FindFirstChild(string.format("Gate_%02d", gateIndex))
	if gate ~= highlightedGate then
		highlightedGate = gate
		targetHighlight.Adornee = gate
	end
	targetHighlight.Enabled = gate ~= nil and player:GetAttribute("Racing") == true and not player:GetAttribute("Finished")
end

local function getOwnDrone()
	local world = Workspace:FindFirstChild("AeroRushWorld")
	local drones = world and world:FindFirstChild("Drones")
	local model = drones and drones:FindFirstChild("Drone_" .. player.UserId)
	if model and model.PrimaryPart then
		return model
	end
	return nil
end

local function updateLeaderboard(entries)
	leaderboard.Visible = #entries > 0
	for index, row in ipairs(leaderboardRows) do
		local entry = entries[index]
		row.Row.Visible = entry ~= nil
		if entry then
			row.Place.Text = "#" .. entry.Place
			row.Place.TextColor3 = entry.Place == 1 and COLORS.Yellow or COLORS.Muted
			row.Name.Text = entry.Name
			row.Name.TextColor3 = entry.UserId == player.UserId and COLORS.Cyan or (entry.AeroClub and COLORS.Yellow or COLORS.White)
			row.Detail.Text = entry.Finished and Config.FormatTime(entry.FinishTime) or string.format("%d/%d · %d", entry.Lap, entry.Gate, math.floor(entry.Speed * 1.2 + 0.5))
		end
	end
end

remotes.Leaderboard.OnClientEvent:Connect(updateLeaderboard)
remotes.Notify.OnClientEvent:Connect(showNotification)
remotes.Results.OnClientEvent:Connect(showResults)
remotes.Celebration.OnClientEvent:Connect(function(userId, displayName)
	showNotification("ПОБЕДИТЕЛЬ: " .. tostring(displayName), "success")
	local world = Workspace:FindFirstChild("AeroRushWorld")
	local drones = world and world:FindFirstChild("Drones")
	local drone = drones and drones:FindFirstChild("Drone_" .. tostring(userId))
	local root = drone and drone.PrimaryPart
	if not root then
		return
	end
	local attachment = Instance.new("Attachment")
	attachment.Parent = root
	local particles = Instance.new("ParticleEmitter")
	particles.Name = "WinnerConfetti"
	particles.Rate = 0
	particles.Lifetime = NumberRange.new(1.5, 3.5)
	particles.Speed = NumberRange.new(9, 18)
	particles.SpreadAngle = Vector2.new(180, 180)
	particles.Rotation = NumberRange.new(0, 360)
	particles.RotSpeed = NumberRange.new(-220, 220)
	particles.Size = NumberSequence.new(0.32)
	particles.Color = ColorSequence.new(COLORS.Cyan, COLORS.Pink)
	particles.LightEmission = 0.45
	particles.Parent = attachment
	particles:Emit(110)
	task.delay(6, function()
		attachment:Destroy()
	end)
end)
local function temporaryPart(shape, size, cframe, color, transparency, lifetime)
	local part = Instance.new("Part")
	part.Shape = shape
	part.Size = size
	part.CFrame = cframe
	part.Color = color
	part.Material = Enum.Material.Neon
	part.Transparency = transparency
	part.Anchored = true
	part.CanCollide = false
	part.CanQuery = false
	part.CanTouch = false
	part.CastShadow = false
	part.Parent = Workspace
	task.delay(lifetime, function()
		part:Destroy()
	end)
	return part
end

remotes.CombatFX.OnClientEvent:Connect(function(effect)
	if type(effect) ~= "table" then
		return
	end
	local color = effect.Color or COLORS.Cyan
	if effect.Kind == "Beam" then
		local direction = effect.Destination - effect.Origin
		local length = direction.Magnitude
		if length > 0 and length < 100 then
			local width = effect.Width or 0.35
			temporaryPart(Enum.PartType.Block, Vector3.new(width, width, length), CFrame.lookAt((effect.Origin + effect.Destination) * 0.5, effect.Destination), color, 0.12, 0.16)
		end
	elseif effect.Kind == "Burst" then
		local radius = math.clamp(effect.Radius or 4, 1, 28)
		temporaryPart(Enum.PartType.Ball, Vector3.one * radius * 2, CFrame.new(effect.Position), color, 0.72, 0.24)
	elseif effect.Kind == "Repair" then
		local world = Workspace:FindFirstChild("AeroRushWorld")
		local drones = world and world:FindFirstChild("Drones")
		local drone = drones and drones:FindFirstChild("Drone_" .. tostring(effect.UserId))
		if drone and drone.PrimaryPart then
			local light = Instance.new("PointLight")
			light.Color = color
			light.Brightness = 3
			light.Range = 16
			light.Parent = drone.PrimaryPart
			task.delay(1, function()
				light:Destroy()
			end)
		end
	end
end)

remotes.Checkpoint.OnClientEvent:Connect(function(passed, nextGate, lap)
	if passed == 1 then
		showNotification(string.format("КРУГ %d / %d", math.min(lap, Config.Laps), Config.Laps), "success")
	else
		showNotification(string.format("ГЕЙТ %02d  →  %02d", passed, nextGate), "checkpoint")
	end
end)

raceState:GetAttributeChangedSignal("Phase"):Connect(function()
	if raceState:GetAttribute("Phase") == "Intermission" then
		resultsOverlay.Visible = false
		updateLeaderboard({})
	end
end)

local function keyDown(...)
	for _, key in ipairs({ ... }) do
		if UserInputService:IsKeyDown(key) then
			return true
		end
	end
	return false
end

local function gamepadStick(keyCode)
	for _, input in ipairs(UserInputService:GetGamepadState(Enum.UserInputType.Gamepad1)) do
		if input.KeyCode == keyCode then
			return input.Position
		end
	end
	return Vector3.zero
end

local inputClock = 0
local function sendInput(deltaTime)
	inputClock = inputClock + deltaTime
	if inputClock < 1 / 30 then
		return
	end
	inputClock = 0
	if raceState:GetAttribute("Phase") ~= "Racing" or not player:GetAttribute("Racing") or player:GetAttribute("Finished") then
		return
	end
	if helpOverlay.Visible or resultsOverlay.Visible or UserInputService:GetFocusedTextBox() then
		return
	end

	local leftStick = gamepadStick(Enum.KeyCode.Thumbstick1)
	local rightStick = gamepadStick(Enum.KeyCode.Thumbstick2)
	local x = (keyDown(Enum.KeyCode.D, Enum.KeyCode.Right) and 1 or 0) - (keyDown(Enum.KeyCode.A, Enum.KeyCode.Left) and 1 or 0)
	local y = (keyDown(Enum.KeyCode.W, Enum.KeyCode.Up) and 1 or 0) - (keyDown(Enum.KeyCode.S, Enum.KeyCode.Down) and 1 or 0)
	x = math.clamp(x + leftStick.X, -1, 1)
	y = math.clamp(y + touchMove.Y + leftStick.Y, -1, 1)
	local yaw = (keyDown(Enum.KeyCode.E) and 1 or 0) - (keyDown(Enum.KeyCode.Q) and 1 or 0)
	-- На сенсорном экране горизонталь стика работает как руль, поэтому трасса проходится без отдельных кнопок Q/E.
	yaw = math.clamp(yaw + rightStick.X + touchMove.X, -1, 1)
	remotes.Input:FireServer({
		X = x,
		Y = y,
		Yaw = yaw,
		Up = keyDown(Enum.KeyCode.Space, Enum.KeyCode.ButtonA) or touchFlags.Up,
		Down = keyDown(Enum.KeyCode.LeftControl, Enum.KeyCode.ButtonB) or touchFlags.Down,
		Boost = keyDown(Enum.KeyCode.LeftShift, Enum.KeyCode.ButtonX) or touchFlags.Boost,
	})
end

local cameraFollowing = false
local function updateCamera(deltaTime, ownDrone)
	local camera = Workspace.CurrentCamera
	if not camera then
		return
	end
	if ownDrone and player:GetAttribute("Racing") and raceState:GetAttribute("Phase") ~= "Intermission" then
		local root = ownDrone.PrimaryPart
		camera.CameraType = Enum.CameraType.Scriptable
		local speed = ownDrone:GetAttribute("Speed") or 0
		local desiredPosition = root.Position + root.CFrame:VectorToWorldSpace(Vector3.new(0, 6.5, 18))
		local lookAt = root.Position + root.CFrame.LookVector * 18 + Vector3.new(0, 1.5, 0)
		local target = CFrame.lookAt(desiredPosition, lookAt)
		if cameraFollowing then
			camera.CFrame = camera.CFrame:Lerp(target, 1 - math.exp(-deltaTime * 10))
		else
			camera.CFrame = target
		end
		camera.FieldOfView = camera.FieldOfView + ((70 + math.min(16, speed * 0.11)) - camera.FieldOfView) * (1 - math.exp(-deltaTime * 5))
		cameraFollowing = true
	elseif cameraFollowing then
		cameraFollowing = false
		camera.FieldOfView = 70
		camera.CameraType = Enum.CameraType.Custom
		local character = player.Character
		local humanoid = character and character:FindFirstChildOfClass("Humanoid")
		if humanoid then
			camera.CameraSubject = humanoid
		end
	end
end

local rotorAngle = 0
local hudClock = 0
local function updateHUD(deltaTime, ownDrone)
	hudClock = hudClock + deltaTime
	if hudClock < 0.05 then
		return
	end
	hudClock = 0
	local phase = raceState:GetAttribute("Phase") or "Intermission"
	local racing = player:GetAttribute("Racing") == true
	local finished = player:GetAttribute("Finished") == true
	local now = Workspace:GetServerTimeNow()
	local remaining = math.max(0, math.ceil((raceState:GetAttribute("PhaseEndsAt") or now) - now))

	if phase == "Intermission" then
		phaseTitle.Text = "СЛЕДУЮЩИЙ ЗАЕЗД"
		phaseDetail.Text = string.format("Старт через %d сек · до %d пилотов", remaining, Config.MaxRacers)
	elseif phase == "Countdown" then
		phaseTitle.Text = "ПИЛОТЫ НА СТАРТЕ"
		phaseDetail.Text = Config.TrackName
	elseif phase == "Racing" then
		phaseTitle.Text = "ЗАЕЗД В РЕАЛЬНОМ ВРЕМЕНИ"
		phaseDetail.Text = string.format("Осталось %02d:%02d", math.floor(remaining / 60), remaining % 60)
	else
		phaseTitle.Text = "ФИНИШ"
		phaseDetail.Text = string.format("Новый заезд через %d сек", remaining)
	end

	raceStats.Visible = racing and phase ~= "Intermission"
	speedPanel.Visible = racing and phase ~= "Intermission" and not finished
	resetButton.Visible = racing and phase == "Racing" and not finished
	healthPanel.Visible = racing and phase == "Racing" and not finished and not helpOverlay.Visible and not resultsOverlay.Visible
	gadgetPanel.Visible = racing and phase == "Racing" and not finished and not helpOverlay.Visible and not resultsOverlay.Visible
	countdown.Visible = phase == "Countdown"
	countdownSub.Visible = phase == "Countdown"
	if phase == "Countdown" then
		local value = raceState:GetAttribute("Countdown") or 0
		countdown.Text = value > 0 and tostring(value) or "ВПЕРЁД!"
		countdown.TextColor3 = value <= 1 and COLORS.Cyan or COLORS.White
		countdownSub.Text = "ДЕРЖИ КУРС НА ПЕРВЫЙ ГЕЙТ"
	end

	local lap = player:GetAttribute("Lap") or 1
	local gate = player:GetAttribute("Gate") or 2
	lapLabel.Text = string.format("КРУГ %d / %d", math.max(1, lap), Config.Laps)
	gateLabel.Text = string.format("СЛЕДУЮЩИЙ ГЕЙТ %02d / %02d", gate, #Track.Gates)
	local elapsed = math.max(0, now - (raceState:GetAttribute("RaceStartAt") or now))
	if finished and (player:GetAttribute("FinishTime") or 0) > 0 then
		elapsed = player:GetAttribute("FinishTime")
	end
	if phase == "Racing" or phase == "PostRace" then
		timerLabel.Text = string.format("%02d:%06.3f", math.floor(elapsed / 60), elapsed % 60)
	else
		timerLabel.Text = "00:00.000"
	end
	bestLabel.Text = "ЛУЧШИЙ КРУГ  " .. Config.FormatTime(player:GetAttribute("RaceBestLap") or 0)

	local health = math.clamp(player:GetAttribute("DroneHealth") or 100, 0, 100)
	local shield = math.max(0, player:GetAttribute("DroneShield") or 0)
	healthBar.Size = UDim2.fromScale(health / 100, 1)
	healthBar.BackgroundColor3 = health <= 30 and COLORS.Pink or (health <= 60 and COLORS.Yellow or COLORS.Cyan)
	healthText.Text = tostring(math.ceil(health))
	shieldLabel.Text = shield > 0 and ("ЩИТ " .. math.ceil(shield)) or ""
	local attack = Gadgets.Get(player:GetAttribute("SelectedAttack")) or Gadgets.Get("PulseLaser")
	local defense = Gadgets.Get(player:GetAttribute("SelectedDefense")) or Gadgets.Get("RepairPulse")
	local attackCooldown = math.max(0, player:GetAttribute("AttackCooldown") or 0)
	local defenseCooldown = math.max(0, player:GetAttribute("DefenseCooldown") or 0)
	local attackKey = UserInputService.TouchEnabled and "АТАКА" or "F"
	local defenseKey = UserInputService.TouchEnabled and "ЗАЩИТА" or "G"
	attackButton.Text = attackCooldown > 0.05 and string.format("%s · %.1f С", attackKey, attackCooldown) or (attackKey .. " · " .. attack.Name)
	defenseButton.Text = defenseCooldown > 0.05 and string.format("%s · %.1f С", defenseKey, defenseCooldown) or (defenseKey .. " · " .. defense.Name)
	attackButton.TextColor3 = attack.Color
	defenseButton.TextColor3 = defense.Color

	if ownDrone then
		local speed = ownDrone:GetAttribute("Speed") or 0
		local boost = ownDrone:GetAttribute("Boost") or 0
		speedValue.Text = tostring(math.floor(speed * 1.2 + 0.5))
		boostNumber.Text = tostring(math.floor(boost + 0.5)) .. "%"
		boostBar.Size = UDim2.fromScale(math.clamp(boost / Config.Drone.BoostCapacity, 0, 1), 1)
		boostBar.BackgroundColor3 = boost < 25 and COLORS.Pink or COLORS.Cyan
		if highlightedGate and highlightedGate.PrimaryPart then
			distanceLabel.Text = string.format("ДО ЦЕЛИ  %d М", math.floor((ownDrone.PrimaryPart.Position - highlightedGate.PrimaryPart.Position).Magnitude + 0.5))
		else
			distanceLabel.Text = ""
		end
	end
	if phase == "PostRace" then
		resultsSubtitle.Text = string.format("%s · скрин результата · реванш через %d сек", Config.TrackName, remaining)
	end
	touchControls.Visible = UserInputService.TouchEnabled and racing and phase == "Racing" and not finished and not helpOverlay.Visible and not resultsOverlay.Visible
end

RunService.RenderStepped:Connect(function(deltaTime)
	local ownDrone = getOwnDrone()
	sendInput(deltaTime)
	updateCamera(deltaTime, ownDrone)
	updateTargetHighlight()
	updateHUD(deltaTime, ownDrone)

	rotorAngle = rotorAngle + deltaTime * 34
	for _, blade in ipairs(CollectionService:GetTagged("AeroRushRotor")) do
		local model = blade:FindFirstAncestorOfClass("Model")
		local root = model and model.PrimaryPart
		if root and blade.Parent then
			local offset = Vector3.new(blade:GetAttribute("OffsetX") or 0, blade:GetAttribute("OffsetY") or 0, blade:GetAttribute("OffsetZ") or 0)
			local direction = (blade:GetAttribute("RotorIndex") or 0) % 2 == 0 and -1 or 1
			blade.CFrame = root.CFrame * CFrame.new(offset) * CFrame.Angles(0, rotorAngle * direction, 0)
		end
	end
end)
