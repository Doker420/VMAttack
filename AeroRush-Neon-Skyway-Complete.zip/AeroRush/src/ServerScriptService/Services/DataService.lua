-- Профили, валюта и транзакции. Покупки Robux подтверждаются только после
-- атомарной записи PurchaseId, поэтому повторный ProcessReceipt не дублирует награду.
local DataStoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Catalog = require(Shared:WaitForChild("Catalog"))
local Gadgets = require(Shared:WaitForChild("Gadgets"))
local Tuning = require(Shared:WaitForChild("Tuning"))

local DataService = {}

local cache = {}
local loadTokens = {}
local saveReady = {}
local saveLocks = {}
local memoryReceipts = {}
local store
local closing = false
local onChanged

local function defaults()
	return {
		Wins = 0,
		Races = 0,
		Rating = Config.Rating.StartingRating,
		PeakRating = Config.Rating.StartingRating,
		RatingMatches = 0,
		Eliminations = 0,
		LastRatingDelta = 0,
		Credits = 0,
		Tech = 0,
		LifetimeCoins = 0,
		BestCoinCombo = 0,
		TuningPreset = "Balanced",
		UpgradeLevels = { Engine = 0, Battery = 0, Handling = 0 },
		BestLap = 0,
		XP = 0,
		BoostCreditRaces = 0,
		BoostCreditMultiplier = 2,
		SelectedSkin = "SkinCyan",
		SelectedTrail = "TrailCyan",
		SelectedAttack = "PulseLaser",
		SelectedDefense = "RepairPulse",
		OwnedGadgets = {},
		CaseTokens = 3,
		CaseProgress = 0,
		CasesOpened = 0,
		LegendaryPity = 0,
		OwnedCosmetics = {},
		Receipts = {},
		StarterReceived = false,
		DailyClaims = 0,
		LastDailyClaim = 0,
		QuestDay = "",
		QuestProgress = {},
		QuestRewards = {},
		Achievements = {},
		TotalDonated = 0,
	}
end

local function sanitizeNumber(value, default, maximum)
	if type(value) ~= "number" or value ~= value or value == math.huge or value == -math.huge then
		return default
	end
	return math.clamp(value, 0, maximum)
end

local function sanitizeGadget(value, slot, fallback)
	if type(value) == "string" then
		local gadget = Gadgets.Get(value)
		if gadget and gadget.Slot == slot then
			return gadget.Id
		end
	end
	return fallback
end

local function sanitizeDictionary(value, numericValues, limit)
	local result = {}
	if type(value) ~= "table" then
		return result
	end
	local count = 0
	for key, entry in pairs(value) do
		if count >= limit then
			break
		end
		if type(key) == "string" and #key <= 100 then
			if numericValues and type(entry) == "number" and entry == entry then
				result[key] = sanitizeNumber(entry, 0, 2000000000)
				count = count + 1
			elseif not numericValues and entry == true then
				result[key] = true
				count = count + 1
			end
		end
	end
	return result
end

local function sanitize(value)
	local result = defaults()
	if type(value) ~= "table" then
		return result
	end
	for _, key in ipairs({ "Wins", "Races", "RatingMatches", "Eliminations", "Credits", "Tech", "LifetimeCoins", "BestCoinCombo", "DailyClaims", "TotalDonated" }) do
		result[key] = math.floor(sanitizeNumber(value[key], 0, 1000000000))
	end
	result.Rating = math.floor(math.clamp(sanitizeNumber(value.Rating, Config.Rating.StartingRating, Config.Rating.Maximum), Config.Rating.Minimum, Config.Rating.Maximum))
	result.PeakRating = math.floor(math.clamp(sanitizeNumber(value.PeakRating, result.Rating, Config.Rating.Maximum), Config.Rating.Minimum, Config.Rating.Maximum))
	result.PeakRating = math.max(result.PeakRating, result.Rating)
	if type(value.LastRatingDelta) == "number" and value.LastRatingDelta == value.LastRatingDelta and math.abs(value.LastRatingDelta) ~= math.huge then
		result.LastRatingDelta = math.clamp(math.floor(value.LastRatingDelta), -500, 500)
	end
	result.XP = math.floor(sanitizeNumber(value.XP, 0, 1000000000))
	result.BestLap = sanitizeNumber(value.BestLap, 0, 86400)
	result.LastDailyClaim = math.floor(sanitizeNumber(value.LastDailyClaim, 0, 2000000000))
	result.BoostCreditRaces = math.floor(sanitizeNumber(value.BoostCreditRaces, 0, Config.MaxStoredBoostRaces))
	result.BoostCreditMultiplier = math.clamp(sanitizeNumber(value.BoostCreditMultiplier, 2, 10), 1, 10)
	result.CaseTokens = math.floor(sanitizeNumber(value.CaseTokens, 3, 1000))
	result.CaseProgress = math.floor(sanitizeNumber(value.CaseProgress, 0, 1000))
	result.CasesOpened = math.floor(sanitizeNumber(value.CasesOpened, 0, 1000000000))
	result.LegendaryPity = math.floor(sanitizeNumber(value.LegendaryPity, 0, Gadgets.Case.LegendaryPity))
	result.StarterReceived = value.StarterReceived == true
	result.SelectedSkin = type(value.SelectedSkin) == "string" and string.sub(value.SelectedSkin, 1, 64) or "SkinCyan"
	result.SelectedTrail = type(value.SelectedTrail) == "string" and string.sub(value.SelectedTrail, 1, 64) or "TrailCyan"
	result.TuningPreset = Tuning.GetPreset(value.TuningPreset).Id
	for _, module in ipairs(Tuning.Modules) do
		local level = type(value.UpgradeLevels) == "table" and value.UpgradeLevels[module.Id] or 0
		result.UpgradeLevels[module.Id] = math.floor(sanitizeNumber(level, 0, Tuning.MaxModuleLevel))
	end
	result.SelectedAttack = sanitizeGadget(value.SelectedAttack, "Attack", "PulseLaser")
	result.SelectedDefense = sanitizeGadget(value.SelectedDefense, "Defense", "RepairPulse")
	result.QuestDay = type(value.QuestDay) == "string" and string.sub(value.QuestDay, 1, 16) or ""
	result.OwnedCosmetics = sanitizeDictionary(value.OwnedCosmetics, false, 250)
	result.OwnedGadgets = sanitizeDictionary(value.OwnedGadgets, false, 100)
	result.Receipts = sanitizeDictionary(value.Receipts, true, 5000)
	result.QuestRewards = sanitizeDictionary(value.QuestRewards, false, 100)
	result.Achievements = sanitizeDictionary(value.Achievements, false, 100)
	for _, quest in ipairs(Catalog.Quests) do
		local progress = type(value.QuestProgress) == "table" and value.QuestProgress[quest.Id] or 0
		result.QuestProgress[quest.Id] = sanitizeNumber(progress, 0, 1000000)
	end
	return result
end

local function snapshot(data)
	return sanitize(data)
end

local function apply(player, data)
	local leaderstats = player:FindFirstChild("leaderstats")
	if leaderstats then
		local rating = leaderstats:FindFirstChild("Rating")
		local wins = leaderstats:FindFirstChild("Wins")
		local credits = leaderstats:FindFirstChild("Credits")
		local tech = leaderstats:FindFirstChild("Tech")
		if rating then
			rating.Value = data.Rating
		end
		if wins then
			wins.Value = data.Wins
		end
		if credits then
			credits.Value = data.Credits
		end
		if tech then
			tech.Value = data.Tech
		end
	end
	player:SetAttribute("Rating", data.Rating)
	player:SetAttribute("PeakRating", data.PeakRating)
	player:SetAttribute("RatingMatches", data.RatingMatches)
	player:SetAttribute("Eliminations", data.Eliminations)
	player:SetAttribute("LastRatingDelta", data.LastRatingDelta)
	player:SetAttribute("Wins", data.Wins)
	player:SetAttribute("Races", data.Races)
	player:SetAttribute("Credits", data.Credits)
	player:SetAttribute("Tech", data.Tech)
	player:SetAttribute("LifetimeCoins", data.LifetimeCoins)
	player:SetAttribute("BestCoinCombo", data.BestCoinCombo)
	player:SetAttribute("TuningPreset", data.TuningPreset)
	player:SetAttribute("BestLap", data.BestLap)
	player:SetAttribute("XP", data.XP)
	player:SetAttribute("Level", Catalog.LevelForXP(data.XP))
	player:SetAttribute("CreditBoostRaces", data.BoostCreditRaces)
	player:SetAttribute("CaseTokens", data.CaseTokens)
	player:SetAttribute("SelectedAttack", data.SelectedAttack)
	player:SetAttribute("SelectedDefense", data.SelectedDefense)
	if onChanged and player.Parent then
		onChanged(player)
	end
end

local function createLeaderstats(player)
	local old = player:FindFirstChild("leaderstats")
	if old then
		old:Destroy()
	end
	local leaderstats = Instance.new("Folder")
	leaderstats.Name = "leaderstats"
	local rating = Instance.new("IntValue")
	rating.Name = "Rating"
	rating.Parent = leaderstats
	local wins = Instance.new("IntValue")
	wins.Name = "Wins"
	wins.Parent = leaderstats
	local credits = Instance.new("IntValue")
	credits.Name = "Credits"
	credits.Parent = leaderstats
	local tech = Instance.new("IntValue")
	tech.Name = "Tech"
	tech.Parent = leaderstats
	leaderstats.Parent = player
end

local function acquireLock(userId)
	while saveLocks[userId] do
		task.wait(0.05)
	end
	saveLocks[userId] = true
end

local function applyProduct(data, item)
	if item.Action == "CreditBoost" then
		data.BoostCreditRaces = math.min(Config.MaxStoredBoostRaces, data.BoostCreditRaces + item.Amount)
		data.BoostCreditMultiplier = item.Multiplier
	elseif item.Action == "Credits" then
		data.Credits = data.Credits + item.Amount
	elseif item.Action == "Donation" then
		data.TotalDonated = data.TotalDonated + item.PriceRobux
	end
end

function DataService.SetOnChanged(callback)
	onChanged = callback
end

function DataService.Init()
	if RunService:IsStudio() and not Config.PersistInStudio then
		return
	end
	local ok, result = pcall(function()
		return DataStoreService:GetDataStore(Config.DataStoreName)
	end)
	if ok then
		store = result
	else
		warn("[AERORUSH] DataStore недоступен: " .. tostring(result))
	end

	task.spawn(function()
		while not closing do
			task.wait(Config.AutosaveInterval)
			if not closing then
				for _, player in ipairs(Players:GetPlayers()) do
					task.spawn(DataService.Save, player)
				end
			end
		end
	end)
end

function DataService.Load(player)
	createLeaderstats(player)
	local token = {}
	loadTokens[player.UserId] = token
	saveReady[player.UserId] = false
	local data = defaults()
	cache[player.UserId] = data
	apply(player, data)

	if not store then
		return
	end

	local key = "player_" .. player.UserId
	for attempt = 1, 3 do
		if loadTokens[player.UserId] ~= token or not player.Parent then
			return
		end
		local ok, saved = pcall(function()
			return store:GetAsync(key)
		end)
		if ok then
			if loadTokens[player.UserId] ~= token or not player.Parent then
				return
			end
			data = sanitize(saved)
			cache[player.UserId] = data
			saveReady[player.UserId] = true
			apply(player, data)
			return
		end
		warn(string.format("[AERORUSH] Загрузка %s, попытка %d: %s", player.Name, attempt, tostring(saved)))
		if attempt < 3 then
			task.wait(attempt * 1.5)
		end
	end
end

function DataService.Get(player)
	return cache[player.UserId]
end

function DataService.Commit(player, immediateSave)
	local data = cache[player.UserId]
	if not data then
		return
	end
	apply(player, data)
	if immediateSave then
		task.spawn(DataService.Save, player)
	end
end

function DataService.AddCredits(player, amount, immediateSave)
	local data = cache[player.UserId]
	if not data then
		return 0
	end
	local added = math.max(0, math.floor(amount))
	data.Credits = data.Credits + added
	DataService.Commit(player, immediateSave)
	return added
end

function DataService.AddXP(player, amount, immediateSave)
	local data = cache[player.UserId]
	if not data then
		return 0
	end
	local oldLevel = Catalog.LevelForXP(data.XP)
	data.XP = data.XP + math.max(0, math.floor(amount))
	DataService.Commit(player, immediateSave)
	return Catalog.LevelForXP(data.XP) - oldLevel
end

function DataService.RecordElimination(player)
	local data = cache[player.UserId]
	if not data then
		return 0
	end
	data.Eliminations = data.Eliminations + 1
	DataService.Commit(player, false)
	return data.Eliminations
end

function DataService.ApplyRating(player, delta)
	local data = cache[player.UserId]
	if not data then
		return 0, Config.Rating.StartingRating
	end
	local previous = data.Rating
	data.Rating = math.floor(math.clamp(previous + (tonumber(delta) or 0), Config.Rating.Minimum, Config.Rating.Maximum))
	data.PeakRating = math.max(data.PeakRating, data.Rating)
	data.RatingMatches = data.RatingMatches + 1
	data.LastRatingDelta = data.Rating - previous
	DataService.Commit(player, true)
	return data.LastRatingDelta, data.Rating
end

function DataService.BuyCosmetic(player, cosmetic)
	local data = cache[player.UserId]
	if not data or not cosmetic.CreditPrice then
		return false, "Товар недоступен"
	end
	if data.OwnedCosmetics[cosmetic.Id] then
		return false, "Уже куплено"
	end
	if data.Credits < cosmetic.CreditPrice then
		return false, "Недостаточно кредитов"
	end
	data.Credits = data.Credits - cosmetic.CreditPrice
	data.OwnedCosmetics[cosmetic.Id] = true
	DataService.Commit(player, true)
	return true, "Куплено"
end

function DataService.RecordResult(player, place, bestLap, partyBonus)
	local data = cache[player.UserId]
	if not data then
		data = defaults()
		cache[player.UserId] = data
	end

	data.Races = data.Races + 1
	if place == 1 then
		data.Wins = data.Wins + 1
	end
	local baseReward = math.max(100, 450 - (math.max(1, place) - 1) * 35)
	local boostActive = data.BoostCreditRaces > 0
	local creditMultiplier = boostActive and data.BoostCreditMultiplier or 1
	if boostActive then
		data.BoostCreditRaces = math.max(0, data.BoostCreditRaces - 1)
	end
	partyBonus = math.clamp(partyBonus or 0, 0, Config.FriendBonusCap)
	local reward = math.floor(baseReward * creditMultiplier * (1 + partyBonus) + 0.5)
	data.Credits = data.Credits + reward
	local techReward = math.max(4, 13 - math.max(1, place))
	data.Tech = data.Tech + techReward

	local xp = math.max(80, 190 - (math.max(1, place) - 1) * 12)
	if boostActive then
		xp = math.floor(xp * 1.5)
	end
	data.XP = data.XP + xp

	local isRecord = false
	if bestLap and bestLap > 0 and bestLap < 86400 and (data.BestLap == 0 or bestLap < data.BestLap) then
		data.BestLap = bestLap
		isRecord = true
	end
	DataService.Commit(player, true)
	return reward, isRecord, {
		BaseReward = baseReward,
		BoostActive = boostActive,
		PartyBonus = partyBonus,
		XP = xp,
		Tech = techReward,
	}
end

function DataService.TestGrant(player, item)
	if not RunService:IsStudio() then
		return false
	end
	local data = cache[player.UserId]
	if not data then
		return false
	end
	applyProduct(data, item)
	DataService.Commit(player, false)
	return true
end

function DataService.ProcessReceipt(player, item, purchaseId)
	if type(purchaseId) ~= "string" or #purchaseId < 3 or #purchaseId > 100 then
		return false, false
	end
	if not store and not RunService:IsStudio() then
		return false, false
	end
	-- Сначала фиксируем незаписанный прогресс, чтобы чек не вернул старую копию профиля.
	if store and saveReady[player.UserId] and not DataService.Save(player) then
		return false, false
	end

	if not store then
		local key = player.UserId .. ":" .. purchaseId
		if memoryReceipts[key] then
			return true, false
		end
		memoryReceipts[key] = true
		local data = cache[player.UserId]
		if data then
			applyProduct(data, item)
			DataService.Commit(player, false)
		end
		return true, true
	end

	acquireLock(player.UserId)
	local duplicate = false
	local updated
	local ok, err = pcall(function()
		updated = store:UpdateAsync("player_" .. player.UserId, function(saved)
			local data = sanitize(saved)
			if data.Receipts[purchaseId] then
				duplicate = true
				return data
			end
			data.Receipts[purchaseId] = os.time()
			applyProduct(data, item)
			return data
		end)
	end)
	if ok and updated then
		-- Ответ медленной первичной загрузки уже не должен перезаписать покупку.
		loadTokens[player.UserId] = nil
		if player.Parent or cache[player.UserId] then
			cache[player.UserId] = sanitize(updated)
			saveReady[player.UserId] = true
		end
		if player.Parent then
			apply(player, cache[player.UserId])
		end
		saveLocks[player.UserId] = nil
		return true, not duplicate
	else
		saveLocks[player.UserId] = nil
		warn("[AERORUSH] Чек не сохранён: " .. tostring(err))
		return false, false
	end
end

function DataService.Save(player)
	if not store then
		return true
	end
	if not saveReady[player.UserId] then
		return false
	end
	acquireLock(player.UserId)
	local data = cache[player.UserId]
	if not data or not saveReady[player.UserId] then
		saveLocks[player.UserId] = nil
		return false
	end
	local dataSnapshot = snapshot(data)
	local key = "player_" .. player.UserId
	for attempt = 1, 3 do
		local ok, err = pcall(function()
			store:UpdateAsync(key, function()
				return dataSnapshot
			end)
		end)
		if ok then
			saveLocks[player.UserId] = nil
			return true
		end
		warn(string.format("[AERORUSH] Сохранение %s, попытка %d: %s", player.Name, attempt, tostring(err)))
		if attempt < 3 then
			task.wait(attempt)
		end
	end
	saveLocks[player.UserId] = nil
	return false
end

function DataService.SaveAndClear(player)
	loadTokens[player.UserId] = nil
	DataService.Save(player)
	cache[player.UserId] = nil
	saveReady[player.UserId] = nil
	saveLocks[player.UserId] = nil
end

function DataService.SaveAll()
	closing = true
	local pending = 0
	for _, player in ipairs(Players:GetPlayers()) do
		pending = pending + 1
		task.spawn(function()
			DataService.Save(player)
			pending = pending - 1
		end)
	end
	local started = os.clock()
	while pending > 0 and os.clock() - started < 25 do
		task.wait(0.1)
	end
end

return DataService
