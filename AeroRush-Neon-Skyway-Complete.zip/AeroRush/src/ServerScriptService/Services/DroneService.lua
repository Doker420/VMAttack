-- Серверная аркадная модель дрона. Клиент передаёт только намерение игрока,
-- а положение, скорость, столкновения и boost вычисляются здесь.
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))

local DroneService = {}

local states = {}
local dronesFolder
local raycastParams
local appearanceProvider
local combatProvider

local PINK = Color3.fromRGB(255, 45, 150)
local DARK = Color3.fromRGB(10, 17, 30)
local METAL = Color3.fromRGB(42, 55, 70)

local function makePart(model, name, size, cframe, color, material)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.CFrame = cframe
	part.Color = color
	part.Material = material or Enum.Material.Metal
	part.Anchored = true
	part.CanCollide = false
	part.CanTouch = false
	part.CanQuery = false
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	part.Parent = model
	return part
end

local function addTrail(root, colorA, colorB)
	local left = Instance.new("Attachment")
	left.Name = "TrailLeft"
	left.Position = Vector3.new(-1.4, 0, 2.4)
	left.Parent = root
	local right = Instance.new("Attachment")
	right.Name = "TrailRight"
	right.Position = Vector3.new(1.4, 0, 2.4)
	right.Parent = root

	local trail = Instance.new("Trail")
	trail.Name = "EngineTrail"
	trail.Attachment0 = left
	trail.Attachment1 = right
	trail.Lifetime = 0.22
	trail.MinLength = 0.2
	trail.LightEmission = 0.8
	trail.WidthScale = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.7),
		NumberSequenceKeypoint.new(1, 0),
	})
	trail.Color = ColorSequence.new(colorA, colorB)
	trail.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.2),
		NumberSequenceKeypoint.new(1, 1),
	})
	trail.Parent = root
end

local function buildDrone(player)
	local skin = { Accent = Color3.fromRGB(25, 232, 255), Secondary = PINK }
	local trailStyle = { ColorA = skin.Accent, ColorB = PINK }
	if appearanceProvider then
		local selectedSkin, selectedTrail = appearanceProvider(player)
		if selectedSkin then
			skin = selectedSkin
		end
		if selectedTrail then
			trailStyle = selectedTrail
		end
	end
	local accent = skin.Accent
	local model = Instance.new("Model")
	model.Name = "Drone_" .. player.UserId
	model:SetAttribute("OwnerUserId", player.UserId)
	model:SetAttribute("Speed", 0)
	model:SetAttribute("Boost", Config.Drone.BoostCapacity)
	model:SetAttribute("Active", false)
	CollectionService:AddTag(model, "AeroRushDrone")

	local root = makePart(model, "Root", Vector3.new(4.2, 0.9, 5.2), CFrame.new(), DARK, Enum.Material.Metal)
	model.PrimaryPart = root

	makePart(model, "Canopy", Vector3.new(2.5, 0.8, 2.8), CFrame.new(0, 0.65, -0.35), Color3.fromRGB(25, 75, 95), Enum.Material.Glass)
	makePart(model, "Nose", Vector3.new(2.2, 0.35, 1.5), CFrame.new(0, -0.05, -3), accent, Enum.Material.Neon)
	makePart(model, "RearLight", Vector3.new(2.6, 0.28, 0.35), CFrame.new(0, 0, 2.7), skin.Secondary, Enum.Material.Neon)

	local rotorIndex = 0
	for _, x in ipairs({ -3.8, 3.8 }) do
		for _, z in ipairs({ -3.8, 3.8 }) do
			rotorIndex = rotorIndex + 1
			local motorPosition = Vector3.new(x, 0, z)
			local armLength = motorPosition.Magnitude
			local armCFrame = CFrame.lookAt(motorPosition * 0.5, motorPosition)
			makePart(model, "Arm", Vector3.new(0.48, 0.35, armLength), armCFrame, METAL, Enum.Material.Metal)

			local motor = makePart(model, "Motor", Vector3.new(0.85, 1.35, 1.35), CFrame.new(motorPosition) * CFrame.Angles(0, 0, math.rad(90)), DARK, Enum.Material.Metal)
			motor.Shape = Enum.PartType.Cylinder
			local ring = makePart(model, "MotorRing", Vector3.new(0.25, 1.65, 1.65), CFrame.new(motorPosition + Vector3.new(0, 0.35, 0)) * CFrame.Angles(0, 0, math.rad(90)), accent, Enum.Material.Neon)
			ring.Shape = Enum.PartType.Cylinder

			local blur = makePart(model, "RotorBlur", Vector3.new(0.04, 5.2, 5.2), CFrame.new(motorPosition + Vector3.new(0, 0.85, 0)) * CFrame.Angles(0, 0, math.rad(90)), accent, Enum.Material.SmoothPlastic)
			blur.Shape = Enum.PartType.Cylinder
			blur.Transparency = 0.88

			local bladePosition = motorPosition + Vector3.new(0, 0.86, 0)
			local blade = makePart(model, "Rotor", Vector3.new(5.1, 0.07, 0.28), CFrame.new(bladePosition), Color3.fromRGB(145, 235, 245), Enum.Material.SmoothPlastic)
			blade.Transparency = 0.25
			blade:SetAttribute("OffsetX", bladePosition.X)
			blade:SetAttribute("OffsetY", bladePosition.Y)
			blade:SetAttribute("OffsetZ", bladePosition.Z)
			blade:SetAttribute("RotorIndex", rotorIndex)
			CollectionService:AddTag(blade, "AeroRushRotor")
		end
	end

	local light = Instance.new("PointLight")
	light.Color = accent
	light.Brightness = 1.2
	light.Range = 16
	light.Parent = root
	addTrail(root, trailStyle.ColorA, trailStyle.ColorB)
	return model
end

local function yawFromCFrame(cframe)
	local forward = cframe.LookVector
	return math.atan2(-forward.X, -forward.Z)
end

local function safeNumber(value)
	if type(value) ~= "number" or value ~= value or value == math.huge or value == -math.huge then
		return 0
	end
	return math.clamp(value, -1, 1)
end

function DroneService.Init(world)
	dronesFolder = world.Drones
	raycastParams = RaycastParams.new()
	raycastParams.FilterType = Enum.RaycastFilterType.Include
	raycastParams.FilterDescendantsInstances = { world.Obstacles }
	raycastParams.IgnoreWater = true
end

function DroneService.SetCosmeticsProvider(provider)
	appearanceProvider = provider
end

function DroneService.SetCombatProvider(provider)
	combatProvider = provider
end

function DroneService.Spawn(player, cframe)
	DroneService.Remove(player)
	local model = buildDrone(player)
	model:PivotTo(cframe)
	model.Parent = dronesFolder
	states[player.UserId] = {
		Player = player,
		Model = model,
		Velocity = Vector3.zero,
		Yaw = yawFromCFrame(cframe),
		Input = { X = 0, Y = 0, Up = false, Down = false, Boost = false, Yaw = 0 },
		LastInput = os.clock(),
		Boost = Config.Drone.BoostCapacity,
		Active = false,
		IsBoosting = false,
		AttributeClock = 0,
	}
	model:SetAttribute("Boost", states[player.UserId].Boost)
	return model
end

function DroneService.Remove(player)
	local state = states[player.UserId]
	if state then
		if state.Model then
			state.Model:Destroy()
		end
		states[player.UserId] = nil
	end
end

function DroneService.SetInput(player, payload)
	local state = states[player.UserId]
	if not state or type(payload) ~= "table" then
		return
	end

	local x = safeNumber(payload.X)
	local y = safeNumber(payload.Y)
	local magnitude = math.sqrt(x * x + y * y)
	if magnitude > 1 then
		x = x / magnitude
		y = y / magnitude
	end

	state.Input = {
		X = x,
		Y = y,
		Up = payload.Up == true,
		Down = payload.Down == true,
		Boost = payload.Boost == true,
		Yaw = safeNumber(payload.Yaw),
	}
	state.LastInput = os.clock()
end

function DroneService.SetActive(player, active)
	local state = states[player.UserId]
	if not state then
		return
	end
	state.Active = active
	state.IsBoosting = false
	state.Model:SetAttribute("Active", active)
	if not active then
		state.Velocity = Vector3.zero
		state.Model:SetAttribute("Speed", 0)
	end
end

function DroneService.Reset(player, cframe)
	local state = states[player.UserId]
	if not state or not state.Model or not state.Model.Parent then
		return
	end
	state.Velocity = Vector3.zero
	state.IsBoosting = false
	state.Yaw = yawFromCFrame(cframe)
	state.Boost = math.max(state.Boost, 25)
	state.Model:PivotTo(cframe)
	state.Model:SetAttribute("Speed", 0)
	state.Model:SetAttribute("Boost", state.Boost)
end

function DroneService.GetModel(player)
	local state = states[player.UserId]
	return state and state.Model or nil
end

function DroneService.GetPosition(player)
	local state = states[player.UserId]
	if not state or not state.Model or not state.Model.PrimaryPart then
		return Vector3.zero
	end
	return state.Model.PrimaryPart.Position
end

function DroneService.GetSpeed(player)
	local state = states[player.UserId]
	return state and state.Velocity.Magnitude or 0
end

function DroneService.ApplyImpulse(player, impulse)
	local state = states[player.UserId]
	if state and state.Active and impulse then
		state.Velocity = state.Velocity + impulse
		if state.Velocity.Magnitude > 160 then
			state.Velocity = state.Velocity.Unit * 160
		end
	end
end

function DroneService.IsBoosting(player)
	local state = states[player.UserId]
	return state and state.Active and state.IsBoosting or false
end

function DroneService.Step(deltaTime)
	if not dronesFolder then
		return
	end

	for _, state in pairs(states) do
		if state.Active and state.Model and state.Model.Parent and state.Model.PrimaryPart then
			local input = state.Input
			if os.clock() - state.LastInput > 0.8 then
				input = { X = 0, Y = 0, Up = false, Down = false, Boost = false, Yaw = 0 }
			end

			state.Yaw = state.Yaw - input.Yaw * Config.Drone.YawSpeed * deltaTime
			local orientation = CFrame.Angles(0, state.Yaw, 0)
			local forward = orientation.LookVector
			local right = orientation.RightVector
			local speedMultiplier, boostAllowed = 1, true
			if combatProvider then
				speedMultiplier, boostAllowed = combatProvider(state.Player)
			end
			local boosting = input.Boost and input.Y > 0.2 and state.Boost > 0.5 and boostAllowed
			state.IsBoosting = boosting
			local topSpeed = (boosting and Config.Drone.BoostSpeed or Config.Drone.MaxSpeed) * speedMultiplier

			if boosting then
				state.Boost = math.max(0, state.Boost - Config.Drone.BoostDrain * deltaTime)
			else
				state.Boost = math.min(Config.Drone.BoostCapacity, state.Boost + Config.Drone.BoostRecharge * deltaTime)
			end

			local forwardInput = input.Y
			local forwardSpeed = topSpeed
			if forwardInput < 0 then
				forwardSpeed = Config.Drone.ReverseSpeed * speedMultiplier
			end
			local targetHorizontal = (forward * forwardInput * forwardSpeed + right * input.X * topSpeed)
			local verticalInput = (input.Up and 1 or 0) - (input.Down and 1 or 0)
			local targetVertical = verticalInput * Config.Drone.VerticalSpeed

			local currentHorizontal = Vector3.new(state.Velocity.X, 0, state.Velocity.Z)
			local horizontalAlpha = 1 - math.exp(-Config.Drone.Acceleration * deltaTime)
			local verticalAlpha = 1 - math.exp(-Config.Drone.VerticalAcceleration * deltaTime)
			currentHorizontal = currentHorizontal:Lerp(targetHorizontal, horizontalAlpha)
			local vertical = state.Velocity.Y + (targetVertical - state.Velocity.Y) * verticalAlpha
			state.Velocity = Vector3.new(currentHorizontal.X, vertical, currentHorizontal.Z)

			local oldPosition = state.Model.PrimaryPart.Position
			local newPosition = oldPosition + state.Velocity * deltaTime
			local motion = newPosition - oldPosition
			if motion.Magnitude > 0.001 then
				local hit = Workspace:Raycast(oldPosition, motion.Unit * (motion.Magnitude + Config.Drone.CollisionRadius), raycastParams)
				if hit then
					newPosition = hit.Position + hit.Normal * Config.Drone.CollisionRadius
					state.Velocity = state.Velocity * 0.16
					state.Model:SetAttribute("ImpactAt", os.clock())
				end
			end

			local pitch = math.rad(-13) * input.Y
			local roll = math.rad(-11) * input.X
			local cframe = CFrame.new(newPosition) * CFrame.Angles(pitch, state.Yaw, roll)
			state.Model:PivotTo(cframe)

			state.AttributeClock = state.AttributeClock + deltaTime
			if state.AttributeClock >= 0.08 then
				state.AttributeClock = 0
				state.Model:SetAttribute("Speed", state.Velocity.Magnitude)
				state.Model:SetAttribute("Boost", state.Boost)
			end
		end
	end
end

return DroneService
