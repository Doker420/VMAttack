-- Бесплатные награды, задания, уровни, достижения и социальный бонус.
local BadgeService = game:GetService("BadgeService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Catalog = require(Shared:WaitForChild("Catalog"))

local EngagementService = {}

local DataService
local ShopService
local remotes
local friendBonus = {}
local knownLevels = {}
local boostClock = {}

local function notify(player, text, kind)
	if player.Parent then
		remotes.Notify:FireClient(player, text, kind or "info")
	end
end

local function awardBadge(userId, badgeId)
	if badgeId <= 0 or RunService:IsStudio() then
		return
	end
	task.spawn(function()
		local ok, err = pcall(function()
			BadgeService:AwardBadge(userId, badgeId)
		end)
		if not ok then
			warn("[AERORUSH] Badge: " .. tostring(err))
		end
	end)
end

local function ensureQuestDay(player)
	local data = DataService.Get(player)
	if not data then
		return nil
	end
	local day = tostring(os.date("!%Y-%m-%d", os.time()))
	if data.QuestDay ~= day then
		data.QuestDay = day
		data.QuestRewards = {}
		for _, quest in ipairs(Catalog.Quests) do
			data.QuestProgress[quest.Id] = 0
		end
	end
	return data
end

local function checkLevelUp(player)
	local data = DataService.Get(player)
	if not data then
		return
	end
	local level = Catalog.LevelForXP(data.XP)
	local previous = knownLevels[player.UserId] or level
	if level > previous then
		notify(player, string.format("Новый уровень: %d! Проверьте награды в гараже", level), "success")
	end
	knownLevels[player.UserId] = level
end

local function checkQuests(player, data)
	for _, quest in ipairs(Catalog.Quests) do
		if not data.QuestRewards[quest.Id] and (data.QuestProgress[quest.Id] or 0) >= quest.Target then
			data.QuestRewards[quest.Id] = true
			data.Credits = data.Credits + quest.Reward
			data.XP = data.XP + quest.XP
			notify(player, string.format("Задание «%s»: +%d кредитов", quest.Name, quest.Reward), "success")
		end
	end
end

local function checkAchievements(player, data)
	local level = Catalog.LevelForXP(data.XP)
	if data.Races >= 1 and not data.Achievements.FirstFinish then
		data.Achievements.FirstFinish = true
		data.Credits = data.Credits + 300
		awardBadge(player.UserId, Catalog.Badges.FirstFinish)
		notify(player, "Достижение «Первый финиш»: +300 кредитов", "success")
	end
	if data.Wins >= 1 and not data.Achievements.FirstWin then
		data.Achievements.FirstWin = true
		data.Credits = data.Credits + 500
		awardBadge(player.UserId, Catalog.Badges.FirstWin)
		notify(player, "Достижение «Лидер небес»: +500 кредитов", "success")
	end
	if level >= 5 and not data.Achievements.Level5 then
		data.Achievements.Level5 = true
		awardBadge(player.UserId, Catalog.Badges.Level5)
		notify(player, "Достижение «Элитный пилот»: след ELITE открыт", "success")
	end
	if data.LifetimeCoins >= 50 and not data.Achievements.Coin50 then
		data.Achievements.Coin50 = true
		data.Credits = data.Credits + 400
		notify(player, "Достижение «Охотник за монетами»: +400 кредитов", "success")
	end
	if data.BestCoinCombo >= 10 and not data.Achievements.CoinCombo10 then
		data.Achievements.CoinCombo10 = true
		data.Tech = data.Tech + 20
		notify(player, "Достижение «Серия ×10»: +20 TECH", "success")
	end
end

local function commitProgress(player, data, immediateSave)
	checkQuests(player, data)
	checkAchievements(player, data)
	DataService.Commit(player, immediateSave)
	checkLevelUp(player)
end

function EngagementService.RefreshFriends(player)
	if not player.Parent then
		return
	end
	local count = 0
	for _, other in ipairs(Players:GetPlayers()) do
		if other ~= player then
			local ok, isFriend = pcall(function()
				return player:IsFriendsWith(other.UserId)
			end)
			if not player.Parent then
				return
			end
			if ok and isFriend then
				count = count + 1
			end
		end
	end
	local bonus = math.min(Config.FriendBonusCap, count * Config.FriendBonusPerFriend)
	friendBonus[player.UserId] = bonus
	player:SetAttribute("FriendBonus", bonus)
	ShopService.SendProfile(player)
end

function EngagementService.OnPlayerAdded(player)
	friendBonus[player.UserId] = 0
	knownLevels[player.UserId] = 1
	boostClock[player.UserId] = 0
	player:SetAttribute("FriendBonus", 0)
	task.spawn(function()
		EngagementService.RefreshFriends(player)
		for _, other in ipairs(Players:GetPlayers()) do
			if other ~= player then
				task.spawn(EngagementService.RefreshFriends, other)
			end
		end
	end)
end

function EngagementService.OnProfileLoaded(player)
	local data = ensureQuestDay(player)
	if not data then
		return
	end
	if not data.StarterReceived then
		data.StarterReceived = true
		data.Credits = data.Credits + Config.StartingCredits
		data.SelectedSkin = Catalog.DefaultSkins[player.UserId % #Catalog.DefaultSkins + 1]
		notify(player, string.format("Стартовый подарок: %d кредитов!", Config.StartingCredits), "success")
	end
	knownLevels[player.UserId] = Catalog.LevelForXP(data.XP)
	DataService.Commit(player, true)
	EngagementService.RefreshFriends(player)
end

function EngagementService.OnPlayerRemoving(player)
	friendBonus[player.UserId] = nil
	knownLevels[player.UserId] = nil
	boostClock[player.UserId] = nil
	for _, other in ipairs(Players:GetPlayers()) do
		if other ~= player then
			task.spawn(EngagementService.RefreshFriends, other)
		end
	end
end

function EngagementService.OnGate(player)
	local data = ensureQuestDay(player)
	if not data then
		return
	end
	data.QuestProgress.Gates = (data.QuestProgress.Gates or 0) + 1
	commitProgress(player, data, false)
end

function EngagementService.OnCoin(player)
	local data = ensureQuestDay(player)
	if not data then
		return
	end
	data.QuestProgress.Coins = (data.QuestProgress.Coins or 0) + 1
	commitProgress(player, data, false)
end

function EngagementService.OnBoost(player, deltaTime)
	local data = ensureQuestDay(player)
	if not data then
		return
	end
	data.QuestProgress.BoostSeconds = math.min(1000000, (data.QuestProgress.BoostSeconds or 0) + deltaTime)
	boostClock[player.UserId] = (boostClock[player.UserId] or 0) + deltaTime
	local completed = not data.QuestRewards.BoostSeconds and data.QuestProgress.BoostSeconds >= 45
	if boostClock[player.UserId] >= 5 or completed then
		boostClock[player.UserId] = 0
		commitProgress(player, data, false)
	end
end

function EngagementService.OnFinish(player, place, bestLap)
	local data = ensureQuestDay(player)
	local bonus = friendBonus[player.UserId] or 0
	local reward, isRecord, info = DataService.RecordResult(player, place, bestLap, bonus)
	data = ensureQuestDay(player)
	if data then
		data.CaseProgress = data.CaseProgress + 1
		if data.CaseProgress >= 2 then
			data.CaseProgress = data.CaseProgress - 2
			data.CaseTokens = data.CaseTokens + 1
			notify(player, "Получен жетон ТЕХНО-КЕЙСА за 2 финиша", "success")
		end
		data.QuestProgress.Finishes = (data.QuestProgress.Finishes or 0) + 1
		if bonus > 0 then
			data.QuestProgress.SocialRaces = (data.QuestProgress.SocialRaces or 0) + 1
		end
		commitProgress(player, data, true)
	end
	return reward, isRecord, info
end

function EngagementService.ClaimDaily(player)
	local data = ensureQuestDay(player)
	if not data then
		return
	end
	local now = os.time()
	local remaining = Config.DailyCooldown - (now - data.LastDailyClaim)
	if data.LastDailyClaim > 0 and remaining > 0 then
		notify(player, string.format("Следующий подарок через %d ч %02d мин", math.floor(remaining / 3600), math.floor(remaining % 3600 / 60)), "info")
		return
	end
	local day = data.DailyClaims % #Catalog.DailyRewards + 1
	local reward = Catalog.DailyRewards[day]
	data.DailyClaims = data.DailyClaims + 1
	data.LastDailyClaim = now
	data.Credits = data.Credits + reward.Credits
	data.XP = data.XP + 50
	if reward.BoostRaces then
		data.BoostCreditRaces = math.min(Config.MaxStoredBoostRaces, data.BoostCreditRaces + reward.BoostRaces)
	end
	if reward.CaseTokens then
		data.CaseTokens = data.CaseTokens + reward.CaseTokens
	end
	checkAchievements(player, data)
	DataService.Commit(player, true)
	checkLevelUp(player)
	local message = string.format("Ежедневный подарок: +%d кредитов и +50 XP", reward.Credits)
	if reward.CaseTokens then
		message = message .. string.format(" · +%d жетон", reward.CaseTokens)
	end
	notify(player, message, "success")
end

function EngagementService.HandleAction(player, action)
	if action == "ClaimDaily" then
		EngagementService.ClaimDaily(player)
	elseif action == "Refresh" then
		ensureQuestDay(player)
		ShopService.SendProfile(player)
	end
end

function EngagementService.Init(dependencies)
	DataService = dependencies.DataService
	ShopService = dependencies.ShopService
	remotes = dependencies.Remotes
end

return EngagementService
