-- Серверная нелетальная гоночная combat-система и бесплатные техно-кейсы.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Gadgets = require(Shared:WaitForChild("Gadgets"))

local CombatService = {}

local DataService
local DroneService
local remotes
local hazardsFolder
local raycastParams
local states = {}
local hazards = {}
local random = Random.new()
local raceActive = false
local lastActions = {}
local eliminationHandler

local function now()
	return os.clock()
end

local function notify(player, text, kind)
	if player.Parent then
		remotes.Notify:FireClient(player, text, kind or "info")
	end
end

local function ownsGadget(player, gadget)
	if gadget.Free then
		return true
	end
	local data = DataService.Get(player)
	if not data then
		return false
	end
	return data.OwnedGadgets[gadget.Id] == true or (gadget.UnlockRaces and data.Races >= gadget.UnlockRaces) or false
end

local function sync(state)
	local player = state.Player
	player:SetAttribute("DroneHealth", math.max(0, math.floor(state.Health + 0.5)))
	player:SetAttribute("DroneShield", math.max(0, math.floor(state.Shield + 0.5)))
	local model = DroneService.GetModel(player)
	if model then
		model:SetAttribute("Health", state.Health)
		model:SetAttribute("Shield", state.Shield)
		model:SetAttribute("HitAt", state.LastDamage)
	end
end

local function ensureState(player)
	local state = states[player.UserId]
	if state then
		return state
	end
	state = {
		Player = player,
		Health = 100,
		Shield = 0,
		ShieldUntil = 0,
		AttackCooldown = 0,
		DefenseCooldown = 0,
		BlasterCooldown = 0,
		SlowUntil = 0,
		SlowMultiplier = 1,
		BoostDisabledUntil = 0,
		InvulnerableUntil = now() + 3,
		LastDamage = 0,
		PendingReboot = false,
		AttributeClock = 0,
	}
	states[player.UserId] = state
	sync(state)
	return state
end

local function removeHazard(hazard)
	if hazard.Model then
		hazard.Model:Destroy()
	end
	if hazards[hazard.Id] then
		hazards[hazard.Id] = nil
	end
end

local function clearHazards()
	for _, hazard in pairs(hazards) do
		if hazard.Model then
			hazard.Model:Destroy()
		end
	end
	table.clear(hazards)
end

local function makePart(parent, name, size, cframe, color, transparency)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.CFrame = cframe
	part.Color = color
	part.Material = Enum.Material.Neon
	part.Transparency = transparency or 0
	part.Anchored = true
	part.CanCollide = false
	part.CanTouch = false
	part.CanQuery = false
	part.Parent = parent
	return part
end

local function spawnHazard(owner, kind, position, radius, duration)
	local model = Instance.new("Model")
	model.Name = kind .. "_" .. owner.UserId .. "_" .. tostring(now())
	local color = kind == "Spike" and Color3.fromRGB(91, 255, 151) or (kind == "Glue" and Color3.fromRGB(74, 157, 255) or Color3.fromRGB(190, 92, 255))
	if kind == "Spike" then
		for index = 1, 7 do
			local angle = index / 7 * math.pi * 2
			local spike = Instance.new("WedgePart")
			spike.Name = "EnergySpike"
			spike.Size = Vector3.new(1.4, 2.4, 1.4)
			spike.CFrame = CFrame.new(position + Vector3.new(math.cos(angle) * 4, 0, math.sin(angle) * 4)) * CFrame.Angles(0, -angle, 0)
			spike.Color = color
			spike.Material = Enum.Material.Neon
			spike.Anchored = true
			spike.CanCollide = false
			spike.CanQuery = false
			spike.CanTouch = false
			spike.CastShadow = false
			spike.Parent = model
		end
		local zone = makePart(model, "DangerZone", Vector3.new(0.15, radius * 2, radius * 2), CFrame.new(position) * CFrame.Angles(0, 0, math.rad(90)), color, 0.72)
		zone.Shape = Enum.PartType.Cylinder
	elseif kind == "Glue" then
		local puddle = makePart(model, "Glue", Vector3.new(0.3, radius * 2, radius * 2), CFrame.new(position) * CFrame.Angles(0, 0, math.rad(90)), color, 0.22)
		puddle.Shape = Enum.PartType.Cylinder
	else
		local sphere = makePart(model, "GravityField", Vector3.one * radius * 2, CFrame.new(position), color, 0.82)
		sphere.Shape = Enum.PartType.Ball
		local light = Instance.new("PointLight")
		light.Color = color
		light.Range = 35
		light.Brightness = 2
		light.Parent = sphere
	end
	model.Parent = hazardsFolder
	local id = tostring(owner.UserId) .. ":" .. tostring(now()) .. ":" .. tostring(random:NextInteger(1, 1000000))
	hazards[id] = {
		Id = id,
		Kind = kind,
		OwnerId = owner.UserId,
		Position = position,
		Radius = radius,
		Expires = now() + duration,
		Model = model,
		Hit = {},
	}
	-- Не больше трёх активных ловушек каждого вида на игрока.
	local owned = {}
	for _, hazard in pairs(hazards) do
		if hazard.OwnerId == owner.UserId and hazard.Kind == kind then
			table.insert(owned, hazard)
		end
	end
	table.sort(owned, function(a, b)
		return a.Expires < b.Expires
	end)
	for index = 1, math.max(0, #owned - 3) do
		removeHazard(owned[index])
	end
end

local function applyDamage(source, target, amount, slowMultiplier, slowDuration, boostDisable)
	if source == target or not raceActive or not target:GetAttribute("Racing") or target:GetAttribute("Finished") then
		return false
	end
	local state = states[target.UserId]
	if not state or state.PendingReboot or now() < state.InvulnerableUntil then
		return false
	end
	local currentTime = now()
	local remaining = amount
	if state.Shield > 0 then
		local absorbed = math.min(state.Shield, remaining)
		state.Shield = state.Shield - absorbed
		remaining = remaining - absorbed
	end
	state.Health = math.max(0, state.Health - remaining)
	state.LastDamage = currentTime
	if slowMultiplier and slowDuration then
		state.SlowMultiplier = math.min(state.SlowMultiplier, slowMultiplier)
		state.SlowUntil = math.max(state.SlowUntil, currentTime + slowDuration)
	end
	if boostDisable then
		state.BoostDisabledUntil = math.max(state.BoostDisabledUntil, currentTime + boostDisable)
	end
	if state.Health <= 0 then
		state.PendingReboot = true
		remotes.CombatFX:FireAllClients({
			Kind = "Elimination",
			Position = DroneService.GetPosition(target),
			SourceUserId = source and source.UserId or 0,
			TargetUserId = target.UserId,
		})
		if eliminationHandler then
			eliminationHandler(source, target)
		end
		notify(target, "Дрон перегружен — перезагрузка на последнем гейте", "warning")
	end
	sync(state)
	return true
end

local function validTarget(player)
	return player:GetAttribute("Racing") and not player:GetAttribute("Finished") and states[player.UserId] and not states[player.UserId].PendingReboot
end

local function beamTargets(attacker, range, width)
	local model = DroneService.GetModel(attacker)
	local root = model and model.PrimaryPart
	if not root then
		return {}, root, root and root.Position or Vector3.zero
	end
	local origin = root.Position + root.CFrame.LookVector * 5
	local forward = root.CFrame.LookVector
	local result = {}
	for _, target in ipairs(Players:GetPlayers()) do
		if target ~= attacker and validTarget(target) then
			local targetModel = DroneService.GetModel(target)
			local targetRoot = targetModel and targetModel.PrimaryPart
			if targetRoot then
				local offset = targetRoot.Position - origin
				local along = offset:Dot(forward)
				if along > 0 and along <= range then
					local distance = (offset - forward * along).Magnitude
					if distance <= width then
						local obstruction = Workspace:Raycast(origin, forward * along, raycastParams)
						if not obstruction or obstruction.Distance > along - 4 then
							table.insert(result, { Player = target, Distance = along })
						end
					end
				end
			end
		end
	end
	table.sort(result, function(a, b)
		return a.Distance < b.Distance
	end)
	return result, root, origin
end

local function useAttack(player, gadget)
	local model = DroneService.GetModel(player)
	local root = model and model.PrimaryPart
	if not root then
		return false
	end
	local rarityColor = Gadgets.Rarities[gadget.Rarity].Color
	if gadget.Id == "PulseLaser" or gadget.Id == "RailLaser" then
		local isRail = gadget.Id == "RailLaser"
		local targets, _, origin = beamTargets(player, isRail and 170 or 110, isRail and 6 or 5)
		local destination = origin + root.CFrame.LookVector * (isRail and 170 or 110)
		if #targets > 0 then
			if not isRail then
				destination = origin + root.CFrame.LookVector * targets[1].Distance
			end
			for _, entry in ipairs(targets) do
				applyDamage(player, entry.Player, isRail and 22 or 16, isRail and 0.8 or 0.88, isRail and 1.5 or 1)
				if not isRail then
					break
				end
			end
		end
		remotes.CombatFX:FireAllClients({ Kind = "Beam", Origin = origin, Destination = destination, Color = rarityColor, Width = isRail and 1.2 or 0.55 })
	elseif gadget.Id == "SpikeTrap" or gadget.Id == "GlueMine" then
		local position = root.Position - root.CFrame.LookVector * 9
		spawnHazard(player, gadget.Id == "SpikeTrap" and "Spike" or "Glue", position, gadget.Id == "SpikeTrap" and 7 or 8, 25)
		remotes.CombatFX:FireAllClients({ Kind = "Drop", Position = position, Color = rarityColor })
	elseif gadget.Id == "EMPBurst" then
		for _, target in ipairs(Players:GetPlayers()) do
			if target ~= player and validTarget(target) then
				local offset = DroneService.GetPosition(target) - root.Position
				if offset.Magnitude <= 45 then
					applyDamage(player, target, 10, nil, nil, 3)
				end
			end
		end
		remotes.CombatFX:FireAllClients({ Kind = "Burst", Position = root.Position, Radius = 45, Color = rarityColor })
	elseif gadget.Id == "GravityWell" then
		local position = root.Position + root.CFrame.LookVector * 55
		spawnHazard(player, "Gravity", position, 34, 5)
		remotes.CombatFX:FireAllClients({ Kind = "Burst", Position = position, Radius = 34, Color = rarityColor })
	end
	return true
end

local function useDefense(player, gadget)
	local state = states[player.UserId]
	if gadget.Id == "RepairPulse" then
		if state.Health >= 100 then
			notify(player, "Прочность уже полная", "info")
			return false
		end
		state.Health = math.min(100, state.Health + 30)
	elseif gadget.Id == "AegisShield" then
		state.Shield = math.min(60, state.Shield + 40)
		state.ShieldUntil = now() + 6
	elseif gadget.Id == "PhoenixProtocol" then
		if state.Health >= 100 and state.Shield >= 20 then
			notify(player, "Ремонт сейчас не требуется", "info")
			return false
		end
		state.Health = math.min(100, state.Health + 35)
		state.Shield = math.min(60, state.Shield + 20)
		state.ShieldUntil = now() + 6
	end
	sync(state)
	remotes.CombatFX:FireAllClients({ Kind = "Repair", UserId = player.UserId, Color = Gadgets.Rarities[gadget.Rarity].Color })
	return true
end

function CombatService.FireBlaster(player)
	if not raceActive or not player:GetAttribute("Racing") or player:GetAttribute("Finished") then
		return false
	end
	local state = states[player.UserId]
	if not state or state.PendingReboot or now() < state.BlasterCooldown then
		return false
	end
	local model = DroneService.GetModel(player)
	local root = model and model.PrimaryPart
	if not root then
		return false
	end

	state.BlasterCooldown = now() + Config.Blaster.Cooldown
	player:SetAttribute("BlasterCooldown", Config.Blaster.Cooldown)
	local targets, _, origin = beamTargets(player, Config.Blaster.Range, Config.Blaster.Width)
	local destination = origin + root.CFrame.LookVector * Config.Blaster.Range
	local hitTarget
	if #targets > 0 then
		local target = targets[1].Player
		destination = origin + root.CFrame.LookVector * targets[1].Distance
		if applyDamage(player, target, Config.Blaster.Damage) then
			hitTarget = target
		end
	end
	remotes.CombatFX:FireAllClients({
		Kind = "Beam",
		Origin = origin,
		Destination = destination,
		Color = Color3.fromRGB(110, 245, 255),
		Width = 0.32,
	})
	if hitTarget then
		remotes.CombatFX:FireClient(player, { Kind = "HitMarker", TargetName = hitTarget.DisplayName })
	end
	return true
end

function CombatService.UseGadget(player, slot)
	if not raceActive or not player:GetAttribute("Racing") or player:GetAttribute("Finished") then
		return
	end
	local state = states[player.UserId]
	local data = DataService.Get(player)
	if not state or not data or state.PendingReboot or not DroneService.GetModel(player) then
		return
	end
	local gadget = Gadgets.Get(slot == "Attack" and data.SelectedAttack or data.SelectedDefense)
	if not gadget or gadget.Slot ~= slot or not ownsGadget(player, gadget) then
		return
	end
	local field = slot == "Attack" and "AttackCooldown" or "DefenseCooldown"
	if now() < state[field] then
		return
	end
	local success = slot == "Attack" and useAttack(player, gadget) or useDefense(player, gadget)
	if success then
		state[field] = now() + gadget.Cooldown
		player:SetAttribute(field, gadget.Cooldown)
	end
end

function CombatService.GetMovementModifiers(player)
	local state = states[player.UserId]
	if not state then
		return 1, true
	end
	if state.PendingReboot then
		return 0, false
	end
	local speed = now() < state.SlowUntil and state.SlowMultiplier or 1
	if now() >= state.SlowUntil then
		state.SlowMultiplier = 1
	end
	return speed, now() >= state.BoostDisabledUntil
end

function CombatService.NeedsReboot(player)
	local state = states[player.UserId]
	return state and state.PendingReboot or false
end

function CombatService.OnRespawn(player, fullHeal, invulnerabilityDuration)
	local state = ensureState(player)
	if fullHeal then
		state.Health = 100
		state.Shield = 0
		state.ShieldUntil = 0
	end
	state.PendingReboot = false
	state.SlowUntil = 0
	state.SlowMultiplier = 1
	state.BoostDisabledUntil = 0
	state.InvulnerableUntil = now() + (invulnerabilityDuration or 0)
	sync(state)
end

local function canManageLoadout(player)
	return ReplicatedStorage.AeroRushState:GetAttribute("Phase") == "Intermission"
		or player:GetAttribute("Racing") ~= true
		or player:GetAttribute("Finished") == true
end

function CombatService.OpenCase(player)
	if not canManageLoadout(player) then
		return
	end
	local data = DataService.Get(player)
	if not data then
		return
	end
	if data.CaseTokens < 1 then
		notify(player, "Получите жетон за каждые 2 финиша", "warning")
		return
	end
	data.CaseTokens = data.CaseTokens - 1
	data.CasesOpened = data.CasesOpened + 1
	local rarity
	if data.LegendaryPity >= Gadgets.Case.LegendaryPity - 1 then
		rarity = "Legendary"
	else
		local roll = random:NextInteger(1, 100)
		rarity = roll <= Gadgets.Case.Odds.Green and "Green" or (roll <= Gadgets.Case.Odds.Green + Gadgets.Case.Odds.Blue and "Blue" or "Legendary")
	end
	local pool = Gadgets.ForRarity(rarity)
	local gadget = pool[random:NextInteger(1, #pool)]
	local duplicate = ownsGadget(player, gadget)
	local compensation = 0
	if duplicate then
		compensation = Gadgets.Case.DuplicateCredits[rarity]
		data.Credits = data.Credits + compensation
	else
		data.OwnedGadgets[gadget.Id] = true
	end
	if rarity == "Legendary" then
		data.LegendaryPity = 0
	else
		data.LegendaryPity = data.LegendaryPity + 1
	end
	DataService.Commit(player, true)
	remotes.CaseOpened:FireClient(player, {
		GadgetId = gadget.Id,
		Rarity = rarity,
		Duplicate = duplicate,
		Compensation = compensation,
		LegendaryPity = data.LegendaryPity,
	})
	notify(player, duplicate and string.format("Дубликат %s: +%d кредитов", gadget.Name, compensation) or ("Открыт гаджет: " .. gadget.Name), "success")
end

function CombatService.HandleAction(player, action, value)
	if type(action) ~= "string" then
		return
	end
	local actionKey = (action == "UseAttack" or action == "UseDefense" or action == "FireBlaster") and "Use" or action
	local current = now()
	local cooldown = actionKey == "Use" and 0.1 or 0.35
	if current - (lastActions[player.UserId] or 0) < cooldown then
		return
	end
	lastActions[player.UserId] = current
	if action == "FireBlaster" then
		CombatService.FireBlaster(player)
	elseif action == "UseAttack" then
		CombatService.UseGadget(player, "Attack")
	elseif action == "UseDefense" then
		CombatService.UseGadget(player, "Defense")
	elseif action == "OpenCase" then
		CombatService.OpenCase(player)
	elseif action == "Equip" and type(value) == "string" then
		if not canManageLoadout(player) then
			return
		end
		local gadget = Gadgets.Get(value)
		local data = DataService.Get(player)
		if gadget and data and ownsGadget(player, gadget) then
			if gadget.Slot == "Attack" then
				data.SelectedAttack = gadget.Id
			else
				data.SelectedDefense = gadget.Id
			end
			DataService.Commit(player, false)
			notify(player, gadget.Name .. " выбран для следующего заезда", "success")
		end
	end
end

function CombatService.StartRace()
	clearHazards()
	table.clear(states)
	raceActive = true
	for _, player in ipairs(Players:GetPlayers()) do
		if player:GetAttribute("Racing") then
			ensureState(player)
			player:SetAttribute("AttackCooldown", 0)
			player:SetAttribute("DefenseCooldown", 0)
			player:SetAttribute("BlasterCooldown", 0)
		end
	end
end

function CombatService.EndRace()
	raceActive = false
	clearHazards()
	table.clear(states)
end

function CombatService.Remove(player)
	states[player.UserId] = nil
	lastActions[player.UserId] = nil
	for _, hazard in pairs(hazards) do
		if hazard.OwnerId == player.UserId then
			removeHazard(hazard)
		end
	end
end

function CombatService.Step(deltaTime)
	if not raceActive then
		return
	end
	local current = now()
	for _, state in pairs(states) do
		if current - state.LastDamage >= 7 and not state.PendingReboot then
			state.Health = math.min(100, state.Health + 8 * deltaTime)
		end
		if state.ShieldUntil > 0 and current >= state.ShieldUntil then
			state.Shield = 0
			state.ShieldUntil = 0
		end
		state.AttributeClock = state.AttributeClock + deltaTime
		if state.AttributeClock >= 0.1 then
			state.AttributeClock = 0
			state.Player:SetAttribute("AttackCooldown", math.max(0, state.AttackCooldown - current))
			state.Player:SetAttribute("DefenseCooldown", math.max(0, state.DefenseCooldown - current))
			state.Player:SetAttribute("BlasterCooldown", math.max(0, state.BlasterCooldown - current))
			sync(state)
		end
	end

	for _, hazard in pairs(hazards) do
		if current >= hazard.Expires then
			removeHazard(hazard)
		else
			for _, target in ipairs(Players:GetPlayers()) do
				if target.UserId ~= hazard.OwnerId and validTarget(target) then
					local offset = DroneService.GetPosition(target) - hazard.Position
					if offset.Magnitude <= hazard.Radius then
						if hazard.Kind == "Spike" and not hazard.Hit[target.UserId] then
							if applyDamage(Players:GetPlayerByUserId(hazard.OwnerId), target, 12, 0.65, 1.8) then
								hazard.Hit[target.UserId] = true
							end
						elseif hazard.Kind == "Glue" and not hazard.Hit[target.UserId] then
							if applyDamage(Players:GetPlayerByUserId(hazard.OwnerId), target, 6, 0.5, 2.8) then
								hazard.Hit[target.UserId] = true
							end
						elseif hazard.Kind == "Gravity" then
							local targetState = states[target.UserId]
							if targetState and current >= targetState.InvulnerableUntil then
								if not hazard.Hit[target.UserId] and applyDamage(Players:GetPlayerByUserId(hazard.OwnerId), target, 5, 0.75, 1.2) then
									hazard.Hit[target.UserId] = true
								end
								targetState.SlowMultiplier = math.min(targetState.SlowMultiplier, 0.75)
								targetState.SlowUntil = math.max(targetState.SlowUntil, current + 0.2)
								if offset.Magnitude > 1 then
									DroneService.ApplyImpulse(target, -offset.Unit * 32 * deltaTime)
								end
							end
						end
					end
				end
			end
		end
	end
end

function CombatService.SetEliminationHandler(handler)
	eliminationHandler = handler
end

function CombatService.Init(dependencies)
	DataService = dependencies.DataService
	DroneService = dependencies.DroneService
	remotes = dependencies.Remotes
	hazardsFolder = Instance.new("Folder")
	hazardsFolder.Name = "CombatHazards"
	hazardsFolder.Parent = dependencies.World.Root
	raycastParams = RaycastParams.new()
	raycastParams.FilterType = Enum.RaycastFilterType.Include
	raycastParams.FilterDescendantsInstances = { dependencies.World.Obstacles }
end

return CombatService
