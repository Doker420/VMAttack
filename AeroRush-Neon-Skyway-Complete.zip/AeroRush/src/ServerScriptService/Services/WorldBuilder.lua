-- Процедурно создаёт всю карту: отдельный .rbxl с моделями не требуется.
local Lighting = game:GetService("Lighting")
local Workspace = game:GetService("Workspace")

local Shared = game:GetService("ReplicatedStorage"):WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Track = require(Shared:WaitForChild("Track"))

local WorldBuilder = {}

local COLORS = {
	Navy = Color3.fromRGB(7, 12, 28),
	Panel = Color3.fromRGB(15, 25, 46),
	Cyan = Color3.fromRGB(30, 236, 255),
	Pink = Color3.fromRGB(255, 42, 150),
	Purple = Color3.fromRGB(128, 74, 255),
	White = Color3.fromRGB(225, 246, 255),
}

local sweepers = {}

local function makePart(parent, name, size, cframe, color, material)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.CFrame = cframe
	part.Color = color or COLORS.Panel
	part.Material = material or Enum.Material.SmoothPlastic
	part.Anchored = true
	part.CanCollide = false
	part.CanTouch = false
	part.CanQuery = false
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	part.Parent = parent
	return part
end

local function addGateLabel(root, index, height)
	local labelPart = Instance.new("Part")
	labelPart.Name = "NumberAnchor"
	labelPart.Size = Vector3.one
	labelPart.Transparency = 1
	labelPart.Anchored = true
	labelPart.CanCollide = false
	labelPart.CanTouch = false
	labelPart.CanQuery = false
	labelPart.CFrame = root.CFrame * CFrame.new(0, height / 2 + 4, 0)
	labelPart.Parent = root.Parent

	local billboard = Instance.new("BillboardGui")
	billboard.Name = "GateNumber"
	billboard.Size = UDim2.fromOffset(110, 46)
	billboard.AlwaysOnTop = true
	billboard.MaxDistance = 420
	billboard.Parent = labelPart

	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.GothamBlack
	text.Text = string.format("%02d", index)
	text.TextColor3 = COLORS.White
	text.TextStrokeColor3 = COLORS.Navy
	text.TextStrokeTransparency = 0.15
	text.TextScaled = true
	text.Parent = billboard
end

local function buildGate(parent, index, definition)
	local cframe = Track.GetGateCFrame(index)
	local model = Instance.new("Model")
	model.Name = string.format("Gate_%02d", index)
	model:SetAttribute("Index", index)
	model:SetAttribute("Width", definition.Width)
	model:SetAttribute("Height", definition.Height)
	model.Parent = parent

	local root = makePart(
		model,
		"Root",
		Vector3.new(definition.Width, definition.Height, 2),
		cframe,
		COLORS.Navy
	)
	root.Transparency = 1
	model.PrimaryPart = root

	local accent = index == 1 and COLORS.Pink or (index % 3 == 0 and COLORS.Purple or COLORS.Cyan)
	local thickness = index == 1 and 1.8 or 1.2
	local height = definition.Height
	local width = definition.Width

	makePart(model, "Left", Vector3.new(thickness, height + 2, 1.5), cframe * CFrame.new(-width / 2, 0, 0), accent, Enum.Material.Neon)
	makePart(model, "Right", Vector3.new(thickness, height + 2, 1.5), cframe * CFrame.new(width / 2, 0, 0), accent, Enum.Material.Neon)
	makePart(model, "Top", Vector3.new(width + 2, thickness, 1.5), cframe * CFrame.new(0, height / 2, 0), accent, Enum.Material.Neon)
	makePart(model, "Bottom", Vector3.new(width + 2, thickness, 1.5), cframe * CFrame.new(0, -height / 2, 0), accent, Enum.Material.Neon)

	-- Тёмная внешняя рама придаёт неоновым полосам объём.
	makePart(model, "LeftShell", Vector3.new(2.4, height + 5, 3), cframe * CFrame.new(-width / 2, 0, 1), COLORS.Panel)
	makePart(model, "RightShell", Vector3.new(2.4, height + 5, 3), cframe * CFrame.new(width / 2, 0, 1), COLORS.Panel)
	root.Parent = model
	addGateLabel(root, index, height)

	local light = Instance.new("PointLight")
	light.Color = accent
	light.Brightness = 1.5
	light.Range = 24
	light.Parent = root

	return {
		Model = model,
		CFrame = cframe,
		Width = definition.Width,
		Height = definition.Height,
	}
end

local function buildTrackDecor(decorations, gates)
	-- Голографические стрелки между гейта обозначают racing line.
	for index, gate in ipairs(gates) do
		local nextGate = gates[index % #gates + 1]
		local direction = nextGate.CFrame.Position - gate.CFrame.Position
		local length = direction.Magnitude
		local arrows = math.max(1, math.floor(length / 36))
		for arrowIndex = 1, arrows do
			local alpha = arrowIndex / (arrows + 1)
			local position = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, alpha)
			position = position - Vector3.new(0, 13, 0)
			local cframe = CFrame.lookAt(position, position + direction)
			local left = makePart(decorations, "ChevronLeft", Vector3.new(7, 0.18, 1.1), cframe * CFrame.new(-2.5, 0, 0) * CFrame.Angles(0, math.rad(35), 0), COLORS.Cyan, Enum.Material.Neon)
			local right = makePart(decorations, "ChevronRight", Vector3.new(7, 0.18, 1.1), cframe * CFrame.new(2.5, 0, 0) * CFrame.Angles(0, math.rad(-35), 0), COLORS.Cyan, Enum.Material.Neon)
			left.Transparency = 0.18
			right.Transparency = 0.18
		end

		-- Парящий технический диск под каждым гейтом.
		local disc = makePart(
			decorations,
			"GateDisc",
			Vector3.new(1.2, 18, 18),
			gate.CFrame * CFrame.new(0, -gate.Height / 2 - 8, 0) * CFrame.Angles(0, 0, math.rad(90)),
			COLORS.Panel,
			Enum.Material.Metal
		)
		disc.Shape = Enum.PartType.Cylinder
	end
end

local function buildObstacles(parent, gates)
	-- Статичные пилоны заставляют выбирать траекторию, не перекрывая сами гейты.
	for _, index in ipairs({ 2, 4, 6, 8, 10, 12 }) do
		local gate = gates[index]
		local nextGate = gates[index % #gates + 1]
		local middle = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, 0.5)
		local cframe = CFrame.lookAt(middle, nextGate.CFrame.Position)
		local side = index % 4 == 0 and -1 or 1
		local pylon = makePart(parent, "Pylon", Vector3.new(5, 28, 5), cframe * CFrame.new(side * 13, -3, 0), COLORS.Panel, Enum.Material.Metal)
		pylon.CanCollide = true
		pylon.CanQuery = true
		local stripe = makePart(parent, "PylonStripe", Vector3.new(5.3, 2, 5.3), pylon.CFrame, COLORS.Pink, Enum.Material.Neon)
		stripe.CanQuery = true
	end

	-- Четыре вращающихся сканера. Их положение обновляется на сервере.
	for order, index in ipairs({ 3, 5, 7, 9 }) do
		local gate = gates[index]
		local nextGate = gates[index % #gates + 1]
		local center = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, 0.48) - Vector3.new(0, 2, 0)
		local beam = makePart(parent, "Sweeper", Vector3.new(30, 1.8, 1.8), CFrame.new(center), order % 2 == 0 and COLORS.Pink or COLORS.Purple, Enum.Material.Neon)
		beam.CanCollide = true
		beam.CanQuery = true
		table.insert(sweepers, {
			Part = beam,
			Center = center,
			Angle = order * 0.8,
			Speed = (order % 2 == 0 and -1 or 1) * (0.45 + order * 0.07),
		})
	end
end

local function buildLobby(parent)
	local platform = makePart(parent, "LobbyPlatform", Vector3.new(4, 76, 76), CFrame.new(0, 82, 338) * CFrame.Angles(0, 0, math.rad(90)), COLORS.Panel, Enum.Material.Metal)
	platform.Shape = Enum.PartType.Cylinder
	platform.CanCollide = true
	platform.CanQuery = true

	local ring = makePart(parent, "LobbyRing", Vector3.new(1, 80, 80), CFrame.new(0, 80.5, 338) * CFrame.Angles(0, 0, math.rad(90)), COLORS.Cyan, Enum.Material.Neon)
	ring.Shape = Enum.PartType.Cylinder

	local spawn = Instance.new("SpawnLocation")
	spawn.Name = "LobbySpawn"
	spawn.Size = Vector3.new(12, 1, 12)
	spawn.CFrame = Track.LobbySpawn
	spawn.Anchored = true
	spawn.Neutral = true
	spawn.Enabled = true
	spawn.Duration = 0
	spawn.Color = COLORS.Panel
	spawn.Material = Enum.Material.SmoothPlastic
	spawn.Parent = parent

	local sign = makePart(parent, "LobbySign", Vector3.new(38, 12, 1), CFrame.new(0, 99, 366), COLORS.Navy, Enum.Material.Metal)
	sign.CanCollide = true
	local surface = Instance.new("SurfaceGui")
	surface.Face = Enum.NormalId.Front
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 12
	surface.Parent = sign
	local title = Instance.new("TextLabel")
	title.Size = UDim2.fromScale(1, 0.62)
	title.BackgroundTransparency = 1
	title.Font = Enum.Font.GothamBlack
	title.Text = Config.GameName
	title.TextColor3 = COLORS.Cyan
	title.TextScaled = true
	title.Parent = surface
	local subtitle = Instance.new("TextLabel")
	subtitle.Position = UDim2.fromScale(0, 0.62)
	subtitle.Size = UDim2.fromScale(1, 0.25)
	subtitle.BackgroundTransparency = 1
	subtitle.Font = Enum.Font.GothamBold
	subtitle.Text = "MULTIPLAYER DRONE RACING"
	subtitle.TextColor3 = COLORS.White
	subtitle.TextScaled = true
	subtitle.Parent = surface
end

local function buildEnvironment(parent)
	local random = Random.new(42024)
	for index = 1, 54 do
		local angle = random:NextNumber(0, math.pi * 2)
		local radius = random:NextNumber(350, 580)
		local height = random:NextNumber(50, 180)
		local width = random:NextNumber(18, 42)
		local position = Vector3.new(math.cos(angle) * radius, -55 + height / 2, math.sin(angle) * radius - 20)
		local building = makePart(parent, "Skyscraper", Vector3.new(width, height, width), CFrame.new(position) * CFrame.Angles(0, random:NextNumber(-0.4, 0.4), 0), index % 3 == 0 and COLORS.Panel or COLORS.Navy, Enum.Material.Metal)
		local band = makePart(parent, "CityLight", Vector3.new(width + 0.4, 1.2, width + 0.4), building.CFrame * CFrame.new(0, height * 0.28, 0), index % 2 == 0 and COLORS.Cyan or COLORS.Purple, Enum.Material.Neon)
		band.Transparency = 0.15
	end

	-- Мягкое облачное море скрывает нижнюю границу мира.
	for _ = 1, 26 do
		local cloud = makePart(parent, "Cloud", Vector3.new(random:NextNumber(80, 180), random:NextNumber(20, 45), random:NextNumber(70, 150)), CFrame.new(random:NextNumber(-600, 600), random:NextNumber(-125, -85), random:NextNumber(-600, 500)), Color3.fromRGB(157, 177, 210), Enum.Material.SmoothPlastic)
		cloud.Shape = Enum.PartType.Ball
		cloud.Transparency = random:NextNumber(0.35, 0.65)
	end
end

local function setupLighting()
	Lighting.ClockTime = 18.15
	Lighting.Brightness = 2.2
	Lighting.Ambient = Color3.fromRGB(45, 48, 76)
	Lighting.OutdoorAmbient = Color3.fromRGB(80, 70, 112)
	Lighting.EnvironmentDiffuseScale = 0.45
	Lighting.EnvironmentSpecularScale = 0.65
	Lighting.ExposureCompensation = 0.15

	for _, name in ipairs({ "AeroAtmosphere", "AeroBloom", "AeroColor", "AeroSun" }) do
		local existing = Lighting:FindFirstChild(name)
		if existing then
			existing:Destroy()
		end
	end

	local atmosphere = Instance.new("Atmosphere")
	atmosphere.Name = "AeroAtmosphere"
	atmosphere.Density = 0.32
	atmosphere.Offset = 0.15
	atmosphere.Color = Color3.fromRGB(130, 174, 210)
	atmosphere.Decay = Color3.fromRGB(92, 66, 125)
	atmosphere.Glare = 0.18
	atmosphere.Haze = 1.4
	atmosphere.Parent = Lighting

	local bloom = Instance.new("BloomEffect")
	bloom.Name = "AeroBloom"
	bloom.Intensity = 0.65
	bloom.Size = 22
	bloom.Threshold = 1.05
	bloom.Parent = Lighting

	local color = Instance.new("ColorCorrectionEffect")
	color.Name = "AeroColor"
	color.Contrast = 0.08
	color.Saturation = 0.08
	color.TintColor = Color3.fromRGB(235, 240, 255)
	color.Parent = Lighting

	local sun = Instance.new("SunRaysEffect")
	sun.Name = "AeroSun"
	sun.Intensity = 0.07
	sun.Spread = 0.7
	sun.Parent = Lighting
end

function WorldBuilder.Build()
	table.clear(sweepers)
	local previous = Workspace:FindFirstChild("AeroRushWorld")
	if previous then
		previous:Destroy()
	end

	local world = Instance.new("Folder")
	world.Name = "AeroRushWorld"
	world.Parent = Workspace

	local decorations = Instance.new("Folder")
	decorations.Name = "Decorations"
	decorations.Parent = world
	local gatesFolder = Instance.new("Folder")
	gatesFolder.Name = "Gates"
	gatesFolder.Parent = world
	local obstacles = Instance.new("Folder")
	obstacles.Name = "Obstacles"
	obstacles.Parent = world
	local lobby = Instance.new("Folder")
	lobby.Name = "Lobby"
	lobby.Parent = world
	local drones = Instance.new("Folder")
	drones.Name = "Drones"
	drones.Parent = world

	local gates = {}
	for index, definition in ipairs(Track.Gates) do
		gates[index] = buildGate(gatesFolder, index, definition)
	end

	buildTrackDecor(decorations, gates)
	buildObstacles(obstacles, gates)
	buildLobby(lobby)
	buildEnvironment(decorations)
	setupLighting()
	Workspace.FallenPartsDestroyHeight = Config.Drone.KillY - 30

	return {
		Root = world,
		Gates = gates,
		Obstacles = obstacles,
		Drones = drones,
		Lobby = lobby,
	}
end

function WorldBuilder.Step(deltaTime)
	for _, sweeper in ipairs(sweepers) do
		sweeper.Angle = sweeper.Angle + sweeper.Speed * deltaTime
		sweeper.Part.CFrame = CFrame.new(sweeper.Center) * CFrame.Angles(0, sweeper.Angle, 0)
	end
end

return WorldBuilder
