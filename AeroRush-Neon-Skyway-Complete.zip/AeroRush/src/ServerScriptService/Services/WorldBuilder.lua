-- Процедурно создаёт всю карту: отдельный .rbxl с моделями не требуется.
local Lighting = game:GetService("Lighting")
local Workspace = game:GetService("Workspace")

local Shared = game:GetService("ReplicatedStorage"):WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Track = require(Shared:WaitForChild("Track"))

local WorldBuilder = {}

local COLORS = {
	Navy = Color3.fromRGB(7, 12, 28),
	Panel = Color3.fromRGB(15, 25, 46),
	Cyan = Color3.fromRGB(30, 236, 255),
	Pink = Color3.fromRGB(255, 42, 150),
	Purple = Color3.fromRGB(128, 74, 255),
	White = Color3.fromRGB(225, 246, 255),
}

local sweepers = {}

local function makePart(parent, name, size, cframe, color, material)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.CFrame = cframe
	part.Color = color or COLORS.Panel
	part.Material = material or Enum.Material.SmoothPlastic
	part.Anchored = true
	part.CanCollide = false
	part.CanTouch = false
	part.CanQuery = false
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	part.Parent = parent
	return part
end

local function addBillboard(parent, name, title, subtitle, accent)
	local billboard = Instance.new("BillboardGui")
	billboard.Name = name
	billboard.Size = UDim2.fromOffset(250, 72)
	billboard.AlwaysOnTop = true
	billboard.MaxDistance = 460
	billboard.Parent = parent

	local heading = Instance.new("TextLabel")
	heading.Name = "Title"
	heading.Size = UDim2.new(1, 0, 0.56, 0)
	heading.BackgroundTransparency = 1
	heading.Font = Enum.Font.GothamBlack
	heading.Text = title
	heading.TextColor3 = accent
	heading.TextStrokeColor3 = COLORS.Navy
	heading.TextStrokeTransparency = 0.3
	heading.TextScaled = true
	heading.Parent = billboard

	local detail = Instance.new("TextLabel")
	detail.Name = "Subtitle"
	detail.Position = UDim2.fromScale(0, 0.62)
	detail.Size = UDim2.new(1, 0, 0.3, 0)
	detail.BackgroundTransparency = 1
	detail.Font = Enum.Font.GothamBold
	detail.Text = subtitle
	detail.TextColor3 = COLORS.White
	detail.TextStrokeColor3 = COLORS.Navy
	detail.TextStrokeTransparency = 0.4
	detail.TextScaled = true
	detail.Parent = billboard
	return billboard
end

local function addGateLabel(root, index, height)
	local accent = index == 1 and COLORS.Pink or (index % 3 == 0 and COLORS.Purple or COLORS.Cyan)
	local labelPart = Instance.new("Part")
	labelPart.Name = "NumberAnchor"
	labelPart.Size = Vector3.one
	labelPart.Transparency = 1
	labelPart.Anchored = true
	labelPart.CanCollide = false
	labelPart.CanTouch = false
	labelPart.CanQuery = false
	labelPart.CFrame = root.CFrame * CFrame.new(0, height / 2 + 5, 0)
	labelPart.Parent = root.Parent

	addBillboard(labelPart, "GateNumber", string.format("GATE // %02d", index), index == 1 and "START // FINISH" or "CHECKPOINT", accent)
	local target = addBillboard(labelPart, "TargetTag", "NEXT TARGET", "", COLORS.White)
	target.Name = "TargetTag"
	target.Size = UDim2.fromOffset(190, 44)
	target.StudsOffsetWorldSpace = Vector3.new(0, 7, 0)
	target.Enabled = false
end

local function buildGate(parent, index, definition)
	local cframe = Track.GetGateCFrame(index)
	local model = Instance.new("Model")
	model.Name = string.format("Gate_%02d", index)
	model:SetAttribute("Index", index)
	model:SetAttribute("Width", definition.Width)
	model:SetAttribute("Height", definition.Height)
	model.Parent = parent

	local root = makePart(
		model,
		"Root",
		Vector3.new(definition.Width, definition.Height, 2),
		cframe,
		COLORS.Navy
	)
	root.Transparency = 1
	model.PrimaryPart = root

	local accent = index == 1 and COLORS.Pink or (index % 3 == 0 and COLORS.Purple or COLORS.Cyan)
	local thickness = index == 1 and 1.8 or 1.2
	local height = definition.Height
	local width = definition.Width

	local field = makePart(model, "EnergyField", Vector3.new(width - 2, height - 2, 0.12), cframe, accent, Enum.Material.Glass)
	field.Transparency = 0.94
	field.Name = "EnergyField"

	makePart(model, "Left", Vector3.new(thickness, height + 2, 1.5), cframe * CFrame.new(-width / 2, 0, 0), accent, Enum.Material.Neon)
	makePart(model, "Right", Vector3.new(thickness, height + 2, 1.5), cframe * CFrame.new(width / 2, 0, 0), accent, Enum.Material.Neon)
	makePart(model, "Top", Vector3.new(width + 2, thickness, 1.5), cframe * CFrame.new(0, height / 2, 0), accent, Enum.Material.Neon)
	makePart(model, "Bottom", Vector3.new(width + 2, thickness, 1.5), cframe * CFrame.new(0, -height / 2, 0), accent, Enum.Material.Neon)

	-- Тёмная внешняя рама придаёт неоновым полосам объём.
	makePart(model, "LeftShell", Vector3.new(2.4, height + 5, 3), cframe * CFrame.new(-width / 2, 0, 1), COLORS.Panel)
	makePart(model, "RightShell", Vector3.new(2.4, height + 5, 3), cframe * CFrame.new(width / 2, 0, 1), COLORS.Panel)
	for _, x in ipairs({ -1, 1 }) do
		for _, y in ipairs({ -1, 1 }) do
			makePart(model, "CornerNode", Vector3.new(2.3, 2.3, 2.3), cframe * CFrame.new(x * width / 2, y * height / 2, 0), accent, Enum.Material.Neon)
		end
	end
	root.Parent = model
	addGateLabel(root, index, height)

	local approach = Instance.new("Part")
	approach.Name = "ApproachAnchor"
	approach.Size = Vector3.one
	approach.Transparency = 1
	approach.Anchored = true
	approach.CanCollide = false
	approach.CanTouch = false
	approach.CanQuery = false
	approach.CFrame = cframe * CFrame.new(0, -height / 2 - 4, 26)
	approach.Parent = model
	local guide = addBillboard(approach, "ApproachLabel", string.format(">> GATE %02d <<", index), "ALIGN + HOLD COURSE", accent)
	guide.Size = UDim2.fromOffset(210, 54)
	guide.MaxDistance = 180

	local particles = Instance.new("ParticleEmitter")
	particles.Name = "GateSparks"
	particles.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	particles.Rate = 5
	particles.Lifetime = NumberRange.new(1.2, 2.2)
	particles.Speed = NumberRange.new(1, 3)
	particles.SpreadAngle = Vector2.new(25, 25)
	particles.EmissionDirection = Enum.NormalId.Front
	particles.Acceleration = Vector3.new(0, 0.5, 0)
	particles.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.32), NumberSequenceKeypoint.new(1, 0) })
	particles.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(1, 1) })
	particles.Color = ColorSequence.new(accent)
	particles.LightEmission = 0.85
	particles.Parent = root

	local light = Instance.new("PointLight")
	light.Color = accent
	light.Brightness = 1.5
	light.Range = 24
	light.Parent = root

	return {
		Model = model,
		CFrame = cframe,
		Width = definition.Width,
		Height = definition.Height,
	}
end

local function buildTrackBoundaries(parent, gates)
	-- Энерго-барьеры только обозначают коридор: физика и размеры гейтов не меняются.
	for index, gate in ipairs(gates) do
		local nextGate = gates[index % #gates + 1]
		local direction = nextGate.CFrame.Position - gate.CFrame.Position
		local length = direction.Magnitude
		if length > 28 then
			local unit = direction / length
			local segmentStart = gate.CFrame.Position + unit * 12
			local segmentEnd = nextGate.CFrame.Position - unit * 12
			local usable = length - 24
			local center = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, 0.5)
			local segmentCFrame = CFrame.lookAt(center, nextGate.CFrame.Position)
			local corridor = math.min(gate.Width, nextGate.Width) / 2 + 7
			local accent = index == 1 and COLORS.Pink or (index % 3 == 0 and COLORS.Purple or COLORS.Cyan)
			for _, side in ipairs({ -1, 1 }) do
				local railCFrame = segmentCFrame * CFrame.new(side * corridor, -4, 0)
				local base = makePart(parent, "BoundaryBase", Vector3.new(0.75, 4, usable), railCFrame, COLORS.Panel, Enum.Material.Metal)
				base.Transparency = 0.18
				local rail = makePart(parent, "EnergyRail", Vector3.new(0.32, 0.32, usable), railCFrame * CFrame.new(0, 2, 0), accent, Enum.Material.Neon)
				rail.Transparency = 0.08

				local postCount = math.max(1, math.floor(usable / 34))
				for postIndex = 0, postCount do
					local position = segmentStart:Lerp(segmentEnd, postIndex / postCount)
					local postCFrame = CFrame.lookAt(position, nextGate.CFrame.Position)
					makePart(parent, "BoundaryPost", Vector3.new(1.2, 8, 1.2), postCFrame * CFrame.new(side * corridor, -4, 0), COLORS.Panel, Enum.Material.Metal)
					makePart(parent, "BoundaryBeacon", Vector3.new(1.55, 0.45, 1.55), postCFrame * CFrame.new(side * corridor, 0, 0), accent, Enum.Material.Neon)
				end
			end
		end
	end
end

local function buildStartGantry(parent, gates)
	local gate = gates[1]
	local cframe = gate.CFrame * CFrame.new(0, 0, 24)
	for _, side in ipairs({ -1, 1 }) do
		makePart(parent, "StartPillar", Vector3.new(2, 32, 2), cframe * CFrame.new(side * 25, 0, 0), COLORS.Panel, Enum.Material.Metal)
		makePart(parent, "StartPillarLight", Vector3.new(0.35, 28, 0.5), cframe * CFrame.new(side * 24, 0, -1.05), side == 1 and COLORS.Cyan or COLORS.Pink, Enum.Material.Neon)
	end
	makePart(parent, "StartBeam", Vector3.new(52, 2, 2), cframe * CFrame.new(0, 16, 0), COLORS.Panel, Enum.Material.Metal)
	makePart(parent, "StartBeamLight", Vector3.new(52, 0.35, 0.45), cframe * CFrame.new(0, 17.15, -1), COLORS.Cyan, Enum.Material.Neon)
	for lightIndex = -2, 2 do
		makePart(parent, "StartSignal", Vector3.new(3, 0.8, 0.8), cframe * CFrame.new(lightIndex * 6, 16, -1.3), lightIndex == 0 and COLORS.Pink or COLORS.Cyan, Enum.Material.Neon)
	end

	local sign = makePart(parent, "StartSign", Vector3.new(44, 8, 0.8), cframe * CFrame.new(0, 21, 0), COLORS.Navy, Enum.Material.Metal)
	local surface = Instance.new("SurfaceGui")
	surface.Name = "StartDisplay"
	surface.Face = Enum.NormalId.Back
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 9
	surface.Parent = sign
	local title = Instance.new("TextLabel")
	title.Size = UDim2.new(1, 0, 0.58, 0)
	title.BackgroundTransparency = 1
	title.Font = Enum.Font.GothamBlack
	title.Text = "AERORUSH // NEON SKYWAY"
	title.TextColor3 = COLORS.Cyan
	title.TextScaled = true
	title.Parent = surface
	local subtitle = Instance.new("TextLabel")
	subtitle.Position = UDim2.fromScale(0, 0.64)
	subtitle.Size = UDim2.new(1, 0, 0.25, 0)
	subtitle.BackgroundTransparency = 1
	subtitle.Font = Enum.Font.GothamBold
	subtitle.Text = "START GRID  ·  3 LAPS  ·  12 GATES"
	subtitle.TextColor3 = COLORS.White
	subtitle.TextScaled = true
	subtitle.Parent = surface
end

local function buildTrackDecor(decorations, gates)
	-- Голографические стрелки между гейта обозначают racing line.
	for index, gate in ipairs(gates) do
		local nextGate = gates[index % #gates + 1]
		local direction = nextGate.CFrame.Position - gate.CFrame.Position
		local length = direction.Magnitude
		local arrows = math.max(1, math.floor(length / 36))
		for arrowIndex = 1, arrows do
			local alpha = arrowIndex / (arrows + 1)
			local position = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, alpha)
			position = position - Vector3.new(0, 13, 0)
			local cframe = CFrame.lookAt(position, position + direction)
			local left = makePart(decorations, "ChevronLeft", Vector3.new(7, 0.18, 1.1), cframe * CFrame.new(-2.5, 0, 0) * CFrame.Angles(0, math.rad(35), 0), COLORS.Cyan, Enum.Material.Neon)
			local right = makePart(decorations, "ChevronRight", Vector3.new(7, 0.18, 1.1), cframe * CFrame.new(2.5, 0, 0) * CFrame.Angles(0, math.rad(-35), 0), COLORS.Cyan, Enum.Material.Neon)
			left.Transparency = 0.18
			right.Transparency = 0.18
		end

		-- Парящий технический диск под каждым гейтом.
		local disc = makePart(
			decorations,
			"GateDisc",
			Vector3.new(1.2, 18, 18),
			gate.CFrame * CFrame.new(0, -gate.Height / 2 - 8, 0) * CFrame.Angles(0, 0, math.rad(90)),
			COLORS.Panel,
			Enum.Material.Metal
		)
		disc.Shape = Enum.PartType.Cylinder
	end
end

local function buildObstacles(parent, gates)
	-- Статичные пилоны заставляют выбирать траекторию, не перекрывая сами гейты.
	for _, index in ipairs({ 2, 4, 6, 8, 10, 12 }) do
		local gate = gates[index]
		local nextGate = gates[index % #gates + 1]
		local middle = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, 0.5)
		local cframe = CFrame.lookAt(middle, nextGate.CFrame.Position)
		local side = index % 4 == 0 and -1 or 1
		local pylon = makePart(parent, "Pylon", Vector3.new(5, 28, 5), cframe * CFrame.new(side * 13, -3, 0), COLORS.Panel, Enum.Material.Metal)
		pylon.CanCollide = true
		pylon.CanQuery = true
		local stripe = makePart(parent, "PylonStripe", Vector3.new(5.3, 2, 5.3), pylon.CFrame, COLORS.Pink, Enum.Material.Neon)
		stripe.CanQuery = true
	end

	-- Четыре вращающихся сканера. Их положение обновляется на сервере.
	for order, index in ipairs({ 3, 5, 7, 9 }) do
		local gate = gates[index]
		local nextGate = gates[index % #gates + 1]
		local center = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, 0.48) - Vector3.new(0, 2, 0)
		local beam = makePart(parent, "Sweeper", Vector3.new(30, 1.8, 1.8), CFrame.new(center), order % 2 == 0 and COLORS.Pink or COLORS.Purple, Enum.Material.Neon)
		beam.CanCollide = true
		beam.CanQuery = true
		table.insert(sweepers, {
			Part = beam,
			Center = center,
			Angle = order * 0.8,
			Speed = (order % 2 == 0 and -1 or 1) * (0.45 + order * 0.07),
		})
	end
end

local function buildHoloPanel(parent, position, titleText, subtitleText, accent)
	local spawn = Track.LobbySpawn.Position
	local cframe = CFrame.lookAt(position, Vector3.new(spawn.X, position.Y, spawn.Z))
	local panel = makePart(parent, "HoloPanel", Vector3.new(19, 8, 0.6), cframe, COLORS.Navy, Enum.Material.Metal)
	panel.Transparency = 0.08
	makePart(parent, "HoloPanelEdge", Vector3.new(19.4, 0.28, 0.75), cframe * CFrame.new(0, 4.1, 0), accent, Enum.Material.Neon)
	local surface = Instance.new("SurfaceGui")
	surface.Name = "HoloDisplay"
	surface.Face = Enum.NormalId.Front
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 9
	surface.Parent = panel
	local title = Instance.new("TextLabel")
	title.Size = UDim2.new(1, 0, 0.55, 0)
	title.BackgroundTransparency = 1
	title.Font = Enum.Font.GothamBlack
	title.Text = titleText
	title.TextColor3 = accent
	title.TextScaled = true
	title.Parent = surface
	local subtitle = Instance.new("TextLabel")
	subtitle.Position = UDim2.fromScale(0, 0.62)
	subtitle.Size = UDim2.new(1, 0, 0.25, 0)
	subtitle.BackgroundTransparency = 1
	subtitle.Font = Enum.Font.GothamBold
	subtitle.Text = subtitleText
	subtitle.TextColor3 = COLORS.White
	subtitle.TextScaled = true
	subtitle.Parent = surface
	local light = Instance.new("PointLight")
	light.Color = accent
	light.Brightness = 1.2
	light.Range = 14
	light.Parent = panel
end

local function buildLobby(parent)
	local platform = makePart(parent, "LobbyPlatform", Vector3.new(4, 124, 124), CFrame.new(0, 82, 338) * CFrame.Angles(0, 0, math.rad(90)), COLORS.Panel, Enum.Material.Metal)
	platform.Shape = Enum.PartType.Cylinder
	platform.CanCollide = true
	platform.CanQuery = true

	local ring = makePart(parent, "LobbyRing", Vector3.new(1, 128, 128), CFrame.new(0, 80.5, 338) * CFrame.Angles(0, 0, math.rad(90)), COLORS.Cyan, Enum.Material.Neon)
	ring.Shape = Enum.PartType.Cylinder

	for index = 1, 2 do
		local floorRing = makePart(parent, "LobbyFloorRing", Vector3.new(0.18, 96 - index * 18, 96 - index * 18), CFrame.new(0, 84.12 + index * 0.01, 338) * CFrame.Angles(0, 0, math.rad(90)), index == 1 and COLORS.Cyan or COLORS.Purple, Enum.Material.Neon)
		floorRing.Shape = Enum.PartType.Cylinder
		floorRing.Transparency = 0.28
	end
	for index = 1, 8 do
		local angle = index / 8 * math.pi * 2
		local strip = makePart(parent, "LobbyFloorGuide", Vector3.new(0.16, 0.08, 32), CFrame.new(0, 84.14, 338) * CFrame.Angles(0, angle, 0) * CFrame.new(0, 0, -30), index % 2 == 0 and COLORS.Cyan or COLORS.Purple, Enum.Material.Neon)
		strip.Transparency = 0.35
	end
	for index = 1, 12 do
		local angle = index / 12 * math.pi * 2
		local position = Vector3.new(math.cos(angle) * 55, 88, 338 + math.sin(angle) * 55)
		makePart(parent, "LoungePylon", Vector3.new(0.8, 8, 0.8), CFrame.new(position), COLORS.Panel, Enum.Material.Metal)
		makePart(parent, "LoungeBeacon", Vector3.new(1.4, 0.5, 1.4), CFrame.new(position + Vector3.new(0, 4.2, 0)), index % 3 == 0 and COLORS.Pink or COLORS.Cyan, Enum.Material.Neon)
	end

	local spawn = Instance.new("SpawnLocation")
	spawn.Name = "LobbySpawn"
	spawn.Size = Vector3.new(12, 1, 12)
	spawn.CFrame = Track.LobbySpawn
	spawn.Anchored = true
	spawn.Neutral = true
	spawn.Enabled = true
	spawn.Duration = 0
	spawn.Color = COLORS.Panel
	spawn.Material = Enum.Material.SmoothPlastic
	spawn.Parent = parent

	local sign = makePart(parent, "LobbySign", Vector3.new(38, 12, 1), CFrame.new(0, 99, 392), COLORS.Navy, Enum.Material.Metal)
	sign.CanCollide = true
	local surface = Instance.new("SurfaceGui")
	surface.Face = Enum.NormalId.Front
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 12
	surface.Parent = sign
	local title = Instance.new("TextLabel")
	title.Size = UDim2.fromScale(1, 0.62)
	title.BackgroundTransparency = 1
	title.Font = Enum.Font.GothamBlack
	title.Text = Config.GameName
	title.TextColor3 = COLORS.Cyan
	title.TextScaled = true
	title.Parent = surface
	local subtitle = Instance.new("TextLabel")
	subtitle.Position = UDim2.fromScale(0, 0.62)
	subtitle.Size = UDim2.fromScale(1, 0.25)
	subtitle.BackgroundTransparency = 1
	subtitle.Font = Enum.Font.GothamBold
	subtitle.Text = "MULTIPLAYER DRONE RACING"
	subtitle.TextColor3 = COLORS.White
	subtitle.TextScaled = true
	subtitle.Parent = surface

	buildHoloPanel(parent, Vector3.new(-25, 95, 338), "03 // LAPS", "12 ORDERED GATES", COLORS.Cyan)
	buildHoloPanel(parent, Vector3.new(25, 95, 338), "09 // GADGETS", "F + G · FREE TECH CASES", COLORS.Pink)
	buildHoloPanel(parent, Vector3.new(0, 96, 304), "NEON SKYWAY", "RACE CLEAN · FLY FAST", COLORS.Purple)
end

local function buildEnvironment(parent)
	local random = Random.new(42024)
	for index = 1, 54 do
		local angle = random:NextNumber(0, math.pi * 2)
		local radius = random:NextNumber(350, 580)
		local height = random:NextNumber(50, 180)
		local width = random:NextNumber(18, 42)
		local position = Vector3.new(math.cos(angle) * radius, -55 + height / 2, math.sin(angle) * radius - 20)
		local building = makePart(parent, "Skyscraper", Vector3.new(width, height, width), CFrame.new(position) * CFrame.Angles(0, random:NextNumber(-0.4, 0.4), 0), index % 3 == 0 and COLORS.Panel or COLORS.Navy, Enum.Material.Metal)
		local accent = index % 6 == 0 and COLORS.Pink or (index % 2 == 0 and COLORS.Cyan or COLORS.Purple)
		local band = makePart(parent, "CityLight", Vector3.new(width + 0.4, 1.2, width + 0.4), building.CFrame * CFrame.new(0, height * 0.28, 0), accent, Enum.Material.Neon)
		band.Transparency = 0.15
		local lowerBand = makePart(parent, "CityLightLower", Vector3.new(width + 0.35, 0.55, width + 0.35), building.CFrame * CFrame.new(0, -height * 0.12, 0), accent, Enum.Material.Neon)
		lowerBand.Transparency = 0.32
		local crown = makePart(parent, "CityCrown", Vector3.new(width + 0.8, 0.6, width + 0.8), building.CFrame * CFrame.new(0, height / 2 + 0.3, 0), accent, Enum.Material.Neon)
		crown.Transparency = 0.22
		if index % 3 == 0 then
			makePart(parent, "CityAntenna", Vector3.new(0.5, 10, 0.5), building.CFrame * CFrame.new(0, height / 2 + 5, 0), COLORS.Panel, Enum.Material.Metal)
			makePart(parent, "CityBeacon", Vector3.new(1.4, 1.4, 1.4), building.CFrame * CFrame.new(0, height / 2 + 10.4, 0), accent, Enum.Material.Neon)
		end
	end

	-- Мягкое облачное море скрывает нижнюю границу мира.
	for _ = 1, 26 do
		local cloud = makePart(parent, "Cloud", Vector3.new(random:NextNumber(80, 180), random:NextNumber(20, 45), random:NextNumber(70, 150)), CFrame.new(random:NextNumber(-600, 600), random:NextNumber(-125, -85), random:NextNumber(-600, 500)), Color3.fromRGB(157, 177, 210), Enum.Material.SmoothPlastic)
		cloud.Shape = Enum.PartType.Ball
		cloud.Transparency = random:NextNumber(0.35, 0.65)
	end
end

local function buildFlightBoundary(parent)
	local center = Config.Boundary.Center
	local half = Config.Boundary.HalfSize
	for _, side in ipairs({ -1, 1 }) do
		local wallX = makePart(parent, "FlightLimitX", Vector3.new(0.5, half.Y * 2, half.Z * 2), CFrame.new(center + Vector3.new(side * half.X, 0, 0)), COLORS.Purple, Enum.Material.Glass)
		wallX.Transparency = 0.96
		local wallZ = makePart(parent, "FlightLimitZ", Vector3.new(half.X * 2, half.Y * 2, 0.5), CFrame.new(center + Vector3.new(0, 0, side * half.Z)), COLORS.Cyan, Enum.Material.Glass)
		wallZ.Transparency = 0.96
		makePart(parent, "FlightLimitTopX", Vector3.new(0.8, 0.8, half.Z * 2), CFrame.new(center + Vector3.new(side * half.X, half.Y, 0)), COLORS.Purple, Enum.Material.Neon)
		makePart(parent, "FlightLimitTopZ", Vector3.new(half.X * 2, 0.8, 0.8), CFrame.new(center + Vector3.new(0, half.Y, side * half.Z)), COLORS.Cyan, Enum.Material.Neon)
	end
	for offset = -390, 390, 65 do
		for _, side in ipairs({ -1, 1 }) do
			local postX = makePart(parent, "FlightLimitBeacon", Vector3.new(0.7, half.Y * 2, 0.7), CFrame.new(center + Vector3.new(side * half.X, 0, offset)), COLORS.Purple, Enum.Material.Neon)
			postX.Transparency = 0.55
		end
	end
	for offset = -260, 260, 65 do
		for _, side in ipairs({ -1, 1 }) do
			local postZ = makePart(parent, "FlightLimitBeacon", Vector3.new(0.7, half.Y * 2, 0.7), CFrame.new(center + Vector3.new(offset, 0, side * half.Z)), COLORS.Cyan, Enum.Material.Neon)
			postZ.Transparency = 0.55
		end
	end
end

local function setupLighting()
	Lighting.ClockTime = 17.4
	Lighting.Brightness = 2.6
	Lighting.Ambient = Color3.fromRGB(65, 72, 100)
	Lighting.OutdoorAmbient = Color3.fromRGB(100, 95, 135)
	Lighting.EnvironmentDiffuseScale = 0.6
	Lighting.EnvironmentSpecularScale = 0.7
	Lighting.ExposureCompensation = 0.3

	for _, name in ipairs({ "AeroAtmosphere", "AeroBloom", "AeroColor", "AeroSun" }) do
		local existing = Lighting:FindFirstChild(name)
		if existing then
			existing:Destroy()
		end
	end

	local atmosphere = Instance.new("Atmosphere")
	atmosphere.Name = "AeroAtmosphere"
	atmosphere.Density = 0.24
	atmosphere.Offset = 0.12
	atmosphere.Color = Color3.fromRGB(130, 174, 210)
	atmosphere.Decay = Color3.fromRGB(92, 66, 125)
	atmosphere.Glare = 0.18
	atmosphere.Haze = 1
	atmosphere.Parent = Lighting

	local bloom = Instance.new("BloomEffect")
	bloom.Name = "AeroBloom"
	bloom.Intensity = 0.45
	bloom.Size = 18
	bloom.Threshold = 1.05
	bloom.Parent = Lighting

	local color = Instance.new("ColorCorrectionEffect")
	color.Name = "AeroColor"
	color.Contrast = 0.08
	color.Saturation = 0.08
	color.TintColor = Color3.fromRGB(235, 240, 255)
	color.Parent = Lighting

	local sun = Instance.new("SunRaysEffect")
	sun.Name = "AeroSun"
	sun.Intensity = 0.07
	sun.Spread = 0.7
	sun.Parent = Lighting
end

function WorldBuilder.Build()
	table.clear(sweepers)
	local previous = Workspace:FindFirstChild("AeroRushWorld")
	if previous then
		previous:Destroy()
	end

	local world = Instance.new("Folder")
	world.Name = "AeroRushWorld"
	world.Parent = Workspace

	local decorations = Instance.new("Folder")
	decorations.Name = "Decorations"
	decorations.Parent = world
	local gatesFolder = Instance.new("Folder")
	gatesFolder.Name = "Gates"
	gatesFolder.Parent = world
	local obstacles = Instance.new("Folder")
	obstacles.Name = "Obstacles"
	obstacles.Parent = world
	local lobby = Instance.new("Folder")
	lobby.Name = "Lobby"
	lobby.Parent = world
	local drones = Instance.new("Folder")
	drones.Name = "Drones"
	drones.Parent = world

	local gates = {}
	for index, definition in ipairs(Track.Gates) do
		gates[index] = buildGate(gatesFolder, index, definition)
	end

	buildTrackBoundaries(decorations, gates)
	buildStartGantry(decorations, gates)
	buildTrackDecor(decorations, gates)
	buildObstacles(obstacles, gates)
	buildLobby(lobby)
	buildEnvironment(decorations)
	buildFlightBoundary(decorations)
	setupLighting()
	-- FallenPartsDestroyHeight требует PluginOrOpenCloud и недоступен живому серверу.
	-- Жёсткие координаты границ дополнительно контролирует DroneService.

	return {
		Root = world,
		Gates = gates,
		Obstacles = obstacles,
		Drones = drones,
		Lobby = lobby,
	}
end

function WorldBuilder.Step(deltaTime)
	for _, sweeper in ipairs(sweepers) do
		sweeper.Angle = sweeper.Angle + sweeper.Speed * deltaTime
		sweeper.Part.CFrame = CFrame.new(sweeper.Center) * CFrame.Angles(0, sweeper.Angle, 0)
	end
end

return WorldBuilder
