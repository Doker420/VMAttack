-- Game Passes, Developer Products и косметический гараж.
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Catalog = require(Shared:WaitForChild("Catalog"))

local ShopService = {}

local DataService
local remotes
local passOwnership = {}
local studioOwned = {}
local lastActions = {}

local function notify(player, text, kind)
	if player.Parent then
		remotes.Notify:FireClient(player, text, kind or "info")
	end
end

local function ownsPass(player, passItem)
	if studioOwned[player.UserId] and studioOwned[player.UserId][passItem.Id] then
		return true
	end
	local ownership = passOwnership[player.UserId]
	return ownership and ownership[passItem.Id] == true or false
end

local function ownsCosmetic(player, cosmetic)
	if cosmetic.Free then
		return true
	end
	local data = DataService.Get(player)
	if not data then
		return false
	end
	if data.OwnedCosmetics[cosmetic.Id] then
		return true
	end
	if cosmetic.UnlockLevel and Catalog.LevelForXP(data.XP) >= cosmetic.UnlockLevel then
		return true
	end
	if cosmetic.UnlockCoins and data.LifetimeCoins >= cosmetic.UnlockCoins then
		return true
	end
	if cosmetic.UnlockRaces and data.Races >= cosmetic.UnlockRaces then
		return true
	end
	if cosmetic.GamePass then
		local passItem = Catalog.GetShopItem(cosmetic.GamePass)
		return passItem and ownsPass(player, passItem) or false
	end
	return false
end

local function productMessage(player, item)
	local data = DataService.Get(player)
	if item.Action == "CreditBoost" then
		notify(player, string.format("Бустер активен: %d финишей с 2× кредитами", data and data.BoostCreditRaces or item.Amount), "success")
	elseif item.Action == "Credits" then
		notify(player, string.format("Начислено %d кредитов для гаража", item.Amount), "success")
	elseif item.Action == "Donation" then
		notify(player, "Спасибо за поддержку AERORUSH!", "success")
	else
		notify(player, "Покупка успешно подтверждена", "success")
	end
end

function ShopService.SendProfile(player)
	local data = DataService.Get(player)
	if not data or not player.Parent then
		return
	end
	local passes = {}
	for _, item in ipairs(Catalog.ShopItems) do
		if item.Kind == "GamePass" then
			passes[item.Id] = ownsPass(player, item)
		end
	end
	remotes.ProfileUpdate:FireClient(player, {
		Credits = data.Credits,
		Tech = data.Tech,
		LifetimeCoins = data.LifetimeCoins,
		BestCoinCombo = data.BestCoinCombo,
		TuningPreset = data.TuningPreset,
		UpgradeLevels = table.clone(data.UpgradeLevels),
		Wins = data.Wins,
		Races = data.Races,
		BestLap = data.BestLap,
		XP = data.XP,
		Level = Catalog.LevelForXP(data.XP),
		BoostCreditRaces = data.BoostCreditRaces,
		BoostCreditMultiplier = data.BoostCreditMultiplier,
		SelectedSkin = data.SelectedSkin,
		SelectedTrail = data.SelectedTrail,
		SelectedAttack = data.SelectedAttack,
		SelectedDefense = data.SelectedDefense,
		OwnedGadgets = table.clone(data.OwnedGadgets),
		CaseTokens = data.CaseTokens,
		CaseProgress = data.CaseProgress,
		CasesOpened = data.CasesOpened,
		LegendaryPity = data.LegendaryPity,
		OwnedCosmetics = table.clone(data.OwnedCosmetics),
		Passes = passes,
		DailyClaims = data.DailyClaims,
		LastDailyClaim = data.LastDailyClaim,
		QuestDay = data.QuestDay,
		QuestProgress = table.clone(data.QuestProgress),
		QuestRewards = table.clone(data.QuestRewards),
		StarterReceived = data.StarterReceived,
		TotalDonated = data.TotalDonated,
		FriendBonus = player:GetAttribute("FriendBonus") or 0,
		ServerTime = os.time(),
		StudioTest = RunService:IsStudio() and Config.EnableStudioTestPurchases,
	})
end

function ShopService.RefreshPasses(player)
	if not player.Parent then
		return
	end
	local ownership = {}
	passOwnership[player.UserId] = ownership
	for _, item in ipairs(Catalog.ShopItems) do
		if item.Kind == "GamePass" and item.ProductId > 0 then
			local ok, owns = pcall(function()
				return MarketplaceService:UserOwnsGamePassAsync(player.UserId, item.ProductId)
			end)
			if not player.Parent or passOwnership[player.UserId] ~= ownership then
				return
			end
			if ok then
				ownership[item.Id] = owns == true
			else
				warn("[AERORUSH] Проверка Game Pass: " .. tostring(owns))
			end
		end
	end
	if player.Parent and passOwnership[player.UserId] == ownership then
		ShopService.SendProfile(player)
	end
end

function ShopService.GetDroneAppearance(player)
	local data = DataService.Get(player)
	local skin = data and Catalog.GetCosmetic(data.SelectedSkin) or nil
	local trail = data and Catalog.GetCosmetic(data.SelectedTrail) or nil
	if not skin or skin.Type ~= "Skin" or not ownsCosmetic(player, skin) then
		skin = Catalog.GetCosmetic("SkinCyan")
	end
	if not trail or trail.Type ~= "Trail" or not ownsCosmetic(player, trail) then
		trail = Catalog.GetCosmetic("TrailCyan")
	end
	return skin, trail
end

function ShopService.Purchase(player, itemId)
	local item = Catalog.GetShopItem(itemId)
	if not item then
		return
	end
	if item.Action == "CreditBoost" then
		local data = DataService.Get(player)
		if data and data.BoostCreditRaces + item.Amount > Config.MaxStoredBoostRaces then
			notify(player, string.format("Сначала используйте бустер: хранится максимум %d финишей", Config.MaxStoredBoostRaces), "info")
			return
		end
	end
	if RunService:IsStudio() and Config.EnableStudioTestPurchases then
		if item.Kind == "GamePass" then
			studioOwned[player.UserId] = studioOwned[player.UserId] or {}
			studioOwned[player.UserId][item.Id] = true
			passOwnership[player.UserId] = passOwnership[player.UserId] or {}
			passOwnership[player.UserId][item.Id] = true
			ShopService.SendProfile(player)
			player:SetAttribute("AeroClub", studioOwned[player.UserId].AeroClub == true)
			notify(player, "Studio-тест: Game Pass выдан без Robux", "success")
		elseif DataService.TestGrant(player, item) then
			ShopService.SendProfile(player)
			productMessage(player, item)
		end
		return
	end
	if item.ProductId <= 0 then
		notify(player, "Этот товар ещё не опубликован", "warning")
		return
	end

	local ok, err = pcall(function()
		if item.Kind == "GamePass" then
			if ownsPass(player, item) then
				notify(player, "Этот Game Pass уже у вас есть", "info")
				return
			end
			MarketplaceService:PromptGamePassPurchase(player, item.ProductId)
		else
			MarketplaceService:PromptProductPurchase(player, item.ProductId)
		end
	end)
	if not ok then
		warn("[AERORUSH] Окно покупки: " .. tostring(err))
		notify(player, "Не удалось открыть покупку. Попробуйте позже.", "warning")
	end
end

function ShopService.HandleAction(player, action, itemId)
	if type(action) ~= "string" or type(itemId) ~= "string" then
		return
	end
	local now = os.clock()
	if now - (lastActions[player.UserId] or 0) < 0.3 then
		return
	end
	lastActions[player.UserId] = now
	if action == "Purchase" then
		ShopService.Purchase(player, itemId)
		return
	end
	local cosmetic = Catalog.GetCosmetic(itemId)
	if not cosmetic then
		return
	end
	if action == "BuyCosmetic" then
		local ok, message = DataService.BuyCosmetic(player, cosmetic)
		notify(player, message, ok and "success" or "warning")
	elseif action == "Equip" then
		if not ownsCosmetic(player, cosmetic) then
			notify(player, "Сначала откройте этот предмет", "warning")
			return
		end
		local data = DataService.Get(player)
		if not data then
			return
		end
		if cosmetic.Type == "Skin" then
			data.SelectedSkin = cosmetic.Id
		else
			data.SelectedTrail = cosmetic.Id
		end
		DataService.Commit(player, false)
		notify(player, cosmetic.Name .. " будет на вашем следующем дроне", "success")
	end
	ShopService.SendProfile(player)
end

function ShopService.OnPlayerAdded(player)
	passOwnership[player.UserId] = {}
	studioOwned[player.UserId] = {}
	player:SetAttribute("AeroClub", false)
	task.spawn(function()
		ShopService.RefreshPasses(player)
		local club = Catalog.GetShopItem("AeroClub")
		player:SetAttribute("AeroClub", ownsPass(player, club))
	end)
end

function ShopService.OnPlayerRemoving(player)
	passOwnership[player.UserId] = nil
	studioOwned[player.UserId] = nil
	lastActions[player.UserId] = nil
end

function ShopService.Init(dependencies)
	DataService = dependencies.DataService
	remotes = dependencies.Remotes
	DataService.SetOnChanged(ShopService.SendProfile)

	MarketplaceService.ProcessReceipt = function(receiptInfo)
		local player = Players:GetPlayerByUserId(receiptInfo.PlayerId)
		if not player then
			return Enum.PurchaseDecision.NotProcessedYet
		end
		local item = Catalog.GetProduct(receiptInfo.ProductId)
		if not item then
			warn("[AERORUSH] Неизвестный Developer Product: " .. tostring(receiptInfo.ProductId))
			return Enum.PurchaseDecision.NotProcessedYet
		end
		local saved, granted = DataService.ProcessReceipt(player, item, receiptInfo.PurchaseId)
		if not saved then
			return Enum.PurchaseDecision.NotProcessedYet
		end
		if granted then
			productMessage(player, item)
		end
		ShopService.SendProfile(player)
		return Enum.PurchaseDecision.PurchaseGranted
	end

	MarketplaceService.PromptGamePassPurchaseFinished:Connect(function(player, _, purchased)
		if purchased then
			task.spawn(function()
				task.wait(1)
				ShopService.RefreshPasses(player)
				local club = Catalog.GetShopItem("AeroClub")
				player:SetAttribute("AeroClub", ownsPass(player, club))
				notify(player, "Game Pass активирован — новый стиль уже в гараже", "success")
			end)
		end
	end)
end

return ShopService
