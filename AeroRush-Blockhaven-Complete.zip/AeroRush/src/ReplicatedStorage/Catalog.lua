-- Единый каталог магазина, косметики и бесплатных активностей.
-- Перед публикацией замените нулевые ProductId на ID из Creator Dashboard.
local Catalog = {}

Catalog.ShopItems = {
	{
		Id = "AeroClub",
		Kind = "GamePass",
		ProductId = 0,
		PriceRobux = 149,
		Tag = "CLUB",
		Name = "AERO CLUB",
		Description = "Значок профиля, золотая рамка и скин Club. Только стиль, без бонуса к скорости.",
	},
	{
		Id = "ChromaPack",
		Kind = "GamePass",
		ProductId = 0,
		PriceRobux = 199,
		Tag = "SKINS",
		Name = "BLOCK SKIN PACK",
		Description = "Блочные скины Ruby и Meadow для всех будущих заездов.",
	},
	{
		Id = "TrailPack",
		Kind = "GamePass",
		ProductId = 0,
		PriceRobux = 149,
		Tag = "FX",
		Name = "TRAIL PACK",
		Description = "Луговой и кометный следы. Визуальный эффект не меняет характеристики.",
	},
	{
		Id = "Boost3",
		Kind = "DeveloperProduct",
		ProductId = 0,
		PriceRobux = 49,
		Tag = "2X",
		Name = "BOOST ПРОКАЧКИ ×3",
		Description = "2× кредиты и 1.5× XP за следующие 3 финиша. Скорость дрона не меняется.",
		Action = "CreditBoost",
		Amount = 3,
		Multiplier = 2,
	},
	{
		Id = "Boost10",
		Kind = "DeveloperProduct",
		ProductId = 0,
		PriceRobux = 129,
		Tag = "2X",
		Name = "BOOST ПРОКАЧКИ ×10",
		Description = "2× кредиты и 1.5× XP за следующие 10 финишей. Можно накапливать до 30.",
		Action = "CreditBoost",
		Amount = 10,
		Multiplier = 2,
	},
	{
		Id = "CreditPack750",
		Kind = "DeveloperProduct",
		ProductId = 0,
		PriceRobux = 79,
		Tag = "+750",
		Name = "ПАК КРЕДИТОВ",
		Description = "750 кредиты для косметики из гаража. Не даёт преимущества в гонке.",
		Action = "Credits",
		Amount = 750,
	},
	{
		Id = "Tip25",
		Kind = "DeveloperProduct",
		ProductId = 0,
		PriceRobux = 25,
		Tag = "THX",
		Name = "МАЛЕНЬКИЙ ДОНАТ",
		Description = "Добровольная поддержка разработчика. Награды и преимущества не входят.",
		Action = "Donation",
	},
	{
		Id = "Tip99",
		Kind = "DeveloperProduct",
		ProductId = 0,
		PriceRobux = 99,
		Tag = "THX",
		Name = "ДОНАТ ПИЛОТА",
		Description = "Добровольная поддержка разработчика. Награды и преимущества не входят.",
		Action = "Donation",
	},
	{
		Id = "Tip249",
		Kind = "DeveloperProduct",
		ProductId = 0,
		PriceRobux = 249,
		Tag = "THX",
		Name = "ДОНАТ СПОНСОРА",
		Description = "Добровольная поддержка разработчика. Награды и преимущества не входят.",
		Action = "Donation",
	},
}

Catalog.Cosmetics = {
	{ Id = "SkinCyan", Type = "Skin", Name = "SKY", Accent = Color3.fromRGB(45, 157, 203), Secondary = Color3.fromRGB(235, 139, 44), Free = true },
	{ Id = "SkinPink", Type = "Skin", Name = "BRICK", Accent = Color3.fromRGB(174, 83, 58), Secondary = Color3.fromRGB(230, 200, 150), Free = true },
	{ Id = "SkinYellow", Type = "Skin", Name = "HONEY", Accent = Color3.fromRGB(214, 170, 65), Secondary = Color3.fromRGB(110, 75, 45), Free = true },
	{ Id = "SkinPurple", Type = "Skin", Name = "MOSS", Accent = Color3.fromRGB(96, 134, 72), Secondary = Color3.fromRGB(210, 220, 180), Free = true },
	{ Id = "SkinMint", Type = "Skin", Name = "LEAF", Accent = Color3.fromRGB(83, 143, 63), Secondary = Color3.fromRGB(230, 235, 200), Free = true },
	{ Id = "SkinOrange", Type = "Skin", Name = "EMBER", Accent = Color3.fromRGB(190, 105, 55), Secondary = Color3.fromRGB(230, 190, 90), Free = true },
	{ Id = "SkinFalcon", Type = "Skin", Model = "Falcon", Name = "FALCON X", Description = "Стреловидный корпус, блочные крылья и стабилизаторы.", Accent = Color3.fromRGB(210, 220, 215), Secondary = Color3.fromRGB(73, 124, 158), CreditPrice = 1400 },
	{ Id = "SkinManta", Type = "Skin", Model = "Manta", Name = "MANTA RAY", Description = "Широкие блочные крылья. Награда за собранные монетки.", Accent = Color3.fromRGB(90, 120, 135), Secondary = Color3.fromRGB(170, 190, 170), UnlockCoins = 35 },
	{ Id = "SkinHornet", Type = "Skin", Model = "Hornet", Name = "HORNET MK-II", Description = "Узкий корпус, боковые двигатели и боевой спойлер. Награда за финиши.", Accent = Color3.fromRGB(214, 170, 65), Secondary = Color3.fromRGB(90, 80, 60), UnlockRaces = 8 },
	{ Id = "SkinTitan", Type = "Skin", Model = "Titan", Name = "TITAN ARMOR", Description = "Каменная броня, расширенные пилоны и сдвоенный купол.", Accent = Color3.fromRGB(180, 190, 180), Secondary = Color3.fromRGB(214, 170, 65), UnlockLevel = 7 },
	{ Id = "SkinSunset", Type = "Skin", Name = "SUNSET", Accent = Color3.fromRGB(174, 83, 58), Secondary = Color3.fromRGB(214, 170, 65), CreditPrice = 500 },
	{ Id = "SkinWave", Type = "Skin", Name = "DEEP WAVE", Accent = Color3.fromRGB(73, 124, 158), Secondary = Color3.fromRGB(105, 158, 181), CreditPrice = 900 },
	{ Id = "SkinLevel3", Type = "Skin", Name = "PRO PILOT", Accent = Color3.fromRGB(220, 225, 210), Secondary = Color3.fromRGB(96, 134, 72), UnlockLevel = 3 },
	{ Id = "SkinChroma", Type = "Skin", Model = "Hornet", Name = "RUBY", Accent = Color3.fromRGB(155, 65, 55), Secondary = Color3.fromRGB(225, 180, 130), GamePass = "ChromaPack" },
	{ Id = "SkinAurora", Type = "Skin", Model = "Manta", Name = "MEADOW", Accent = Color3.fromRGB(83, 143, 63), Secondary = Color3.fromRGB(190, 205, 150), GamePass = "ChromaPack" },
	{ Id = "SkinClub", Type = "Skin", Model = "Titan", Name = "CLUB GOLD", Accent = Color3.fromRGB(214, 170, 65), Secondary = Color3.fromRGB(235, 235, 210), GamePass = "AeroClub" },

	{ Id = "TrailCyan", Type = "Trail", Name = "SKY TRAIL", ColorA = Color3.fromRGB(90, 150, 180), ColorB = Color3.fromRGB(220, 225, 200), Free = true },
	{ Id = "TrailPink", Type = "Trail", Name = "BRICK DUST", ColorA = Color3.fromRGB(174, 83, 58), ColorB = Color3.fromRGB(230, 200, 150), CreditPrice = 650 },
	{ Id = "TrailStar", Type = "Trail", Name = "HONEY TRAIL", ColorA = Color3.fromRGB(214, 170, 65), ColorB = Color3.fromRGB(240, 230, 180), CreditPrice = 1200 },
	{ Id = "TrailLevel5", Type = "Trail", Name = "ELITE", ColorA = Color3.fromRGB(220, 225, 210), ColorB = Color3.fromRGB(96, 134, 72), UnlockLevel = 5 },
	{ Id = "TrailRainbow", Type = "Trail", Name = "MEADOW", ColorA = Color3.fromRGB(83, 143, 63), ColorB = Color3.fromRGB(105, 158, 181), GamePass = "TrailPack" },
	{ Id = "TrailComet", Type = "Trail", Name = "COMET", ColorA = Color3.fromRGB(190, 105, 55), ColorB = Color3.fromRGB(230, 190, 90), GamePass = "TrailPack" },
}

Catalog.DefaultSkins = { "SkinCyan", "SkinPink", "SkinYellow", "SkinPurple", "SkinMint", "SkinOrange" }

Catalog.DailyRewards = {
	{ Credits = 100 },
	{ Credits = 150 },
	{ Credits = 200, CaseTokens = 1 },
	{ Credits = 250 },
	{ Credits = 300, CaseTokens = 1 },
	{ Credits = 400 },
	{ Credits = 700, BoostRaces = 1 },
}

Catalog.Quests = {
	{ Id = "Gates", Name = "ВОЗДУШНЫЙ МАРШРУТ", Description = "Пройди 36 гейтов", Target = 36, Reward = 200, XP = 60 },
	{ Id = "Coins", Name = "ЗОЛОТАЯ СЕРИЯ", Description = "Собери 20 монет на трассе", Target = 20, Reward = 250, XP = 75 },
	{ Id = "Finishes", Name = "ФИНИШЕР", Description = "Заверши 2 заезда", Target = 2, Reward = 250, XP = 80 },
	{ Id = "BoostSeconds", Name = "ПОЛНЫЙ ИМПУЛЬС", Description = "Используй boost 45 секунд", Target = 45, Reward = 200, XP = 60 },
	{ Id = "SocialRaces", Name = "КОМАНДНЫЙ ВЫЛЕТ", Description = "Финишируй в сервере с другом", Target = 1, Reward = 300, XP = 100 },
}

Catalog.Badges = {
	FirstFinish = 0,
	FirstWin = 0,
	Level5 = 0,
}

function Catalog.GetShopItem(itemId)
	for _, item in ipairs(Catalog.ShopItems) do
		if item.Id == itemId then
			return item
		end
	end
	return nil
end

function Catalog.GetProduct(productId)
	for _, item in ipairs(Catalog.ShopItems) do
		if item.Kind == "DeveloperProduct" and item.ProductId == productId and productId > 0 then
			return item
		end
	end
	return nil
end

function Catalog.GetCosmetic(cosmeticId)
	for _, cosmetic in ipairs(Catalog.Cosmetics) do
		if cosmetic.Id == cosmeticId then
			return cosmetic
		end
	end
	return nil
end

function Catalog.LevelForXP(xp)
	return math.floor(math.max(0, xp) / 500) + 1
end

function Catalog.XPForLevel(level)
	return math.max(0, level - 1) * 500
end

return Catalog
