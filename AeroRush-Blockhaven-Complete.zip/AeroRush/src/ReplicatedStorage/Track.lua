-- Замкнутая voxel-трасса Blockhaven. Координаты задают центр каждого гейта.
local Track = {}

Track.Gates = {
	{ Position = Vector3.new(0, 60, 220), Width = 38, Height = 24 },
	{ Position = Vector3.new(0, 76, 90), Width = 34, Height = 22 },
	{ Position = Vector3.new(82, 94, 12), Width = 32, Height = 22 },
	{ Position = Vector3.new(174, 76, -48), Width = 34, Height = 24 },
	{ Position = Vector3.new(220, 55, -154), Width = 30, Height = 20 },
	{ Position = Vector3.new(148, 46, -254), Width = 32, Height = 22 },
	{ Position = Vector3.new(18, 70, -286), Width = 36, Height = 24 },
	{ Position = Vector3.new(-104, 98, -232), Width = 32, Height = 22 },
	{ Position = Vector3.new(-194, 114, -108), Width = 30, Height = 20 },
	{ Position = Vector3.new(-224, 82, 32), Width = 34, Height = 24 },
	{ Position = Vector3.new(-158, 64, 154), Width = 32, Height = 22 },
	{ Position = Vector3.new(-72, 56, 220), Width = 34, Height = 22 },
}

Track.LobbySpawn = CFrame.lookAt(Vector3.new(0, 84.5, 366), Vector3.new(0, 84.5, 330))
Track.WorldCenter = Vector3.new(0, 40, -20)

function Track.GetGateCFrame(index)
	local gate = Track.Gates[index]
	local nextGate = Track.Gates[index % #Track.Gates + 1]
	return CFrame.lookAt(gate.Position, nextGate.Position)
end

function Track.GetGridCFrame(gridIndex)
	-- Три дрона в ряд; более поздние ряды стоят дальше за стартовой линией.
	local row = math.floor((gridIndex - 1) / 3)
	local column = (gridIndex - 1) % 3 - 1
	return Track.GetGateCFrame(1) * CFrame.new(column * 11, 0, 28 + row * 13)
end

-- Подход охватывает все 12 мест стартовой сетки и соединяет её с первым гейтом.
Track.StartApproach = (Track.GetGridCFrame(11) * CFrame.new(0, 0, 12)).Position

local function considerSegment(position, startPosition, endPosition, bestPoint, bestDistanceSquared)
	local direction = endPosition - startPosition
	local lengthSquared = direction:Dot(direction)
	if lengthSquared < 0.001 then
		return bestPoint, bestDistanceSquared
	end
	local alpha = math.clamp((position - startPosition):Dot(direction) / lengthSquared, 0, 1)
	local point = startPosition + direction * alpha
	local distanceSquared = (position - point):Dot(position - point)
	if distanceSquared < bestDistanceSquared then
		return point, distanceSquared
	end
	return bestPoint, bestDistanceSquared
end

function Track.GetClosestPoint(position)
	-- Маршрут замкнут; сервер выбирает ближайший коридор, а не общий бокс карты.
	local bestPoint = Track.Gates[1].Position
	local bestDistanceSquared = math.huge
	bestPoint, bestDistanceSquared = considerSegment(position, Track.StartApproach, Track.Gates[1].Position, bestPoint, bestDistanceSquared)
	for index, gate in ipairs(Track.Gates) do
		local nextGate = Track.Gates[index % #Track.Gates + 1]
		bestPoint, bestDistanceSquared = considerSegment(position, gate.Position, nextGate.Position, bestPoint, bestDistanceSquared)
	end
	return bestPoint, math.sqrt(bestDistanceSquared)
end

local function considerGroundSegment(position, startPosition, endPosition, bestY, bestDistanceSquared)
	local dx = endPosition.X - startPosition.X
	local dz = endPosition.Z - startPosition.Z
	local lengthSquared = dx * dx + dz * dz
	if lengthSquared < 0.001 then
		return bestY, bestDistanceSquared
	end
	local alpha = math.clamp(((position.X - startPosition.X) * dx + (position.Z - startPosition.Z) * dz) / lengthSquared, 0, 1)
	local x = startPosition.X + dx * alpha
	local z = startPosition.Z + dz * alpha
	local distanceSquared = (position.X - x) * (position.X - x) + (position.Z - z) * (position.Z - z)
	if distanceSquared < bestDistanceSquared then
		return startPosition.Y + (endPosition.Y - startPosition.Y) * alpha, distanceSquared
	end
	return bestY, bestDistanceSquared
end

function Track.GetGroundHeight(position)
	-- Высота пола зависит только от XZ, поэтому удержание снижения не меняет её между кадрами.
	local bestY = Track.Gates[1].Position.Y
	local bestDistanceSquared = math.huge
	bestY, bestDistanceSquared = considerGroundSegment(position, Track.StartApproach, Track.Gates[1].Position, bestY, bestDistanceSquared)
	for index, gate in ipairs(Track.Gates) do
		local nextGate = Track.Gates[index % #Track.Gates + 1]
		bestY, bestDistanceSquared = considerGroundSegment(position, gate.Position, nextGate.Position, bestY, bestDistanceSquared)
	end
	return bestY
end

return Track
