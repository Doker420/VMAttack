-- AERORUSH server entry point.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local services = script.Parent:WaitForChild("Services")
local WorldBuilder = require(services:WaitForChild("WorldBuilder"))
local DroneService = require(services:WaitForChild("DroneService"))
local DataService = require(services:WaitForChild("DataService"))
local ShopService = require(services:WaitForChild("ShopService"))
local EngagementService = require(services:WaitForChild("EngagementService"))
local CombatService = require(services:WaitForChild("CombatService"))
local LobbyService = require(services:WaitForChild("LobbyService"))
local TuningService = require(services:WaitForChild("TuningService"))
local RaceService = require(services:WaitForChild("RaceService"))

local remotes = Instance.new("Folder")
remotes.Name = "Remotes"
for _, name in ipairs({ "Input", "Reset", "Notify", "Checkpoint", "Leaderboard", "Results", "ShopAction", "EngagementAction", "ProfileUpdate", "Celebration", "CombatAction", "CombatFX", "CaseOpened", "LobbyAction", "TuningAction", "CoinFX" }) do
	local remote = Instance.new("RemoteEvent")
	remote.Name = name
	remote.Parent = remotes
end
remotes.Parent = Shared

local world = WorldBuilder.Build()
DroneService.Init(world)
DataService.Init()
ShopService.Init({ DataService = DataService, Remotes = remotes })
EngagementService.Init({ DataService = DataService, ShopService = ShopService, Remotes = remotes })
CombatService.Init({ DataService = DataService, DroneService = DroneService, Remotes = remotes, World = world })
TuningService.Init({ DataService = DataService, DroneService = DroneService, EngagementService = EngagementService, Remotes = remotes, World = world })
DroneService.SetCosmeticsProvider(ShopService.GetDroneAppearance)
DroneService.SetCombatProvider(CombatService.GetMovementModifiers)
DroneService.SetTuningProvider(TuningService.GetMovement)
RaceService.Init({
	DataService = DataService,
	World = world,
	WorldBuilder = WorldBuilder,
	DroneService = DroneService,
	EngagementService = EngagementService,
	CombatService = CombatService,
	TuningService = TuningService,
	Remotes = remotes,
})
LobbyService.Init({ World = world, DataService = DataService, DroneService = DroneService, RaceService = RaceService, Remotes = remotes })

local function onPlayerAdded(player)
	RaceService.OnPlayerAdded(player)
	ShopService.OnPlayerAdded(player)
	EngagementService.OnPlayerAdded(player)
	task.spawn(function()
		DataService.Load(player)
		if player.Parent then
			EngagementService.OnProfileLoaded(player)
		end
	end)
end

Players.PlayerAdded:Connect(onPlayerAdded)
Players.PlayerRemoving:Connect(function(player)
	RaceService.OnPlayerRemoving(player)
	ShopService.OnPlayerRemoving(player)
	EngagementService.OnPlayerRemoving(player)
	DataService.SaveAndClear(player)
end)

remotes.Input.OnServerEvent:Connect(function(player, payload)
	RaceService.HandleInput(player, payload)
end)
remotes.Reset.OnServerEvent:Connect(function(player)
	RaceService.RequestReset(player)
end)
remotes.ShopAction.OnServerEvent:Connect(function(player, action, itemId)
	ShopService.HandleAction(player, action, itemId)
end)
remotes.EngagementAction.OnServerEvent:Connect(function(player, action)
	EngagementService.HandleAction(player, action)
end)
remotes.LobbyAction.OnServerEvent:Connect(function(player, action)
	RaceService.HandleLobbyAction(player, action)
end)
remotes.CombatAction.OnServerEvent:Connect(function(player, action, value)
	CombatService.HandleAction(player, action, value)
end)
remotes.TuningAction.OnServerEvent:Connect(function(player, action, value)
	TuningService.HandleAction(player, action, value)
end)

-- Фиксированные 30 тиков/с: стабильная симуляция и разумная нагрузка на репликацию.
local accumulator = 0
RunService.Heartbeat:Connect(function(deltaTime)
	accumulator = accumulator + math.min(deltaTime, 0.12)
	while accumulator >= 1 / 30 do
		RaceService.Step(1 / 30)
		LobbyService.Step(1 / 30)
		accumulator = accumulator - 1 / 30
	end
end)

game:BindToClose(function()
	DataService.SaveAll()
end)

for _, player in ipairs(Players:GetPlayers()) do
	onPlayerAdded(player)
end

print("[AERORUSH] Blockhaven готова · мультиплеер до 12 пилотов")
