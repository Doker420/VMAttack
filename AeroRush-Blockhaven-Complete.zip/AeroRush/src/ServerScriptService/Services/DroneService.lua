-- Серверная аркадная модель дрона. Клиент передаёт только намерение игрока,
-- а положение, скорость, столкновения и boost вычисляются здесь.
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Track = require(Shared:WaitForChild("Track"))

local DroneService = {}

local states = {}
local dronesFolder
local raycastParams
local overlapParams
local appearanceProvider
local combatProvider
local tuningProvider

local PINK = Color3.fromRGB(235, 139, 44)
local DARK = Color3.fromRGB(48, 56, 54)
local METAL = Color3.fromRGB(80, 88, 82)
local WOOD = Color3.fromRGB(177, 126, 63)
local WOOD_DARK = Color3.fromRGB(104, 70, 37)
local WHITE = Color3.fromRGB(246, 248, 232)

local COLLISION_SKIN = 0.18
local SLIDE_ITERATIONS = 3
local RECOVERY_ITERATIONS = 6
local CONTACT_PUSH_SPEED = 5

local function makePart(model, name, size, cframe, color, material, className)
	local part = Instance.new(className or "Part")
	part.Name = name
	part.Size = size
	part.CFrame = cframe
	part.Color = color
	part.Material = material or Enum.Material.Metal
	part.Anchored = true
	part.CanCollide = false
	part.CanTouch = false
	part.CanQuery = false
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	part.Parent = model
	return part
end

local function addTrail(root, colorA, colorB)
	local left = Instance.new("Attachment")
	left.Name = "TrailLeft"
	left.Position = Vector3.new(-1.4, 0, 2.4)
	left.Parent = root
	local right = Instance.new("Attachment")
	right.Name = "TrailRight"
	right.Position = Vector3.new(1.4, 0, 2.4)
	right.Parent = root

	local trail = Instance.new("Trail")
	trail.Name = "EngineTrail"
	trail.Attachment0 = left
	trail.Attachment1 = right
	trail.Lifetime = 0.22
	trail.MinLength = 0.2
	trail.LightEmission = 0.12
	trail.WidthScale = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.7),
		NumberSequenceKeypoint.new(1, 0),
	})
	trail.Color = ColorSequence.new(colorA, colorB)
	trail.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.2),
		NumberSequenceKeypoint.new(1, 1),
	})
	trail.Parent = root
end

local function addWing(model, name, offset, size, rotationY, rotationZ, color)
	local cframe = CFrame.new(offset) * CFrame.Angles(0, math.rad(rotationY), math.rad(rotationZ))
	local wing = makePart(model, name, size, cframe, color, Enum.Material.Metal)
	wing:SetAttribute("OffsetX", offset.X)
	wing:SetAttribute("OffsetY", offset.Y)
	wing:SetAttribute("OffsetZ", offset.Z)
	wing:SetAttribute("BaseY", math.rad(rotationY))
	wing:SetAttribute("BaseZ", math.rad(rotationZ))
	wing:SetAttribute("FlexSide", offset.X < 0 and -1 or 1)
	CollectionService:AddTag(wing, "AeroRushWing")
	return wing
end

local function addSkinGeometry(model, skin, accent)
	local kind = skin.Model or "Quad"
	model:SetAttribute("SkinModel", kind)
	if kind == "Falcon" then
		makePart(model, "FalconNose", Vector3.new(2.4, 0.72, 3.6), CFrame.new(0, 0.05, -4.25), accent, Enum.Material.Metal, "WedgePart")
		addWing(model, "FalconWingL", Vector3.new(-2.45, -0.22, 0.4), Vector3.new(4.3, 0.24, 2.6), -24, -4, skin.Secondary)
		addWing(model, "FalconWingR", Vector3.new(2.45, -0.22, 0.4), Vector3.new(4.3, 0.24, 2.6), 24, 4, skin.Secondary)
		for _, side in ipairs({ -1, 1 }) do
			makePart(model, "FalconTail", Vector3.new(0.28, 1.8, 1.8), CFrame.new(side * 1.15, 1.1, 2.15) * CFrame.Angles(0, 0, math.rad(side * 12)), accent, Enum.Material.Metal, "WedgePart")
		end
	elseif kind == "Manta" then
		addWing(model, "MantaWingL", Vector3.new(-3.1, -0.3, -0.25), Vector3.new(5.2, 0.28, 3.8), -16, -3, accent)
		addWing(model, "MantaWingR", Vector3.new(3.1, -0.3, -0.25), Vector3.new(5.2, 0.28, 3.8), 16, 3, accent)
		makePart(model, "MantaHead", Vector3.new(4.4, 0.55, 2.4), CFrame.new(0, 0.25, -1.8), DARK, Enum.Material.Glass)
		makePart(model, "MantaTail", Vector3.new(0.35, 0.3, 4.8), CFrame.new(0, 0, 4.1), skin.Secondary, Enum.Material.SmoothPlastic)
	elseif kind == "Hornet" then
		makePart(model, "HornetNose", Vector3.new(1.65, 0.7, 4.2), CFrame.new(0, 0.1, -4.45), accent, Enum.Material.Metal, "WedgePart")
		for _, side in ipairs({ -1, 1 }) do
			makePart(model, "HornetPod", Vector3.new(1.15, 1.15, 4.4), CFrame.new(side * 2.35, 0, 0.8), DARK, Enum.Material.Metal)
			makePart(model, "HornetPodLight", Vector3.new(1.22, 0.25, 3.4), CFrame.new(side * 2.35, 0.58, 0.55), skin.Secondary, Enum.Material.SmoothPlastic)
		end
		addWing(model, "HornetSpoilerL", Vector3.new(-2.0, 0.65, 2.5), Vector3.new(3.4, 0.24, 1.4), -10, -7, accent)
		addWing(model, "HornetSpoilerR", Vector3.new(2.0, 0.65, 2.5), Vector3.new(3.4, 0.24, 1.4), 10, 7, accent)
	elseif kind == "Titan" then
		makePart(model, "TitanArmor", Vector3.new(4.9, 0.55, 3.8), CFrame.new(0, 0.55, 0.25), METAL, Enum.Material.DiamondPlate)
		makePart(model, "TitanCanopy", Vector3.new(1.8, 0.75, 2.2), CFrame.new(0, 1.15, -0.6), accent, Enum.Material.Glass)
		for _, side in ipairs({ -1, 1 }) do
			makePart(model, "TitanPod", Vector3.new(1.35, 1.45, 4.5), CFrame.new(side * 2.65, 0, 0.35), DARK, Enum.Material.Metal)
			addWing(model, side < 0 and "TitanPlateL" or "TitanPlateR", Vector3.new(side * 3.25, -0.25, 0.3), Vector3.new(2.7, 0.5, 3.2), 0, side * 3, skin.Secondary)
		end
		makePart(model, "TitanBumper", Vector3.new(4.8, 0.55, 0.7), CFrame.new(0, -0.2, -3.15), accent, Enum.Material.Metal)
	end
end

local function buildDrone(player)
	local skin = { Accent = Color3.fromRGB(45, 157, 203), Secondary = PINK }
	local trailStyle = { ColorA = skin.Accent, ColorB = PINK }
	if appearanceProvider then
		local selectedSkin, selectedTrail = appearanceProvider(player)
		if selectedSkin then
			skin = selectedSkin
		end
		if selectedTrail then
			trailStyle = selectedTrail
		end
	end
	local accent = skin.Accent
	local model = Instance.new("Model")
	model.Name = "Drone_" .. player.UserId
	model:SetAttribute("OwnerUserId", player.UserId)
	model:SetAttribute("Speed", 0)
	model:SetAttribute("Boost", Config.Drone.BoostCapacity)
	model:SetAttribute("Active", false)
	CollectionService:AddTag(model, "AeroRushDrone")

	local root = makePart(model, "Root", Vector3.new(4.6, 1.05, 5.6), CFrame.new(), accent, Enum.Material.SmoothPlastic)
	model.PrimaryPart = root

	makePart(model, "WoodKeel", Vector3.new(4.9, 0.55, 5.9), CFrame.new(0, -0.55, 0.2), WOOD_DARK, Enum.Material.WoodPlanks)
	makePart(model, "OrangeTopPanel", Vector3.new(3.5, 0.38, 3.6), CFrame.new(0, 0.72, 0.45), skin.Secondary, Enum.Material.WoodPlanks)
	makePart(model, "Canopy", Vector3.new(2.6, 0.9, 2.5), CFrame.new(0, 0.75, -1.25), Color3.fromRGB(70, 145, 170), Enum.Material.Glass)
	makePart(model, "Nose", Vector3.new(2.6, 0.65, 1.4), CFrame.new(0, 0, -3.25), accent, Enum.Material.SmoothPlastic)
	makePart(model, "HeadLamp", Vector3.new(1.35, 0.65, 0.35), CFrame.new(0, 0.05, -4), WHITE, Enum.Material.SmoothPlastic)
	makePart(model, "RearLight", Vector3.new(2.6, 0.3, 0.35), CFrame.new(0, 0, 3), skin.Secondary, Enum.Material.SmoothPlastic)

	local rotorIndex = 0
	for _, x in ipairs({ -4.4, 4.4 }) do
		for _, z in ipairs({ -4.4, 4.4 }) do
			rotorIndex = rotorIndex + 1
			local motorPosition = Vector3.new(x, 0, z)
			local armLength = motorPosition.Magnitude
			local armCFrame = CFrame.lookAt(motorPosition * 0.5, motorPosition)
			makePart(model, "WoodenArm", Vector3.new(0.68, 0.5, armLength), armCFrame, WOOD_DARK, Enum.Material.WoodPlanks)
			makePart(model, "Motor", Vector3.new(1.15, 1.25, 1.15), CFrame.new(motorPosition + Vector3.new(0, 0.25, 0)), DARK, Enum.Material.Metal)

			for _, side in ipairs({ -1, 1 }) do
				makePart(model, "SquareRotorFrameX", Vector3.new(6.2, 0.5, 0.6), CFrame.new(motorPosition + Vector3.new(0, 0.45, side * 2.8)), WOOD, Enum.Material.WoodPlanks)
				makePart(model, "SquareRotorFrameZ", Vector3.new(0.6, 0.5, 6.2), CFrame.new(motorPosition + Vector3.new(side * 2.8, 0.45, 0)), WOOD, Enum.Material.WoodPlanks)
				makePart(model, "RotorAccentX", Vector3.new(6.25, 0.22, 0.68), CFrame.new(motorPosition + Vector3.new(0, 0.12, side * 2.8)), accent, Enum.Material.SmoothPlastic)
				makePart(model, "RotorAccentZ", Vector3.new(0.68, 0.22, 6.25), CFrame.new(motorPosition + Vector3.new(side * 2.8, 0.12, 0)), accent, Enum.Material.SmoothPlastic)
			end

			local bladePosition = motorPosition + Vector3.new(0, 1.02, 0)
			for _, size in ipairs({ Vector3.new(5.1, 0.09, 0.34), Vector3.new(0.34, 0.09, 5.1) }) do
				local blade = makePart(model, "Rotor", size, CFrame.new(bladePosition), WHITE, Enum.Material.SmoothPlastic)
				blade.Transparency = 0.18
				blade:SetAttribute("OffsetX", bladePosition.X)
				blade:SetAttribute("OffsetY", bladePosition.Y)
				blade:SetAttribute("OffsetZ", bladePosition.Z)
				blade:SetAttribute("RotorIndex", rotorIndex)
				CollectionService:AddTag(blade, "AeroRushRotor")
			end
		end
	end

	addSkinGeometry(model, skin, accent)
	local light = Instance.new("PointLight")
	light.Color = WHITE
	light.Brightness = 0.3
	light.Range = 14
	light.Parent = root
	addTrail(root, trailStyle.ColorA, trailStyle.ColorB)
	return model
end

local function yawFromCFrame(cframe)
	local forward = cframe.LookVector
	return math.atan2(-forward.X, -forward.Z)
end

local function safeNumber(value)
	if type(value) ~= "number" or value ~= value or value == math.huge or value == -math.huge then
		return 0
	end
	return math.clamp(value, -1, 1)
end

function DroneService.Init(world)
	dronesFolder = world.Drones
	local collisionFilter = { world.Obstacles, world.Decorations }
	raycastParams = RaycastParams.new()
	raycastParams.FilterType = Enum.RaycastFilterType.Include
	raycastParams.FilterDescendantsInstances = collisionFilter
	raycastParams.IgnoreWater = true
	overlapParams = OverlapParams.new()
	overlapParams.FilterType = Enum.RaycastFilterType.Include
	overlapParams.FilterDescendantsInstances = collisionFilter
	overlapParams.MaxParts = 64
	overlapParams.RespectCanCollide = true
end

function DroneService.SetCosmeticsProvider(provider)
	appearanceProvider = provider
end

function DroneService.SetCombatProvider(provider)
	combatProvider = provider
end

function DroneService.SetTuningProvider(provider)
	tuningProvider = provider
end

function DroneService.Spawn(player, cframe)
	DroneService.Remove(player)
	local model = buildDrone(player)
	model:PivotTo(cframe)
	model.Parent = dronesFolder
	local tuning = tuningProvider and tuningProvider(player) or { Speed = 1, BoostSpeed = 1, Acceleration = 1, Yaw = 1, Capacity = 1, Drain = 1, Recharge = 1 }
	local boostCapacity = Config.Drone.BoostCapacity * tuning.Capacity
	model:SetAttribute("BoostCapacity", boostCapacity)
	states[player.UserId] = {
		Player = player,
		Model = model,
		Velocity = Vector3.zero,
		SafePosition = cframe.Position,
		Yaw = yawFromCFrame(cframe),
		Input = { X = 0, Y = 0, Up = false, Down = false, Boost = false, Yaw = 0 },
		LastInput = os.clock(),
		Boost = boostCapacity,
		Tuning = tuning,
		Active = false,
		IsBoosting = false,
		BoundaryWarning = 0,
		AttributeClock = 0,
	}
	model:SetAttribute("Boost", states[player.UserId].Boost)
	model:SetAttribute("BoundaryWarning", 0)
	return model
end

function DroneService.Remove(player)
	local state = states[player.UserId]
	if state then
		if state.Model then
			state.Model:Destroy()
		end
		states[player.UserId] = nil
	end
end

function DroneService.SetInput(player, payload)
	local state = states[player.UserId]
	if not state or type(payload) ~= "table" then
		return
	end

	local x = safeNumber(payload.X)
	local y = safeNumber(payload.Y)
	local magnitude = math.sqrt(x * x + y * y)
	if magnitude > 1 then
		x = x / magnitude
		y = y / magnitude
	end

	state.Input = {
		X = x,
		Y = y,
		Up = payload.Up == true,
		Down = payload.Down == true,
		Boost = payload.Boost == true,
		Yaw = safeNumber(payload.Yaw),
	}
	state.LastInput = os.clock()
end

function DroneService.SetActive(player, active)
	local state = states[player.UserId]
	if not state then
		return
	end
	state.Active = active
	state.IsBoosting = false
	state.Model:SetAttribute("Active", active)
	if not active then
		state.Velocity = Vector3.zero
		state.Model:SetAttribute("Speed", 0)
	end
end

function DroneService.Reset(player, cframe)
	local state = states[player.UserId]
	if not state or not state.Model or not state.Model.Parent then
		return
	end
	state.Velocity = Vector3.zero
	state.IsBoosting = false
	state.SafePosition = cframe.Position
	state.Yaw = yawFromCFrame(cframe)
	state.Boost = math.max(state.Boost, 25)
	state.BoundaryWarning = 0
	state.Model:PivotTo(cframe)
	state.Model:SetAttribute("BoundaryWarning", 0)
	state.Model:SetAttribute("Speed", 0)
	state.Model:SetAttribute("Boost", state.Boost)
end

function DroneService.GuardGate(player, gate, localX, localY)
	local state = states[player.UserId]
	if not state or not state.Model or not state.Model.Parent or not gate then
		return DroneService.GetPosition(player)
	end
	local marginX = math.min(4, gate.Width / 4)
	local marginY = math.min(4, gate.Height / 4)
	local x = math.clamp(localX, -gate.Width / 2 + marginX, gate.Width / 2 - marginX)
	local y = math.clamp(localY, -gate.Height / 2 + marginY, gate.Height / 2 - marginY)
	local corrected = gate.CFrame * CFrame.new(x, y, 5)
	state.Velocity = Vector3.zero
	state.IsBoosting = false
	state.SafePosition = corrected.Position
	state.Yaw = yawFromCFrame(gate.CFrame)
	state.Model:PivotTo(corrected)
	state.Model:SetAttribute("Speed", 0)
	state.Model:SetAttribute("GateGuardAt", Workspace:GetServerTimeNow())
	return corrected.Position
end

function DroneService.GetModel(player)
	local state = states[player.UserId]
	return state and state.Model or nil
end

function DroneService.GetPosition(player)
	local state = states[player.UserId]
	if not state or not state.Model or not state.Model.PrimaryPart then
		return Vector3.zero
	end
	return state.Model.PrimaryPart.Position
end

function DroneService.GetSpeed(player)
	local state = states[player.UserId]
	return state and state.Velocity.Magnitude or 0
end

function DroneService.ApplyImpulse(player, impulse)
	local state = states[player.UserId]
	if state and state.Active and impulse then
		state.Velocity = state.Velocity + impulse
		if state.Velocity.Magnitude > 160 then
			state.Velocity = state.Velocity.Unit * 160
		end
	end
end

function DroneService.AddBoost(player, amount)
	local state = states[player.UserId]
	if not state or not state.Active or type(amount) ~= "number" then
		return
	end
	local capacity = Config.Drone.BoostCapacity * state.Tuning.Capacity
	state.Boost = math.min(capacity, state.Boost + math.max(0, amount))
	state.Model:SetAttribute("Boost", state.Boost)
end

function DroneService.IsBoosting(player)
	local state = states[player.UserId]
	return state and state.Active and state.IsBoosting or false
end

local function softBoundaryAxis(value, velocity, minimum, maximum, deltaTime)
	local margin = Config.Boundary.SoftZone
	local direction = 0
	local warning = 0
	if value > maximum - margin then
		direction = 1
		warning = math.clamp((value - (maximum - margin)) / margin, 0, 1)
	elseif value < minimum + margin then
		direction = -1
		warning = math.clamp(((minimum + margin) - value) / margin, 0, 1)
	end
	if direction ~= 0 then
		local outward = velocity * direction
		if outward > 0 then
			local reduced = math.max(0, outward - outward * warning * deltaTime * 8 - Config.Boundary.Pushback * warning * deltaTime)
			velocity = direction * reduced
		end
		velocity = velocity - direction * Config.Boundary.Pushback * 0.18 * warning * deltaTime
	end
	return velocity, warning
end

local function hardBoundaryAxis(value, velocity, minimum, maximum)
	if value > maximum then
		return maximum, -math.abs(velocity) * 0.12, true
	elseif value < minimum then
		return minimum, math.abs(velocity) * 0.12, true
	end
	return value, velocity, false
end

local function radiusForNormal(normal)
	if math.abs(normal.Y) > 0.65 then
		return Config.Drone.CollisionRadius
	end
	return Config.Drone.SideCollisionRadius or Config.Drone.CollisionRadius
end

local function finitePosition(position)
	return position.X == position.X and position.Y == position.Y and position.Z == position.Z
		and math.abs(position.X) < 100000 and math.abs(position.Y) < 100000 and math.abs(position.Z) < 100000
end

-- Точная проверка сферы дрона против повернутого блока. Если центр уже внутри,
-- выбирается выход, ближайший к последней безопасной позиции, а не случайная грань.
local function overlapCorrection(part, position, safePosition)
	if not part.CanCollide or not part.CanQuery then
		return nil
	end
	local localPosition = part.CFrame:PointToObjectSpace(position)
	local half = part.Size * 0.5
	local closest = Vector3.new(
		math.clamp(localPosition.X, -half.X, half.X),
		math.clamp(localPosition.Y, -half.Y, half.Y),
		math.clamp(localPosition.Z, -half.Z, half.Z)
	)
	local delta = localPosition - closest
	local distance = delta.Magnitude
	if distance > 0.0001 then
		local normal = part.CFrame:VectorToWorldSpace(delta / distance).Unit
		local penetration = radiusForNormal(normal) + COLLISION_SKIN - distance
		if penetration > 0 then
			return normal * penetration, penetration
		end
		return nil
	end

	local bestCorrection
	local bestScore
	local function considerFace(normalLocal, faceDistance)
		local normal = part.CFrame:VectorToWorldSpace(normalLocal).Unit
		local penetration = faceDistance + radiusForNormal(normal) + COLLISION_SKIN
		local correction = normal * penetration
		local score = penetration
		if safePosition then
			score = (position + correction - safePosition).Magnitude + penetration * 0.05
		end
		if not bestScore or score < bestScore then
			bestCorrection = correction
			bestScore = score
		end
	end
	considerFace(Vector3.new(1, 0, 0), half.X - localPosition.X)
	considerFace(Vector3.new(-1, 0, 0), half.X + localPosition.X)
	considerFace(Vector3.new(0, 1, 0), half.Y - localPosition.Y)
	considerFace(Vector3.new(0, -1, 0), half.Y + localPosition.Y)
	considerFace(Vector3.new(0, 0, 1), half.Z - localPosition.Z)
	considerFace(Vector3.new(0, 0, -1), half.Z + localPosition.Z)
	if bestCorrection then
		return bestCorrection, bestCorrection.Magnitude
	end
	return nil
end

local function resolveOverlaps(state, position)
	local recovered = false
	local totalCorrection = 0
	local queryRadius = (Config.Drone.SideCollisionRadius or Config.Drone.CollisionRadius) + COLLISION_SKIN + 0.5
	for _ = 1, RECOVERY_ITERATIONS do
		local bestCorrection
		local bestDepth
		local parts = Workspace:GetPartBoundsInRadius(position, queryRadius, overlapParams) or {}
		for _, part in ipairs(parts) do
			local correction, depth = overlapCorrection(part, position, state.SafePosition)
			if correction and depth > 0.0001 and (not bestDepth or depth < bestDepth) then
				bestCorrection = correction
				bestDepth = depth
			end
		end
		if not bestCorrection then
			return position, recovered, true
		end
		if bestDepth > 30 or totalCorrection + bestDepth > 50 then
			return position, recovered, false
		end
		position = position + bestCorrection
		totalCorrection = totalCorrection + bestDepth
		recovered = true
		local normal = bestCorrection.Unit
		local into = state.Velocity:Dot(normal)
		if into < 0 then
			state.Velocity = state.Velocity - normal * into
		end
	end
	return position, recovered, false
end

local function moveWithSlide(state, startPosition, displacement, deltaTime)
	local position = startPosition
	local remaining = displacement
	local impactNormal
	for _ = 1, SLIDE_ITERATIONS do
		local distance = remaining.Magnitude
		if distance <= 0.0001 then
			break
		end
		local direction = remaining / distance
		local sideRadius = Config.Drone.SideCollisionRadius or Config.Drone.CollisionRadius
		local sweepRadius = math.abs(direction.Y) > 0.65 and Config.Drone.CollisionRadius or sideRadius
		local hit = Workspace:Raycast(position, direction * (distance + sweepRadius + COLLISION_SKIN), raycastParams)
		if not hit then
			position = position + remaining
			remaining = Vector3.zero
			break
		end

		impactNormal = hit.Normal
		local radius = radiusForNormal(hit.Normal) + COLLISION_SKIN
		local desiredEnd = position + remaining
		local contact = hit.Position + hit.Normal * radius
		local correction = contact - position
		if correction.Magnitude <= distance + radius * 2 + 1 then
			position = contact
			remaining = desiredEnd - contact
			remaining = remaining - hit.Normal * remaining:Dot(hit.Normal)
		else
			-- Не перескакиваем через карту при неожиданном результате луча.
			remaining = Vector3.zero
		end
		local into = state.Velocity:Dot(hit.Normal)
		if into < 0 then
			state.Velocity = state.Velocity - hit.Normal * into
		end
	end

	if impactNormal then
		state.Velocity = state.Velocity * 0.96
		local outward = state.Velocity:Dot(impactNormal)
		if outward < CONTACT_PUSH_SPEED then
			state.Velocity = state.Velocity + impactNormal * math.min(CONTACT_PUSH_SPEED - outward, 18 * deltaTime)
		end
		state.Model:SetAttribute("ImpactAt", os.clock())
	end
	return position, impactNormal ~= nil
end

local function applyTrackRepulsion(state, position, deltaTime)
	local closest, distance = Track.GetClosestPoint(position)
	local radius = Config.Boundary.TrackRadius
	local softStart = radius - Config.Boundary.TrackSoftZone
	if distance <= softStart or distance < 0.001 then
		return 0
	end
	local normal = (position - closest).Unit
	local warning = math.clamp((distance - softStart) / Config.Boundary.TrackSoftZone, 0, 1)
	local outward = state.Velocity:Dot(normal)
	if outward > 0 then
		local removal = math.min(outward, (outward * 7 + Config.Boundary.Pushback * 0.25) * warning * deltaTime)
		state.Velocity = state.Velocity - normal * removal
	end

	-- Ограниченная скорость отталкивания: не накапливает огромный отскок у стены.
	local inward = -state.Velocity:Dot(normal)
	local maxInward = Config.Boundary.TrackMaxRepulsionSpeed or 14
	if inward < maxInward then
		local push = math.min(Config.Boundary.Pushback * warning * deltaTime, maxInward - inward)
		state.Velocity = state.Velocity - normal * push
	end
	return warning
end

local function enforceTrackLimit(state, position)
	local closest, distance = Track.GetClosestPoint(position)
	local radius = Config.Boundary.TrackRadius
	if distance <= radius or distance < 0.001 then
		return position, 0
	end
	local normal = (position - closest).Unit
	local allowed = math.max(4, radius - radiusForNormal(normal) - COLLISION_SKIN)
	position = closest + normal * allowed
	local outward = state.Velocity:Dot(normal)
	if outward > 0 then
		state.Velocity = state.Velocity - normal * outward
	end
	return position, 1
end

function DroneService.Step(deltaTime)
	if not dronesFolder then
		return
	end

	for _, state in pairs(states) do
		if state.Active and state.Model and state.Model.Parent and state.Model.PrimaryPart then
			local input = state.Input
			if os.clock() - state.LastInput > 0.8 then
				input = { X = 0, Y = 0, Up = false, Down = false, Boost = false, Yaw = 0 }
			end

			local tuning = state.Tuning
			state.Yaw = state.Yaw - input.Yaw * Config.Drone.YawSpeed * tuning.Yaw * deltaTime
			local orientation = CFrame.Angles(0, state.Yaw, 0)
			local forward = orientation.LookVector
			local right = orientation.RightVector
			local speedMultiplier, boostAllowed = 1, true
			if combatProvider then
				speedMultiplier, boostAllowed = combatProvider(state.Player)
			end
			local boosting = input.Boost and input.Y > 0.2 and state.Boost > 0.5 and boostAllowed
			state.IsBoosting = boosting
			local baseSpeed = boosting and Config.Drone.BoostSpeed * tuning.BoostSpeed or Config.Drone.MaxSpeed * tuning.Speed
			local topSpeed = baseSpeed * speedMultiplier
			local boostCapacity = Config.Drone.BoostCapacity * tuning.Capacity

			if boosting then
				state.Boost = math.max(0, state.Boost - Config.Drone.BoostDrain * tuning.Drain * deltaTime)
			else
				state.Boost = math.min(boostCapacity, state.Boost + Config.Drone.BoostRecharge * tuning.Recharge * deltaTime)
			end

			local forwardInput = input.Y
			local forwardSpeed = topSpeed
			if forwardInput < 0 then
				forwardSpeed = Config.Drone.ReverseSpeed * tuning.Speed * speedMultiplier
			end
			local targetHorizontal = forward * forwardInput * forwardSpeed + right * input.X * topSpeed
			local verticalInput = (input.Up and 1 or 0) - (input.Down and 1 or 0)
			local targetVertical = verticalInput * Config.Drone.VerticalSpeed

			local currentHorizontal = Vector3.new(state.Velocity.X, 0, state.Velocity.Z)
			local inputMagnitude = math.sqrt(input.X * input.X + forwardInput * forwardInput)
			local horizontalResponse = Config.Drone.Acceleration * tuning.Acceleration
			if inputMagnitude < 0.05 then
				horizontalResponse = Config.Drone.Deceleration or 7.4
			elseif currentHorizontal:Dot(targetHorizontal) < 0 then
				horizontalResponse = horizontalResponse * 1.35
			end
			local horizontalAlpha = 1 - math.exp(-horizontalResponse * deltaTime)
			local verticalResponse = verticalInput ~= 0 and Config.Drone.VerticalAcceleration or (Config.Drone.VerticalDeceleration or 8.5)
			local verticalAlpha = 1 - math.exp(-verticalResponse * deltaTime)
			currentHorizontal = currentHorizontal:Lerp(targetHorizontal, horizontalAlpha)
			local vertical = state.Velocity.Y + (targetVertical - state.Velocity.Y) * verticalAlpha
			state.Velocity = Vector3.new(currentHorizontal.X, vertical, currentHorizontal.Z)

			local oldPosition = state.Model.PrimaryPart.Position
			if not finitePosition(oldPosition) then
				oldPosition = state.SafePosition or Vector3.zero
				state.Velocity = Vector3.zero
			end
			local center = Config.Boundary.Center
			local half = Config.Boundary.HalfSize
			local velocityX, warningX = softBoundaryAxis(oldPosition.X, state.Velocity.X, center.X - half.X, center.X + half.X, deltaTime)
			local velocityY, warningY = softBoundaryAxis(oldPosition.Y, state.Velocity.Y, center.Y - half.Y, center.Y + half.Y, deltaTime)
			local velocityZ, warningZ = softBoundaryAxis(oldPosition.Z, state.Velocity.Z, center.Z - half.Z, center.Z + half.Z, deltaTime)
			state.Velocity = Vector3.new(velocityX, velocityY, velocityZ)
			local trackWarning = applyTrackRepulsion(state, oldPosition, deltaTime)
			state.BoundaryWarning = math.max(warningX, warningY, warningZ, trackWarning)

			local newPosition = oldPosition + state.Velocity * deltaTime
			newPosition = moveWithSlide(state, oldPosition, newPosition - oldPosition, deltaTime)

			local boundedX, boundedVX, hitX = hardBoundaryAxis(newPosition.X, state.Velocity.X, center.X - half.X, center.X + half.X)
			local boundedY, boundedVY, hitY = hardBoundaryAxis(newPosition.Y, state.Velocity.Y, center.Y - half.Y, center.Y + half.Y)
			local boundedZ, boundedVZ, hitZ = hardBoundaryAxis(newPosition.Z, state.Velocity.Z, center.Z - half.Z, center.Z + half.Z)
			newPosition = Vector3.new(boundedX, boundedY, boundedZ)
			state.Velocity = Vector3.new(boundedVX, boundedVY, boundedVZ)
			local hardTrackWarning
			newPosition, hardTrackWarning = enforceTrackLimit(state, newPosition)
			state.BoundaryWarning = math.max(state.BoundaryWarning, hardTrackWarning)
			if hitX or hitY or hitZ then
				state.BoundaryWarning = 1
			end

			local resolvedPosition, _, resolved = resolveOverlaps(state, newPosition)
			local valid = resolved and finitePosition(resolvedPosition)
			if valid then
				local _, trackDistance = Track.GetClosestPoint(resolvedPosition)
				valid = trackDistance <= Config.Boundary.TrackRadius + 0.05
			end
			if valid then
				newPosition = resolvedPosition
				state.SafePosition = resolvedPosition
			else
				newPosition = state.SafePosition or oldPosition
				state.Velocity = Vector3.zero
				state.BoundaryWarning = 1
				state.Model:SetAttribute("RecoveryAt", Workspace:GetServerTimeNow())
			end

			local pitch = math.rad(-13) * input.Y
			local roll = math.rad(-11) * input.X
			local cframe = CFrame.new(newPosition) * CFrame.Angles(pitch, state.Yaw, roll)
			state.Model:PivotTo(cframe)

			state.AttributeClock = state.AttributeClock + deltaTime
			if state.AttributeClock >= 0.08 then
				state.AttributeClock = 0
				state.Model:SetAttribute("Speed", state.Velocity.Magnitude)
				state.Model:SetAttribute("Boost", state.Boost)
				state.Model:SetAttribute("BoundaryWarning", state.BoundaryWarning)
			end
		end
	end
end

return DroneService
