-- Монетки, combo-серии и серверный тюнинг. TECH нельзя получить через Robux.
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Track = require(Shared:WaitForChild("Track"))
local Tuning = require(Shared:WaitForChild("Tuning"))

local TuningService = {}

local DataService
local DroneService
local EngagementService
local remotes
local coinFolder
local coins = {}
local raceStates = {}
local lastActions = {}
local raceActive = false
local spawnSerial = 0

local GOLD = Color3.fromRGB(255, 205, 55)
local AMBER = Color3.fromRGB(255, 126, 35)
local WHITE = Color3.fromRGB(255, 252, 214)

local function serverNow()
	return Workspace:GetServerTimeNow()
end

local function notify(player, text, kind)
	if player and player.Parent then
		remotes.Notify:FireClient(player, text, kind or "info")
	end
end

local function makePart(model, name, size, cframe, color, material)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.CFrame = cframe
	part.Color = color
	part.Material = material or Enum.Material.Metal
	part.Anchored = true
	part.CanCollide = false
	part.CanTouch = false
	part.CanQuery = false
	part.CastShadow = false
	part.Parent = model
	return part
end

local function addCoinFace(part, face)
	local surface = Instance.new("SurfaceGui")
	surface.Name = "CoinFace"
	surface.Face = face
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 12
	surface.LightInfluence = 0
	surface.Parent = part
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.Code
	text.Text = "A"
	text.TextScaled = true
	text.TextColor3 = WHITE
	text.Parent = surface
end

local function buildCoin(index, cframe)
	local model = Instance.new("Model")
	model.Name = string.format("Coin_%02d", index)
	model:SetAttribute("CoinIndex", index)
	model:SetAttribute("Phase", index * 0.73)
	model:SetAttribute("SpawnVersion", 0)
	model:SetAttribute("BasePosition", cframe.Position)
	model:SetAttribute("BaseLook", cframe.LookVector)
	model:SetAttribute("BaseUp", cframe.UpVector)
	CollectionService:AddTag(model, "AeroRushCoin")

	local rim = makePart(model, "Rim", Vector3.new(0.35, 2.8, 2.8), cframe, GOLD, Enum.Material.Metal)
	rim.Shape = Enum.PartType.Cylinder
	model.PrimaryPart = rim
	local center = makePart(model, "Center", Vector3.new(0.43, 2.22, 2.22), cframe, AMBER, Enum.Material.Metal)
	center.Shape = Enum.PartType.Cylinder
	addCoinFace(center, Enum.NormalId.Front)
	addCoinFace(center, Enum.NormalId.Back)

	local sparkles = Instance.new("ParticleEmitter")
	sparkles.Name = "Sparkles"
	sparkles.Rate = 1.4
	sparkles.Lifetime = NumberRange.new(0.5, 1.1)
	sparkles.Speed = NumberRange.new(0.25, 0.65)
	sparkles.SpreadAngle = Vector2.new(180, 180)
	sparkles.Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.16),
		NumberSequenceKeypoint.new(1, 0),
	})
	sparkles.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.25),
		NumberSequenceKeypoint.new(1, 1),
	})
	sparkles.Color = ColorSequence.new(GOLD, WHITE)
	sparkles.LightEmission = 0.15
	sparkles.Parent = center
	return model
end

local function spawnCoin(coin)
	spawnSerial = spawnSerial + 1
	coin.Active = true
	coin.RespawnAt = 0
	coin.Model:PivotTo(coin.BaseCFrame)
	coin.Model:SetAttribute("SpawnVersion", spawnSerial)
	coin.Model.Parent = coinFolder
end

local function hideCoin(coin)
	coin.Active = false
	coin.RespawnAt = 0
	coin.Model.Parent = nil
end

local function canManage(player)
	local phase = ReplicatedStorage.AeroRushState:GetAttribute("Phase")
	return phase == "Intermission" or player:GetAttribute("Racing") ~= true or player:GetAttribute("Finished") == true
end

local function collectCoin(player, coin)
	local state = raceStates[player.UserId]
	local data = DataService.Get(player)
	if not state or not data or state.Coins >= Config.Coins.MaxPerRacer then
		return false
	end
	local now = serverNow()
	state.Coins = state.Coins + 1
	local previousCombo = tonumber(state.Combo) or 0
	local combo = 1
	if now <= state.ComboEndsAt then
		combo = math.min(99, previousCombo + 1)
	end
	state.Combo = combo
	state.ComboEndsAt = now + Config.Coins.ComboDuration
	local reward = 1 + (combo % 5 == 0 and 1 or 0)
	data.Tech = data.Tech + reward
	data.CoinBalance = data.CoinBalance + 1
	data.LifetimeCoins = data.LifetimeCoins + 1
	data.BestCoinCombo = math.max(data.BestCoinCombo, combo)
	player:SetAttribute("RaceCoins", state.Coins)
	player:SetAttribute("CoinCombo", combo)
	player:SetAttribute("CoinComboEndsAt", state.ComboEndsAt)
	DroneService.AddBoost(player, Config.Coins.BaseBoost + math.min(8, combo))
	EngagementService.OnCoin(player)

	coin.Active = false
	coin.RespawnAt = now + Config.Coins.RespawnDelay
	coin.Model.Parent = nil
	remotes.CoinFX:FireAllClients({
		UserId = player.UserId,
		Position = coin.BaseCFrame.Position,
		Combo = combo,
		Reward = reward,
		RaceCoins = state.Coins,
	})
	if combo % 5 == 0 then
		notify(player, string.format("МОНЕТНАЯ СЕРИЯ ×%d · бонус +1 TECH", combo), "success")
	end
	return true
end

function TuningService.GetMovement(player)
	local data = DataService.Get(player)
	return Tuning.GetStats(data or {})
end

function TuningService.HandleAction(player, action, value)
	if type(action) ~= "string" or type(value) ~= "string" then
		return
	end
	local now = os.clock()
	if now - (lastActions[player.UserId] or 0) < 0.3 then
		return
	end
	lastActions[player.UserId] = now
	if not canManage(player) then
		notify(player, "Тюнинг доступен в лобби или после финиша", "warning")
		return
	end
	local data = DataService.Get(player)
	if not data then
		return
	end

	if action == "EquipPreset" then
		local preset = Tuning.GetPreset(value)
		if preset.Id ~= value then
			return
		end
		data.TuningPreset = preset.Id
		DataService.Commit(player, false)
		notify(player, preset.Name .. ": настройка применится к следующему дрону", "success")
	elseif action == "Upgrade" then
		local module = Tuning.GetModule(value)
		if not module then
			return
		end
		local level = Tuning.GetLevel(data, module.Id)
		if level >= Tuning.MaxModuleLevel then
			notify(player, module.Name .. ": максимальный уровень", "info")
			return
		end
		local cost = Tuning.ModuleCosts[level + 1]
		if data.Tech < cost then
			notify(player, string.format("Нужно %d TECH · собирайте монетки и финишируйте", cost), "warning")
			return
		end
		data.Tech = data.Tech - cost
		data.UpgradeLevels[module.Id] = level + 1
		DataService.Commit(player, true)
		notify(player, string.format("%s улучшен до уровня %d · применится на следующем дроне", module.Name, level + 1), "success")
	end
end

function TuningService.StartRace()
	raceActive = true
	for _, player in ipairs(Players:GetPlayers()) do
		raceStates[player.UserId] = { Coins = 0, Combo = 0, ComboEndsAt = 0 }
		player:SetAttribute("RaceCoins", 0)
		player:SetAttribute("CoinCombo", 0)
		player:SetAttribute("CoinComboEndsAt", 0)
	end
	for _, coin in ipairs(coins) do
		spawnCoin(coin)
	end
end

function TuningService.EndRace()
	raceActive = false
	for _, coin in ipairs(coins) do
		hideCoin(coin)
	end
	for _, player in ipairs(Players:GetPlayers()) do
		local state = raceStates[player.UserId]
		if state then
			state.Combo = 0
			state.ComboEndsAt = 0
		end
		player:SetAttribute("CoinCombo", 0)
		player:SetAttribute("CoinComboEndsAt", 0)
	end
end

function TuningService.Step(_deltaTime)
	if not raceActive then
		return
	end
	local now = serverNow()
	local collectors = {}
	for _, player in ipairs(Players:GetPlayers()) do
		local state = raceStates[player.UserId]
		if state then
			if state.Combo > 0 and now > state.ComboEndsAt then
				state.Combo = 0
				state.ComboEndsAt = 0
				player:SetAttribute("CoinCombo", 0)
				player:SetAttribute("CoinComboEndsAt", 0)
			end
			local drone = player:GetAttribute("Racing") == true and not player:GetAttribute("Finished") and DroneService.GetModel(player) or nil
			local root = drone and drone.PrimaryPart
			if root and state.Coins < Config.Coins.MaxPerRacer then
				table.insert(collectors, { Player = player, Position = root.Position })
			end
		end
	end

	for _, coin in ipairs(coins) do
		if not coin.Active and coin.RespawnAt > 0 and now >= coin.RespawnAt then
			spawnCoin(coin)
		end
		if coin.Active then
			for _, collector in ipairs(collectors) do
				if (collector.Position - coin.BaseCFrame.Position).Magnitude <= Config.Coins.PickupRadius then
					if collectCoin(collector.Player, coin) then
						break
					end
				end
			end
		end
	end
end

function TuningService.OnPlayerRemoving(player)
	raceStates[player.UserId] = nil
	lastActions[player.UserId] = nil
end

function TuningService.Init(dependencies)
	DataService = dependencies.DataService
	DroneService = dependencies.DroneService
	EngagementService = dependencies.EngagementService
	remotes = dependencies.Remotes
	coinFolder = Instance.new("Folder")
	coinFolder.Name = "CoinRush"
	coinFolder.Parent = dependencies.World.Root

	local offsets = { 0.22, 0.43, 0.74 }
	local index = 0
	for gateIndex, gate in ipairs(Track.Gates) do
		local nextGate = Track.Gates[gateIndex % #Track.Gates + 1]
		for slot = 1, Config.Coins.PerSegment do
			index = index + 1
			local position = gate.Position:Lerp(nextGate.Position, offsets[slot] or (slot / (Config.Coins.PerSegment + 1)))
			local orientation = CFrame.lookAt(position, nextGate.Position)
			local side = ((gateIndex + slot) % 3 - 1) * 9
			local height = ((gateIndex + slot * 2) % 3 - 1) * 4
			local cframe = orientation * CFrame.new(side, height, 0) * CFrame.Angles(0, math.rad(90), 0)
			local model = buildCoin(index, cframe)
			coins[index] = { Model = model, BaseCFrame = cframe, Active = false, RespawnAt = 0 }
		end
	end
end

return TuningService
