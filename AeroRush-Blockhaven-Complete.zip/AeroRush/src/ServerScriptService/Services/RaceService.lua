-- Главный конечный автомат заезда и серверная проверка контрольных точек.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Track = require(Shared:WaitForChild("Track"))

local RaceService = {}

local DataService
local DroneService
local EngagementService
local CombatService
local TuningService
local WorldBuilder
local remotes
local stateFolder
local world

local phase = "Boot"
local phaseEndsAt = 0
local raceStartAt = 0
local participants = {}
local queued = {}
local finishCounter = 0
local lastCountdownValue
local leaderboardClock = 0
local lastResets = {}
local lastInputs = {}
local lastLobbyActions = {}
local characterLoading = {}

local function serverNow()
	return Workspace:GetServerTimeNow()
end

local function setPhase(nextPhase, duration)
	phase = nextPhase
	phaseEndsAt = serverNow() + (duration or 0)
	stateFolder:SetAttribute("Phase", phase)
	stateFolder:SetAttribute("PhaseEndsAt", phaseEndsAt)
end

local function notify(player, text, kind)
	if player and player.Parent then
		remotes.Notify:FireClient(player, text, kind or "info")
	end
end

local function getQueuedPlayers()
	local list = {}
	for player in pairs(queued) do
		if player.Parent then
			table.insert(list, player)
		else
			queued[player] = nil
		end
	end
	table.sort(list, function(a, b)
		return a.UserId < b.UserId
	end)
	return list
end

local function resetRaceAttributes(player)
	player:SetAttribute("Racing", false)
	player:SetAttribute("Queued", false)
	player:SetAttribute("Finished", false)
	player:SetAttribute("Lap", 0)
	player:SetAttribute("Gate", 0)
	player:SetAttribute("Place", 0)
	player:SetAttribute("FinishTime", 0)
	player:SetAttribute("LastLap", 0)
	player:SetAttribute("RaceBestLap", 0)
	player:SetAttribute("RaceEliminations", 0)
	player:SetAttribute("RaceRatingDelta", 0)
	player:SetAttribute("BlasterCooldown", 0)
	player:SetAttribute("RaceCoins", 0)
	player:SetAttribute("CoinCombo", 0)
	player:SetAttribute("CoinComboEndsAt", 0)
end

local function loadLobbyCharacter(player)
	if characterLoading[player.UserId] then
		return
	end
	characterLoading[player.UserId] = true
	task.spawn(function()
		if player.Parent and not player:GetAttribute("Racing") then
			local ok, err = pcall(function()
				player:LoadCharacter()
			end)
			if not ok then
				warn("[AERORUSH] Не удалось создать персонажа: " .. tostring(err))
			end
		end
		characterLoading[player.UserId] = nil
	end)
end

local function progressOf(participant)
	local passed = (participant.NextCheckpoint - 2) % #Track.Gates
	return (participant.Lap - 1) * #Track.Gates + passed
end

local function sortedParticipants()
	local list = {}
	for _, participant in pairs(participants) do
		if participant.Player.Parent then
			table.insert(list, participant)
		end
	end
	table.sort(list, function(a, b)
		if a.Finished ~= b.Finished then
			return a.Finished
		end
		if a.Finished and b.Finished and a.FinishPlace ~= b.FinishPlace then
			return a.FinishPlace < b.FinishPlace
		end
		local aProgress = progressOf(a)
		local bProgress = progressOf(b)
		if aProgress ~= bProgress then
			return aProgress > bProgress
		end
		local aGate = world.Gates[a.NextCheckpoint]
		local bGate = world.Gates[b.NextCheckpoint]
		local aDistance = (DroneService.GetPosition(a.Player) - aGate.CFrame.Position).Magnitude
		local bDistance = (DroneService.GetPosition(b.Player) - bGate.CFrame.Position).Magnitude
		if math.abs(aDistance - bDistance) > 0.01 then
			return aDistance < bDistance
		end
		return a.Player.UserId < b.Player.UserId
	end)
	return list
end

local function sendLeaderboard()
	local entries = {}
	for index, participant in ipairs(sortedParticipants()) do
		local player = participant.Player
		local place = participant.FinishPlace > 0 and participant.FinishPlace or index
		if not participant.Finished then
			player:SetAttribute("Place", place)
		end
		table.insert(entries, {
			UserId = player.UserId,
			Name = player.DisplayName,
			Place = place,
			Lap = participant.Lap,
			Gate = participant.NextCheckpoint,
			Speed = math.floor(DroneService.GetSpeed(player) + 0.5),
			Finished = participant.Finished,
			FinishTime = participant.FinishTime,
			AeroClub = player:GetAttribute("AeroClub") == true,
			Rating = player:GetAttribute("Rating") or Config.Rating.StartingRating,
			Eliminations = participant.Eliminations or 0,
		})
	end
	remotes.Leaderboard:FireAllClients(entries)
end

local function buildResults()
	local results = {}
	for _, participant in ipairs(sortedParticipants()) do
		table.insert(results, {
			UserId = participant.Player.UserId,
			Name = participant.Player.DisplayName,
			Place = participant.FinishPlace,
			FinishTime = participant.FinishTime,
			BestLap = participant.BestLap,
			Finished = participant.Finished,
			AeroClub = participant.Player:GetAttribute("AeroClub") == true,
			Rating = participant.Rating or participant.Player:GetAttribute("Rating") or Config.Rating.StartingRating,
			RatingDelta = participant.RatingDelta or 0,
			Rated = participant.Rated == true,
			Eliminations = participant.Eliminations or 0,
		})
	end
	return results
end

local function applyRatings()
	local entries = sortedParticipants()
	if #entries < 2 then
		for _, participant in ipairs(entries) do
			participant.Rated = false
			participant.RatingDelta = 0
			participant.Rating = participant.Player:GetAttribute("Rating") or Config.Rating.StartingRating
		end
		return
	end

	local deltas = {}
	local pairWeight = Config.Rating.KFactor / (#entries - 1)
	for index, participant in ipairs(entries) do
		local score = 0
		for opponentIndex, opponent in ipairs(entries) do
			if opponentIndex ~= index then
				local expected = 1 / (1 + 10 ^ ((opponent.RatingStart - participant.RatingStart) / 400))
				local actual = index < opponentIndex and 1 or 0
				score = score + actual - expected
			end
		end
		deltas[participant] = math.floor(pairWeight * score + 0.5)
	end

	for _, participant in ipairs(entries) do
		local player = participant.Player
		if DataService.Get(player) then
			local delta, rating = DataService.ApplyRating(player, deltas[participant])
			participant.Rated = true
			participant.RatingDelta = delta
			participant.Rating = rating
			player:SetAttribute("RaceRatingDelta", delta)
		else
			participant.Rated = false
			participant.RatingDelta = 0
			participant.Rating = participant.RatingStart
		end
	end
end

local function finishRound()
	if phase ~= "Racing" then
		return
	end
	applyRatings()
	for _, participant in pairs(participants) do
		DroneService.SetActive(participant.Player, false)
	end
	setPhase("PostRace", Config.PostRaceDuration)
	CombatService.EndRace()
	TuningService.EndRace()
	sendLeaderboard()
	remotes.Results:FireAllClients(buildResults())
end

local function finishPlayer(participant)
	if participant.Finished then
		return
	end
	finishCounter = finishCounter + 1
	participant.Finished = true
	participant.FinishPlace = finishCounter
	participant.FinishTime = serverNow() - raceStartAt
	local player = participant.Player
	player:SetAttribute("Finished", true)
	player:SetAttribute("Place", finishCounter)
	player:SetAttribute("FinishTime", participant.FinishTime)
	DroneService.SetActive(player, false)
	if finishCounter == 1 then
		remotes.Celebration:FireAllClients(player.UserId, player.DisplayName)
	end

	local reward: number, isRecord: boolean, info = EngagementService.OnFinish(player, finishCounter, participant.BestLap)
	local message = string.format("Финиш: #%d · +%d кредитов · +%d XP · +%d TECH", finishCounter, reward, info.XP, info.Tech or 0)
	if info.BoostActive then
		message = message .. " · 2× BOOST"
	end
	if info.PartyBonus > 0 then
		message = message .. string.format(" · друзья +%d%%", math.floor(info.PartyBonus * 100))
	end
	if isRecord then
		message = message .. " · новый рекорд!"
	end
	notify(player, message, "success")
end

local function crossedGate(gate, previousPosition, currentPosition)
	local previous = gate.CFrame:PointToObjectSpace(previousPosition)
	local current = gate.CFrame:PointToObjectSpace(currentPosition)
	-- Правильное направление: из локального +Z в -Z.
	if previous.Z < 0 or current.Z > 0 or previous.Z == current.Z then
		return false
	end
	local alpha = previous.Z / (previous.Z - current.Z)
	if alpha < 0 or alpha > 1 then
		return false
	end
	local x = previous.X + (current.X - previous.X) * alpha
	local y = previous.Y + (current.Y - previous.Y) * alpha
	return math.abs(x) <= gate.Width / 2 and math.abs(y) <= gate.Height / 2
end

local function checkCheckpoint(participant, currentPosition)
	local gate = world.Gates[participant.NextCheckpoint]
	if not crossedGate(gate, participant.LastPosition, currentPosition) then
		return
	end

	local passedIndex = participant.NextCheckpoint
	EngagementService.OnGate(participant.Player)
	participant.RespawnCFrame = gate.CFrame * CFrame.new(0, 0, -10)
	local player = participant.Player

	if passedIndex == 1 then
		local lapTime = serverNow() - participant.LapStart
		participant.LastLap = lapTime
		if participant.BestLap == 0 or lapTime < participant.BestLap then
			participant.BestLap = lapTime
		end
		player:SetAttribute("LastLap", lapTime)
		player:SetAttribute("RaceBestLap", participant.BestLap)

		if participant.Lap >= Config.Laps then
			finishPlayer(participant)
			return
		end
		participant.Lap = participant.Lap + 1
		participant.LapStart = serverNow()
		participant.NextCheckpoint = 2
	else
		participant.NextCheckpoint = passedIndex % #Track.Gates + 1
	end

	player:SetAttribute("Lap", participant.Lap)
	player:SetAttribute("Gate", participant.NextCheckpoint)
	remotes.Checkpoint:FireClient(player, passedIndex, participant.NextCheckpoint, participant.Lap)
end

local function resetPlayer(player, automatic, reboot)
	local participant = participants[player.UserId]
	if phase ~= "Racing" or not participant or participant.Finished then
		return false
	end
	reboot = reboot == true or CombatService.NeedsReboot(player)
	local now = os.clock()
	if not automatic and now - (lastResets[player.UserId] or 0) < Config.ResetCooldown then
		return false
	end
	lastResets[player.UserId] = now
	DroneService.Reset(player, participant.RespawnCFrame)
	participant.LastPosition = participant.RespawnCFrame.Position
	CombatService.OnRespawn(player, reboot == true, reboot and 2 or (automatic and 1 or 0))
	if not automatic then
		notify(player, "Дрон восстановлен на последнем гейте", "info")
	end
	return true
end

local function updateRacers(deltaTime)
	DroneService.Step(deltaTime)
	CombatService.Step(deltaTime)
	TuningService.Step(deltaTime)
	for _, participant in pairs(participants) do
		local player = participant.Player
		if player.Parent and not participant.Finished then
			if DroneService.IsBoosting(player) then
				EngagementService.OnBoost(player, deltaTime)
			end
			if CombatService.NeedsReboot(player) then
				resetPlayer(player, true, true)
			else
				local position = DroneService.GetPosition(player)
				if position.Y < Config.Drone.KillY then
					resetPlayer(player, true)
				else
					checkCheckpoint(participant, position)
					participant.LastPosition = position
				end
			end
		end
	end
end

function RaceService.StartIntermission()
	CombatService.EndRace()
	TuningService.EndRace()
	participants = {}
	queued = {}
	finishCounter = 0
	lastCountdownValue = nil
	leaderboardClock = 0
	stateFolder:SetAttribute("RaceStartAt", 0)
	stateFolder:SetAttribute("Racers", 0)
	stateFolder:SetAttribute("Queued", 0)
	stateFolder:SetAttribute("Countdown", 0)
	setPhase("Intermission", 0)
	phaseEndsAt = 0
	stateFolder:SetAttribute("PhaseEndsAt", 0)
	remotes.Leaderboard:FireAllClients({})

	for _, player in ipairs(Players:GetPlayers()) do
		DroneService.Remove(player)
		resetRaceAttributes(player)
		loadLobbyCharacter(player)
	end
end

function RaceService.BeginCountdown()
	local players = getQueuedPlayers()
	if #players < Config.MinRacers then
		RaceService.StartIntermission()
		return
	end
	queued = {}

	participants = {}
	finishCounter = 0
	local racerCount = math.min(#players, Config.MaxRacers)
	for index = 1, racerCount do
		local player = players[index]
		if player.Character then
			player.Character:Destroy()
		end
		resetRaceAttributes(player)
		player:SetAttribute("Racing", true)
		player:SetAttribute("Lap", 1)
		player:SetAttribute("Gate", 2)

		local gridCFrame = Track.GetGridCFrame(index)
		local data = DataService.Get(player)
		local ratingStart = data and data.Rating or Config.Rating.StartingRating
		DroneService.Spawn(player, gridCFrame)
		participants[player.UserId] = {
			Player = player,
			Lap = 1,
			NextCheckpoint = 2,
			LastPosition = gridCFrame.Position,
			RespawnCFrame = gridCFrame,
			LapStart = 0,
			LastLap = 0,
			BestLap = 0,
			Eliminations = 0,
			RatingStart = ratingStart,
			RatingDelta = 0,
			Rated = false,
			Finished = false,
			FinishPlace = 0,
			FinishTime = 0,
		}
	end

	for index = racerCount + 1, #players do
		resetRaceAttributes(players[index])
		notify(players[index], "Сетка заполнена: вы зритель этого заезда", "info")
	end

	stateFolder:SetAttribute("Racers", racerCount)
	stateFolder:SetAttribute("Queued", 0)
	setPhase("Countdown", Config.CountdownDuration)
	lastCountdownValue = nil
	sendLeaderboard()
end

function RaceService.BeginRace()
	local count = 0
	for _ in pairs(participants) do
		count = count + 1
	end
	if count == 0 then
		RaceService.StartIntermission()
		return
	end

	raceStartAt = serverNow()
	stateFolder:SetAttribute("RaceStartAt", raceStartAt)
	CombatService.StartRace()
	TuningService.StartRace()
	for _, participant in pairs(participants) do
		participant.LapStart = raceStartAt
		participant.LastPosition = DroneService.GetPosition(participant.Player)
		DroneService.SetActive(participant.Player, true)
	end
	setPhase("Racing", Config.RaceTimeLimit)
	sendLeaderboard()
end

function RaceService.OnElimination(source, target)
	if phase ~= "Racing" or not source or not target or source == target then
		return
	end
	local victim = participants[target.UserId]
	local attacker = participants[source.UserId]
	if not victim or victim.Finished or not attacker then
		return
	end
	attacker.Eliminations = attacker.Eliminations + 1
	source:SetAttribute("RaceEliminations", attacker.Eliminations)
	DataService.RecordElimination(source)
	notify(source, string.format("ВЫВЕДЕН ИЗ СТРОЯ: %s · +1 к статистике", target.DisplayName), "success")
end

function RaceService.HandleLobbyAction(player, action)
	if type(action) ~= "string" then
		return
	end
	local current = os.clock()
	if current - (lastLobbyActions[player.UserId] or 0) < 0.25 then
		return
	end
	lastLobbyActions[player.UserId] = current

	if action == "JoinRace" or action == "StartRace" then
		if player:GetAttribute("Racing") then
			return
		end
		if phase ~= "Intermission" then
			notify(player, "Гонка уже идёт. Останьтесь в лобби и нажмите старт после финиша", "info")
			return
		end
		queued[player] = true
		player:SetAttribute("Queued", true)
		stateFolder:SetAttribute("Queued", #getQueuedPlayers())
		if action == "StartRace" then
			RaceService.BeginCountdown()
			return
		end
		if phaseEndsAt <= 0 then
			phaseEndsAt = serverNow() + Config.IntermissionDuration
			stateFolder:SetAttribute("PhaseEndsAt", phaseEndsAt)
		end
		notify(player, "Вы в очереди. Можно продолжать настраивать дрон до старта", "success")
	elseif action == "LeaveQueue" then
		queued[player] = nil
		player:SetAttribute("Queued", false)
		local count = #getQueuedPlayers()
		stateFolder:SetAttribute("Queued", count)
		if count == 0 then
			phaseEndsAt = 0
			stateFolder:SetAttribute("PhaseEndsAt", 0)
		end
	end
end

function RaceService.OnPlayerAdded(player)
	resetRaceAttributes(player)
	player.CharacterAdded:Connect(function(character)
		local humanoid = character:WaitForChild("Humanoid", 5)
		if humanoid then
			humanoid.Died:Connect(function()
				task.delay(2, function()
					if player.Parent and not player:GetAttribute("Racing") then
						loadLobbyCharacter(player)
					end
				end)
			end)
		end
	end)
	loadLobbyCharacter(player)
	if phase == "Racing" or phase == "Countdown" then
		notify(player, "Заезд уже идёт. Оставайтесь в лобби — старт будет доступен после финиша", "info")
	end
end

function RaceService.OnPlayerRemoving(player)
	participants[player.UserId] = nil
	queued[player] = nil
	lastResets[player.UserId] = nil
	lastInputs[player.UserId] = nil
	lastLobbyActions[player.UserId] = nil
	characterLoading[player.UserId] = nil
	DroneService.Remove(player)
	CombatService.Remove(player)
	TuningService.OnPlayerRemoving(player)
	if phase == "Intermission" then
		local count = #getQueuedPlayers()
		stateFolder:SetAttribute("Queued", count)
		if count == 0 then
			phaseEndsAt = 0
			stateFolder:SetAttribute("PhaseEndsAt", 0)
		end
	end
	if phase == "Countdown" or phase == "Racing" then
		local remaining = 0
		local unfinished = 0
		for _, participant in pairs(participants) do
			remaining = remaining + 1
			if not participant.Finished then
				unfinished = unfinished + 1
			end
		end
		stateFolder:SetAttribute("Racers", remaining)
		if remaining == 0 then
			RaceService.StartIntermission()
		elseif phase == "Racing" and unfinished == 0 then
			finishRound()
		end
	end
end

function RaceService.HandleInput(player, payload)
	local participant = participants[player.UserId]
	if phase ~= "Racing" or not participant or participant.Finished then
		return
	end
	local now = os.clock()
	if now - (lastInputs[player.UserId] or 0) < 1 / 60 then
		return
	end
	lastInputs[player.UserId] = now
	DroneService.SetInput(player, payload)
end

function RaceService.RequestReset(player)
	resetPlayer(player, false)
end

function RaceService.Step(deltaTime)
	WorldBuilder.Step(deltaTime)
	local now = serverNow()

	if phase == "Intermission" then
		local queueCount = #getQueuedPlayers()
		stateFolder:SetAttribute("Queued", queueCount)
		if queueCount < Config.MinRacers then
			phaseEndsAt = 0
			stateFolder:SetAttribute("PhaseEndsAt", 0)
		elseif phaseEndsAt <= 0 then
			phaseEndsAt = now + Config.IntermissionDuration
			stateFolder:SetAttribute("PhaseEndsAt", phaseEndsAt)
		elseif now >= phaseEndsAt then
			RaceService.BeginCountdown()
		end
	elseif phase == "Countdown" then
		local countdown = math.max(0, math.ceil(phaseEndsAt - now))
		if countdown ~= lastCountdownValue then
			lastCountdownValue = countdown
			stateFolder:SetAttribute("Countdown", countdown)
		end
		if now >= phaseEndsAt then
			RaceService.BeginRace()
		end
	elseif phase == "Racing" then
		updateRacers(deltaTime)
		leaderboardClock = leaderboardClock + deltaTime
		if leaderboardClock >= 0.25 then
			leaderboardClock = 0
			sendLeaderboard()
		end

		local unfinished = 0
		for _, participant in pairs(participants) do
			if not participant.Finished then
				unfinished = unfinished + 1
			end
		end
		if now >= phaseEndsAt then
			finishRound()
		elseif unfinished == 0 then
			finishRound()
		end
	elseif phase == "PostRace" and now >= phaseEndsAt then
		RaceService.StartIntermission()
	end
end

function RaceService.Init(dependencies)
	DataService = dependencies.DataService
	DroneService = dependencies.DroneService
	EngagementService = dependencies.EngagementService
	CombatService = dependencies.CombatService
	TuningService = dependencies.TuningService
	WorldBuilder = dependencies.WorldBuilder
	remotes = dependencies.Remotes
	world = dependencies.World
	CombatService.SetEliminationHandler(RaceService.OnElimination)

	stateFolder = ReplicatedStorage:FindFirstChild("AeroRushState") or Instance.new("Folder")
	stateFolder.Name = "AeroRushState"
	stateFolder:SetAttribute("GameName", Config.GameName)
	stateFolder:SetAttribute("TrackName", Config.TrackName)
	stateFolder:SetAttribute("Laps", Config.Laps)
	stateFolder:SetAttribute("GateCount", #Track.Gates)
	stateFolder:SetAttribute("MaxRacers", Config.MaxRacers)
	stateFolder.Parent = ReplicatedStorage
	RaceService.StartIntermission()
end

return RaceService
