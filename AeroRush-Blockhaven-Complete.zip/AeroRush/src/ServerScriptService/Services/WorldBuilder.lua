-- Процедурный voxel-мир Blockhaven: обложечные арки, утёсы, лавки и навигация.
local Lighting = game:GetService("Lighting")
local Workspace = game:GetService("Workspace")

local Shared = game:GetService("ReplicatedStorage"):WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Track = require(Shared:WaitForChild("Track"))

local WorldBuilder = {}

local C = {
	Grass = Color3.fromRGB(106, 166, 56),
	GrassLight = Color3.fromRGB(142, 190, 64),
	Dirt = Color3.fromRGB(143, 100, 56),
	Stone = Color3.fromRGB(117, 127, 128),
	StoneDark = Color3.fromRGB(65, 75, 77),
	Wood = Color3.fromRGB(177, 126, 63),
	WoodDark = Color3.fromRGB(104, 70, 37),
	Leaves = Color3.fromRGB(77, 139, 44),
	LeavesLight = Color3.fromRGB(111, 165, 52),
	Sand = Color3.fromRGB(218, 188, 116),
	White = Color3.fromRGB(246, 248, 232),
	Blue = Color3.fromRGB(45, 157, 203),
	Red = Color3.fromRGB(201, 75, 52),
	Gold = Color3.fromRGB(244, 188, 45),
	Orange = Color3.fromRGB(235, 139, 44),
}

local sweepers = {}

local function makePart(parent, name, size, cframe, color, material)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.CFrame = cframe
	part.Color = color or C.Stone
	part.Material = material or Enum.Material.SmoothPlastic
	part.Anchored = true
	part.CanCollide = false
	part.CanTouch = false
	part.CanQuery = false
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	part.Parent = parent
	return part
end

local function beamBetween(parent, name, a, b, thickness, color, material)
	local direction = b - a
	if direction.Magnitude < 0.05 then
		return nil
	end
	return makePart(parent, name, Vector3.new(thickness, thickness, direction.Magnitude), CFrame.lookAt((a + b) * 0.5, b), color, material)
end

local function addBillboard(parent, name, title, subtitle, accent, maxDistance)
	local billboard = Instance.new("BillboardGui")
	billboard.Name = name
	billboard.Size = UDim2.fromOffset(250, 72)
	billboard.AlwaysOnTop = true
	billboard.MaxDistance = maxDistance or 460
	billboard.Parent = parent
	local heading = Instance.new("TextLabel")
	heading.Name = "Title"
	heading.Size = UDim2.new(1, 0, 0.56, 0)
	heading.BackgroundTransparency = 1
	heading.Font = Enum.Font.Code
	heading.Text = title
	heading.TextColor3 = accent
	heading.TextStrokeColor3 = C.StoneDark
	heading.TextStrokeTransparency = 0.25
	heading.TextScaled = true
	heading.Parent = billboard
	local detail = Instance.new("TextLabel")
	detail.Name = "Subtitle"
	detail.Position = UDim2.fromScale(0, 0.62)
	detail.Size = UDim2.new(1, 0, 0.3, 0)
	detail.BackgroundTransparency = 1
	detail.Font = Enum.Font.Code
	detail.Text = subtitle
	detail.TextColor3 = C.White
	detail.TextStrokeColor3 = C.StoneDark
	detail.TextStrokeTransparency = 0.35
	detail.TextScaled = true
	detail.Parent = billboard
	return billboard
end

local function buildVoxelArrow(parent, name, cframe, scale, color)
	scale = scale or 1
	color = color or C.Gold
	makePart(parent, name .. "Shaft", Vector3.new(1.3, 0.7, 5.6) * scale, cframe * CFrame.new(0, 0, 1.1 * scale), color, Enum.Material.Brick)
	makePart(parent, name .. "Tip", Vector3.new(2.1, 0.8, 2.1) * scale, cframe * CFrame.new(0, 0, -2.4 * scale), color, Enum.Material.Brick)
	makePart(parent, name .. "Left", Vector3.new(1.3, 0.7, 4.2) * scale, cframe * CFrame.new(-1.55 * scale, 0, -1.55 * scale) * CFrame.Angles(0, math.rad(-45), 0), color, Enum.Material.Brick)
	makePart(parent, name .. "Right", Vector3.new(1.3, 0.7, 4.2) * scale, cframe * CFrame.new(1.55 * scale, 0, -1.55 * scale) * CFrame.Angles(0, math.rad(45), 0), color, Enum.Material.Brick)
end

local function addGateLabel(root, index, height)
	local accent = index == 1 and C.Gold or (index % 3 == 0 and C.Red or C.Blue)
	local labelPart = Instance.new("Part")
	labelPart.Name = "NumberAnchor"
	labelPart.Size = Vector3.one
	labelPart.Transparency = 1
	labelPart.Anchored = true
	labelPart.CanCollide = false
	labelPart.CanTouch = false
	labelPart.CanQuery = false
	labelPart.CFrame = root.CFrame * CFrame.new(0, height / 2 + 11, 0)
	labelPart.Parent = root.Parent
	addBillboard(labelPart, "GateNumber", string.format("GATE // %02d", index), index == 1 and "START // FINISH" or "CHECKPOINT", accent)
	local target = addBillboard(labelPart, "TargetTag", "▼ NEXT GATE ▼", "FOLLOW THE BLOCK ARROWS", C.White)
	target.Name = "TargetTag"
	target.Size = UDim2.fromOffset(220, 48)
	target.StudsOffsetWorldSpace = Vector3.new(0, 7, 0)
	target.Enabled = false
end

local function buildGateGuidance(model, cframe, index, width, height)
	local accent = index == 1 and C.Gold or (index % 3 == 0 and C.Red or C.Blue)
	for _, side in ipairs({ -1, 1 }) do
		local previousTop
		local previousBottom
		for order = 1, 4 do
			local z = 6 + order * 9
			local spread = width / 2 + 2 + order * 2.4
			local x = side * spread
			makePart(model, "GuidePost", Vector3.new(1.5, height + 7, 1.5), cframe * CFrame.new(x, 0, z), C.Wood, Enum.Material.WoodPlanks)
			makePart(model, "GuideCap", Vector3.new(2.1, 1.1, 2.1), cframe * CFrame.new(x, height / 2 + 4, z), accent, Enum.Material.Brick)
			local top = cframe:PointToWorldSpace(Vector3.new(x, height / 2 + 2.5, z))
			local bottom = cframe:PointToWorldSpace(Vector3.new(x, -height / 2 - 2.5, z))
			if previousTop then
				beamBetween(model, "GuideTopRail", previousTop, top, 0.75, C.Wood, Enum.Material.WoodPlanks)
				beamBetween(model, "GuideBottomRail", previousBottom, bottom, 0.65, C.Wood, Enum.Material.WoodPlanks)
			end
			previousTop = top
			previousBottom = bottom
		end
	end
	for _, z in ipairs({ 17, 31, 45 }) do
		buildVoxelArrow(model, "GateApproachArrow", cframe * CFrame.new(0, -height / 2 + 3, z), 1.15, accent)
	end
end

local function buildGate(parent, index, definition)
	local cframe = Track.GetGateCFrame(index)
	local model = Instance.new("Model")
	model.Name = string.format("Gate_%02d", index)
	model:SetAttribute("Index", index)
	model:SetAttribute("Width", definition.Width)
	model:SetAttribute("Height", definition.Height)
	model.Parent = parent
	local root = makePart(model, "Root", Vector3.new(definition.Width, definition.Height, 2), cframe, C.StoneDark)
	root.Transparency = 1
	model.PrimaryPart = root

	local accent = index == 1 and C.Gold or (index % 3 == 0 and C.Red or C.Blue)
	local height = definition.Height
	local width = definition.Width
	local field = makePart(model, "EnergyField", Vector3.new(width - 2, height - 2, 0.12), cframe, C.Blue, Enum.Material.Glass)
	field.Transparency = 0.97

	for _, side in ipairs({ -1, 1 }) do
		makePart(model, "StonePillar", Vector3.new(3.4, height + 4, 4.2), cframe * CFrame.new(side * width / 2, 0, 0), C.Stone, Enum.Material.Cobblestone)
		makePart(model, "PillarFoot", Vector3.new(5, 3, 5.4), cframe * CFrame.new(side * width / 2, -height / 2 - 1, 0), C.StoneDark, Enum.Material.Cobblestone)
		makePart(model, "WoodSupport", Vector3.new(1.6, height + 8, 1.6), cframe * CFrame.new(side * (width / 2 + 3.2), 0, 1), C.Wood, Enum.Material.WoodPlanks)
		makePart(model, "SupportFlag", Vector3.new(2.8, 3.2, 0.5), cframe * CFrame.new(side * (width / 2 + 3.2), height / 2 + 2, 2), accent, Enum.Material.Fabric)
		for block = 1, math.max(3, math.floor(height / 4)) do
			local y = -height / 2 + (block - 0.5) * height / math.max(3, math.floor(height / 4))
			makePart(model, "Masonry", Vector3.new(3.8, 0.45, 4.5), cframe * CFrame.new(side * width / 2, y, 0), C.StoneDark, Enum.Material.Cobblestone)
		end
	end
	-- Ступенчатая полукруглая арка, как на ключевой иллюстрации, без гладких цилиндров.
	for block = 0, 12 do
		local angle = block * math.pi / 12
		local x = math.cos(angle) * width / 2
		local y = height / 2 + math.sin(angle) * 7.5
		makePart(model, "StoneArch", Vector3.new(4.4, 3.8, 4.6), cframe * CFrame.new(x, y, 0), block % 3 == 0 and C.StoneDark or C.Stone, Enum.Material.Cobblestone)
	end
	for _, side in ipairs({ -1, 1 }) do
		makePart(model, "ArchWoodBand", Vector3.new(5.2, 2.2, 5), cframe * CFrame.new(side * width / 2, -height / 2 + 4, 0), C.Wood, Enum.Material.WoodPlanks)
	end

	makePart(model, "NumberFrame", Vector3.new(8.2, 7.2, 1), cframe * CFrame.new(0, height / 2 + 5.3, 2.8), C.WoodDark, Enum.Material.WoodPlanks)
	local plate = makePart(model, "NumberPlate", Vector3.new(7.2, 6.2, 0.55), cframe * CFrame.new(0, height / 2 + 5.3, 3.5), C.Gold, Enum.Material.Metal)
	local surface = Instance.new("SurfaceGui")
	surface.Name = "PhysicalGateNumber"
	surface.Face = Enum.NormalId.Back
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 18
	surface.Parent = plate
	local number = Instance.new("TextLabel")
	number.Size = UDim2.fromScale(1, 1)
	number.BackgroundTransparency = 1
	number.Font = Enum.Font.Code
	number.Text = tostring(index)
	number.TextColor3 = C.StoneDark
	number.TextScaled = true
	number.Parent = surface

	addGateLabel(root, index, height)
	buildGateGuidance(model, cframe, index, width, height)
	return { Model = model, CFrame = cframe, Width = width, Height = height }
end

local function buildBoundarySegment(parent, startPosition, endPosition, accent)
	local direction = endPosition - startPosition
	local length = direction.Magnitude
	if length <= 28 then
		return
	end
	local unit = direction / length
	local segmentStart = startPosition + unit * 12
	local segmentEnd = endPosition - unit * 12
	local usable = length - 24
	local segmentCFrame = CFrame.lookAt(startPosition:Lerp(endPosition, 0.5), endPosition)
	local corridor = Config.Boundary.TrackRadius
	for _, side in ipairs({ -1, 1 }) do
		for _, height in ipairs({ -4, -1 }) do
			makePart(parent, "TrackFenceRail", Vector3.new(0.8, 0.8, usable), segmentCFrame * CFrame.new(side * corridor, height, 0), C.Wood, Enum.Material.WoodPlanks)
		end
		local postCount = math.max(1, math.floor(usable / 22))
		for postIndex = 0, postCount do
			local position = segmentStart:Lerp(segmentEnd, postIndex / postCount)
			local postCFrame = CFrame.lookAt(position, endPosition)
			makePart(parent, "TrackFencePost", Vector3.new(1.8, 11, 1.8), postCFrame * CFrame.new(side * corridor, -3, 0), C.Stone, Enum.Material.Cobblestone)
			makePart(parent, "TrackFenceCap", Vector3.new(2.5, 1.4, 2.5), postCFrame * CFrame.new(side * corridor, 3, 0), accent, Enum.Material.Brick)
		end
	end
	for _, vertical in ipairs({ -1, 1 }) do
		local marker = makePart(parent, "TrackLimitBlocks", Vector3.new(1, 1, usable), segmentCFrame * CFrame.new(0, vertical * corridor, 0), C.White, Enum.Material.Fabric)
		marker.Transparency = 0.25
	end
end

local function buildTrackBoundaries(parent, gates)
	for index, gate in ipairs(gates) do
		local nextGate = gates[index % #gates + 1]
		local accent = index == 1 and C.Gold or (index % 3 == 0 and C.Red or C.Blue)
		buildBoundarySegment(parent, gate.CFrame.Position, nextGate.CFrame.Position, accent)
	end
	buildBoundarySegment(parent, Track.StartApproach, gates[1].CFrame.Position, C.Blue)
end

local function buildStartGantry(parent, gates)
	local cframe = gates[1].CFrame * CFrame.new(0, 0, 24)
	for _, side in ipairs({ -1, 1 }) do
		makePart(parent, "StartPillar", Vector3.new(4, 34, 4), cframe * CFrame.new(side * 25, 0, 0), C.Stone, Enum.Material.Cobblestone)
		makePart(parent, "StartBanner", Vector3.new(3, 12, 0.6), cframe * CFrame.new(side * 24, 3, -2.2), side == 1 and C.Blue or C.Red, Enum.Material.Fabric)
	end
	makePart(parent, "StartBeam", Vector3.new(56, 3, 4), cframe * CFrame.new(0, 17, 0), C.Wood, Enum.Material.WoodPlanks)
	local sign = makePart(parent, "StartSign", Vector3.new(44, 8, 1), cframe * CFrame.new(0, 23, 0), C.WoodDark, Enum.Material.WoodPlanks)
	local surface = Instance.new("SurfaceGui")
	surface.Name = "StartDisplay"
	surface.Face = Enum.NormalId.Back
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 9
	surface.Parent = sign
	local title = Instance.new("TextLabel")
	title.Size = UDim2.new(1, 0, 0.58, 0)
	title.BackgroundTransparency = 1
	title.Font = Enum.Font.Code
	title.Text = "AERORUSH // BLOCKHAVEN"
	title.TextColor3 = C.White
	title.TextScaled = true
	title.Parent = surface
	local subtitle = Instance.new("TextLabel")
	subtitle.Position = UDim2.fromScale(0, 0.64)
	subtitle.Size = UDim2.new(1, 0, 0.25, 0)
	subtitle.BackgroundTransparency = 1
	subtitle.Font = Enum.Font.Code
	subtitle.Text = "START  ·  3 LAPS  ·  12 GATES"
	subtitle.TextColor3 = C.Gold
	subtitle.TextScaled = true
	subtitle.Parent = surface
end

local function buildTree(parent, position, scale, pine)
	scale = scale or 1
	makePart(parent, "TreeTrunk", Vector3.new(2.4, 8, 2.4) * scale, CFrame.new(position + Vector3.new(0, 4 * scale, 0)), C.WoodDark, Enum.Material.Wood)
	if pine then
		makePart(parent, "PineLower", Vector3.new(8, 4, 8) * scale, CFrame.new(position + Vector3.new(0, 8 * scale, 0)), C.Leaves, Enum.Material.Grass)
		makePart(parent, "PineMiddle", Vector3.new(6, 4, 6) * scale, CFrame.new(position + Vector3.new(0, 11 * scale, 0)), C.LeavesLight, Enum.Material.Grass)
		makePart(parent, "PineTop", Vector3.new(3.5, 4, 3.5) * scale, CFrame.new(position + Vector3.new(0, 14 * scale, 0)), C.Leaves, Enum.Material.Grass)
	else
		makePart(parent, "TreeLeaves", Vector3.new(8, 5, 8) * scale, CFrame.new(position + Vector3.new(0, 9 * scale, 0)), C.Leaves, Enum.Material.Grass)
		makePart(parent, "TreeLeavesTop", Vector3.new(5, 4, 5) * scale, CFrame.new(position + Vector3.new(0, 12 * scale, 0)), C.LeavesLight, Enum.Material.Grass)
	end
end

local function buildFloatingIsland(parent, name, position, size, variant, detailed)
	local top = makePart(parent, name .. "Grass", Vector3.new(size, 2, size), CFrame.new(position), variant % 3 == 0 and C.GrassLight or C.Grass, Enum.Material.Grass)
	makePart(parent, name .. "Dirt", Vector3.new(size * 0.92, 7, size * 0.92), CFrame.new(position - Vector3.new(0, 4.5, 0)), C.Dirt, Enum.Material.Ground)
	makePart(parent, name .. "Stone", Vector3.new(size * 0.76, 15, size * 0.76), CFrame.new(position - Vector3.new(0, 15, 0)), C.Stone, Enum.Material.Rock)
	makePart(parent, name .. "LowerStone", Vector3.new(size * 0.52, 11, size * 0.52), CFrame.new(position - Vector3.new(0, 27, 0)), C.StoneDark, Enum.Material.Rock)
	local ledgeCount = detailed and 4 or 2
	for index = 1, ledgeCount do
		local angle = (index - 1) * math.pi * 2 / ledgeCount + variant * 0.37
		local ledgeSize = size * (0.24 + ((variant + index) % 3) * 0.035)
		local offset = Vector3.new(math.cos(angle) * size * 0.43, -((variant + index) % 2), math.sin(angle) * size * 0.43)
		local ledgePosition = position + offset
		makePart(parent, name .. "LedgeGrass", Vector3.new(ledgeSize, 2, ledgeSize), CFrame.new(ledgePosition), C.Grass, Enum.Material.Grass)
		makePart(parent, name .. "LedgeDirt", Vector3.new(ledgeSize * 0.84, 7, ledgeSize * 0.84), CFrame.new(ledgePosition - Vector3.new(0, 4.5, 0)), C.Dirt, Enum.Material.Ground)
		makePart(parent, name .. "LedgeStone", Vector3.new(ledgeSize * 0.64, 11, ledgeSize * 0.64), CFrame.new(ledgePosition - Vector3.new(0, 13, 0)), C.Stone, Enum.Material.Rock)
	end
	if detailed then
		-- Вертикальные колонны разбивают прямоугольные слои в блочный утёс с обложки.
		for axis = 1, 2 do
			for _, side in ipairs({ -1, 1 }) do
				for rib = 0, 2 do
					local along = (rib - 1) * size * 0.25
					local edge = side * size * 0.39
					local offset
					if axis == 1 then
						offset = Vector3.new(edge, 0, along)
					else
						offset = Vector3.new(along, 0, edge)
					end
					local ribHeight = 13 + ((variant + rib + axis) % 3) * 4
					local color = (variant + rib + axis) % 4 == 0 and C.Dirt or C.Stone
					makePart(parent, name .. "CliffRib", Vector3.new(3.4, ribHeight, 3.4), CFrame.new(position + offset - Vector3.new(0, 2 + ribHeight / 2, 0)), color, color == C.Dirt and Enum.Material.Ground or Enum.Material.Rock)
				end
			end
		end
	end
	return top.Position.Y + 1
end

local function buildTrackDecor(parent, gates)
	for index, gate in ipairs(gates) do
		local nextGate = gates[index % #gates + 1]
		local direction = nextGate.CFrame.Position - gate.CFrame.Position
		local arrows = math.max(1, math.floor(direction.Magnitude / 27))
		local accent = index == 1 and C.Gold or (index % 3 == 0 and C.Red or C.Blue)
		for arrowIndex = 1, arrows do
			local position = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, arrowIndex / (arrows + 1)) - Vector3.new(0, 9, 0)
			local cframe = CFrame.lookAt(position, position + direction)
			buildVoxelArrow(parent, "TrackDirectionArrow", cframe, 1.25, arrowIndex % 3 == 0 and C.White or accent)
		end

		local islandY = gate.CFrame.Position.Y - gate.Height / 2 - 2
		local islandPosition = Vector3.new(gate.CFrame.Position.X, islandY, gate.CFrame.Position.Z)
		local islandSize = math.max(44, gate.Width + 14)
		local topY = buildFloatingIsland(parent, "GateIsland", islandPosition, islandSize, index, true)
		local horizontalDirection = Vector3.new(direction.X, 0, direction.Z)
		local pathCFrame = CFrame.lookAt(Vector3.new(gate.CFrame.Position.X, topY + 0.15, gate.CFrame.Position.Z), Vector3.new(gate.CFrame.Position.X, topY + 0.15, gate.CFrame.Position.Z) + horizontalDirection)
		makePart(parent, "GateIslandPath", Vector3.new(8, 0.3, islandSize + 2), pathCFrame, C.Sand, Enum.Material.Ground)
		if index % 2 == 0 then
			local treeOffset = pathCFrame.RightVector * (gate.Width / 2 + 5)
			buildTree(parent, Vector3.new(pathCFrame.Position.X, topY, pathCFrame.Position.Z) + treeOffset, 0.75, index % 4 == 0)
		end
	end
end

local function buildObstacles(parent, gates)
	for _, index in ipairs({ 2, 4, 6, 8, 10, 12 }) do
		local gate = gates[index]
		local nextGate = gates[index % #gates + 1]
		local middle = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, 0.5)
		local cframe = CFrame.lookAt(middle, nextGate.CFrame.Position)
		local side = index % 4 == 0 and -1 or 1
		local pylon = makePart(parent, "Pylon", Vector3.new(5, 28, 5), cframe * CFrame.new(side * 13, -3, 0), C.Stone, Enum.Material.Cobblestone)
		pylon.CanCollide = true
		pylon.CanQuery = true
		local stripe = makePart(parent, "PylonStripe", Vector3.new(5.3, 3, 5.3), pylon.CFrame, C.Red, Enum.Material.Brick)
		stripe.CanQuery = true
	end
	for order, index in ipairs({ 3, 5, 7, 9 }) do
		local gate = gates[index]
		local nextGate = gates[index % #gates + 1]
		local center = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, 0.48) - Vector3.new(0, 2, 0)
		local beam = makePart(parent, "Sweeper", Vector3.new(30, 2.4, 2.4), CFrame.new(center), order % 2 == 0 and C.Red or C.Wood, order % 2 == 0 and Enum.Material.Brick or Enum.Material.WoodPlanks)
		beam.CanCollide = true
		beam.CanQuery = true
		table.insert(sweepers, { Part = beam, Center = center, Angle = order * 0.8, Speed = (order % 2 == 0 and -1 or 1) * (0.45 + order * 0.07) })
	end
end

local function buildCrate(parent, cframe, scale)
	scale = scale or 1
	makePart(parent, "SupplyCrate", Vector3.new(2.8, 2.8, 2.8) * scale, cframe, C.Wood, Enum.Material.WoodPlanks)
	makePart(parent, "CrateBandX", Vector3.new(3, 0.45, 3) * scale, cframe * CFrame.new(0, 0.65 * scale, 0), C.WoodDark, Enum.Material.WoodPlanks)
	makePart(parent, "CrateBandZ", Vector3.new(0.45, 3, 3) * scale, cframe, C.WoodDark, Enum.Material.WoodPlanks)
end

local function buildStall(parent, name, position, accent)
	local spawn = Track.LobbySpawn.Position
	local cframe = CFrame.lookAt(position, Vector3.new(spawn.X, position.Y, spawn.Z))
	local floor = makePart(parent, name .. "Floor", Vector3.new(20, 0.6, 16), cframe, C.Stone, Enum.Material.Cobblestone)
	floor.CanCollide = true
	local back = makePart(parent, name .. "Back", Vector3.new(20, 8, 1), cframe * CFrame.new(0, 4.2, 7.5), C.Wood, Enum.Material.WoodPlanks)
	back.CanCollide = true
	for _, side in ipairs({ -1, 1 }) do
		makePart(parent, name .. "Post", Vector3.new(1.2, 8, 1.2), cframe * CFrame.new(side * 9, 4.2, -6.5), C.WoodDark, Enum.Material.Wood)
	end
	makePart(parent, name .. "RoofBase", Vector3.new(22, 0.5, 18), cframe * CFrame.new(0, 8.35, 0), C.WoodDark, Enum.Material.WoodPlanks)
	for stripe = 0, 7 do
		makePart(parent, name .. "RoofStripe", Vector3.new(2.75, 0.65, 18), cframe * CFrame.new(-9.625 + stripe * 2.75, 8.85, 0), stripe % 2 == 0 and accent or C.White, Enum.Material.Fabric)
	end
	local counter = makePart(parent, name .. "Counter", Vector3.new(13, 2.6, 2), cframe * CFrame.new(0, 1.6, -3), C.WoodDark, Enum.Material.WoodPlanks)
	counter.CanCollide = true
	local sign = makePart(parent, name .. "Sign", Vector3.new(15, 3, 0.6), cframe * CFrame.new(0, 7, -7.8), C.StoneDark, Enum.Material.Cobblestone)
	local surface = Instance.new("SurfaceGui")
	surface.Face = Enum.NormalId.Front
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 12
	surface.Parent = sign
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.Code
	text.Text = string.upper(name)
	text.TextColor3 = C.White
	text.TextScaled = true
	text.Parent = surface
	buildCrate(parent, cframe * CFrame.new(-7.5, 1.7, 4.5), 0.85)
	buildCrate(parent, cframe * CFrame.new(7.5, 1.4, 4.5), 0.65)
	for item = -1, 1 do
		makePart(parent, name .. "CounterGoods", Vector3.new(1.4, 1.2, 1.4), cframe * CFrame.new(item * 3.2, 3.5, -3), item == 0 and accent or C.Gold, item == 0 and Enum.Material.Fabric or Enum.Material.Metal)
	end
end

local function buildBench(parent, position, rotation)
	local cframe = CFrame.new(position) * CFrame.Angles(0, rotation or 0, 0)
	makePart(parent, "BenchSeat", Vector3.new(8, 0.8, 2.4), cframe * CFrame.new(0, 1.5, 0), C.Wood, Enum.Material.WoodPlanks)
	makePart(parent, "BenchBack", Vector3.new(8, 2.4, 0.7), cframe * CFrame.new(0, 2.7, 1), C.Wood, Enum.Material.WoodPlanks)
	for _, side in ipairs({ -1, 1 }) do
		makePart(parent, "BenchLeg", Vector3.new(0.8, 1.5, 1.8), cframe * CFrame.new(side * 3, 0.75, 0), C.WoodDark, Enum.Material.Wood)
	end
end

local function buildGroundMarker(parent, text, position, target, accent)
	local cframe = CFrame.lookAt(position, Vector3.new(target.X, position.Y, target.Z))
	buildVoxelArrow(parent, "Lobby" .. text .. "Arrow", cframe, 0.8, accent)
	local anchor = makePart(parent, "WayfindingAnchor", Vector3.one, CFrame.new(position + Vector3.new(0, 2.5, 0)), accent)
	anchor.Transparency = 1
	local billboard = addBillboard(anchor, "Wayfinding", text, "", accent, 75)
	billboard.Size = UDim2.fromOffset(145, 34)
	billboard.AlwaysOnTop = false
end

local function buildLobby(parent)
	local base = makePart(parent, "LobbyPlatform", Vector3.new(170, 8, 170), CFrame.new(0, 80, 338), C.Stone, Enum.Material.Cobblestone)
	base.CanCollide = true
	base.CanQuery = true
	makePart(parent, "LobbyDirtCliff", Vector3.new(164, 8, 164), CFrame.new(0, 72, 338), C.Dirt, Enum.Material.Ground)
	makePart(parent, "LobbyStoneCliff", Vector3.new(148, 16, 148), CFrame.new(0, 60, 338), C.Stone, Enum.Material.Rock)
	makePart(parent, "LobbyLowerCliff", Vector3.new(120, 12, 120), CFrame.new(0, 48, 338), C.StoneDark, Enum.Material.Rock)
	makePart(parent, "LobbyRockBottom", Vector3.new(82, 10, 82), CFrame.new(0, 38, 338), C.Stone, Enum.Material.Rock)
	local grass = makePart(parent, "LobbyGrass", Vector3.new(170, 0.4, 170), CFrame.new(0, 84, 338), C.Grass, Enum.Material.Grass)
	grass.CanCollide = true
	grass.CanQuery = true
	local plaza = makePart(parent, "SpawnPlaza", Vector3.new(42, 0.35, 42), CFrame.new(0, 84.3, 366), C.Stone, Enum.Material.Cobblestone)
	plaza.CanCollide = true
	makePart(parent, "MainPath", Vector3.new(12, 0.3, 150), CFrame.new(0, 84.3, 338), C.Sand, Enum.Material.Ground)
	makePart(parent, "CrossPath", Vector3.new(150, 0.3, 10), CFrame.new(0, 84.32, 366), C.Sand, Enum.Material.Ground)
	for _, x in ipairs({ -58, 58 }) do
		makePart(parent, "StallPath", Vector3.new(10, 0.3, 94), CFrame.new(x, 84.32, 335), C.Sand, Enum.Material.Ground)
	end

	local spawn = Instance.new("SpawnLocation")
	spawn.Name = "LobbySpawn"
	spawn.Size = Vector3.new(10, 1, 10)
	spawn.CFrame = Track.LobbySpawn
	spawn.Anchored = true
	spawn.Neutral = true
	spawn.Enabled = true
	spawn.Duration = 0
	spawn.Color = C.Stone
	spawn.Material = Enum.Material.Cobblestone
	spawn.Parent = parent

	buildStall(parent, "BONUS", Vector3.new(-58, 84.3, 382), C.Blue)
	buildStall(parent, "LOOTBOXES", Vector3.new(58, 84.3, 382), C.Gold)
	buildStall(parent, "GARAGE", Vector3.new(-58, 84.3, 288), C.Red)
	buildStall(parent, "SUPPLY", Vector3.new(58, 84.3, 288), C.Blue)
	buildStall(parent, "TUNING", Vector3.new(0, 84.3, 404), C.GrassLight)
	for _, entry in ipairs({
		{ Vector3.new(-73, 84.2, 272), 1.1, true }, { Vector3.new(73, 84.2, 272), 1, false },
		{ Vector3.new(-74, 84.2, 328), 0.9, false }, { Vector3.new(74, 84.2, 328), 1.1, true },
		{ Vector3.new(-73, 84.2, 408), 1, false }, { Vector3.new(73, 84.2, 408), 0.9, true },
	}) do
		buildTree(parent, entry[1], entry[2], entry[3])
	end
	buildBench(parent, Vector3.new(-20, 84.2, 390), 0)
	buildBench(parent, Vector3.new(20, 84.2, 390), 0)
	buildBench(parent, Vector3.new(-68, 84.2, 350), math.rad(90))
	buildBench(parent, Vector3.new(68, 84.2, 350), math.rad(-90))

	for _, side in ipairs({ -1, 1 }) do
		for _, y in ipairs({ 85.4, 87.1 }) do
			local railX = makePart(parent, "LobbyFenceX", Vector3.new(0.75, 0.65, 164), CFrame.new(side * 83, y, 338), C.Wood, Enum.Material.WoodPlanks)
			railX.CanCollide = true
			local railZ = makePart(parent, "LobbyFenceZ", Vector3.new(164, 0.65, 0.75), CFrame.new(0, y, 338 + side * 83), C.Wood, Enum.Material.WoodPlanks)
			railZ.CanCollide = true
		end
		for offset = -80, 80, 16 do
			makePart(parent, "LobbyFencePost", Vector3.new(1.8, 5.5, 1.8), CFrame.new(side * 83, 86.5, 338 + offset), C.WoodDark, Enum.Material.Wood)
			makePart(parent, "LobbyFencePost", Vector3.new(1.8, 5.5, 1.8), CFrame.new(offset, 86.5, 338 + side * 83), C.WoodDark, Enum.Material.Wood)
		end
	end

	for _, side in ipairs({ -1, 1 }) do
		makePart(parent, "RaceArchPillar", Vector3.new(3, 15, 3), CFrame.new(side * 11, 91.7, 366), C.Stone, Enum.Material.Cobblestone)
	end
	makePart(parent, "RaceArchBeam", Vector3.new(25, 3, 3), CFrame.new(0, 99, 366), C.Wood, Enum.Material.WoodPlanks)
	local sign = makePart(parent, "LobbySign", Vector3.new(48, 11, 1), CFrame.new(0, 101, 420), C.WoodDark, Enum.Material.WoodPlanks)
	local surface = Instance.new("SurfaceGui")
	surface.Face = Enum.NormalId.Front
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 12
	surface.Parent = sign
	local title = Instance.new("TextLabel")
	title.Size = UDim2.fromScale(1, 0.62)
	title.BackgroundTransparency = 1
	title.Font = Enum.Font.Code
	title.Text = Config.GameName
	title.TextColor3 = C.White
	title.TextScaled = true
	title.Parent = surface
	local subtitle = Instance.new("TextLabel")
	subtitle.Position = UDim2.fromScale(0, 0.62)
	subtitle.Size = UDim2.fromScale(1, 0.25)
	subtitle.BackgroundTransparency = 1
	subtitle.Font = Enum.Font.Code
	subtitle.Text = "BLOCKHAVEN  ·  FREE LOBBY"
	subtitle.TextColor3 = C.Gold
	subtitle.TextScaled = true
	subtitle.Parent = surface

	buildGroundMarker(parent, "СТАРТ", Vector3.new(-5, 84.65, 366), Vector3.new(-15, 84.65, 366), C.Gold)
	buildGroundMarker(parent, "ГЕЙТЫ", Vector3.new(0, 84.65, 326), Vector3.new(0, 84.65, 290), C.Gold)
	buildGroundMarker(parent, "ТЮНИНГ", Vector3.new(0, 84.65, 389), Vector3.new(0, 84.65, 404), C.GrassLight)
	buildGroundMarker(parent, "ГАРАЖ", Vector3.new(-32, 84.65, 328), Vector3.new(-58, 84.65, 288), C.Red)
	buildGroundMarker(parent, "КЕЙСЫ", Vector3.new(32, 84.65, 374), Vector3.new(58, 84.65, 382), C.Gold)
	buildGroundMarker(parent, "БОНУСЫ", Vector3.new(-32, 84.65, 374), Vector3.new(-58, 84.65, 382), C.Blue)
end

local function buildCloud(parent, position, scale)
	scale = scale or 1
	for _, entry in ipairs({
		{ Vector3.new(0, 0, 0), Vector3.new(34, 8, 24) },
		{ Vector3.new(-18, -2, 2), Vector3.new(18, 6, 20) },
		{ Vector3.new(18, 2, -2), Vector3.new(22, 10, 22) },
		{ Vector3.new(4, 6, 1), Vector3.new(18, 7, 18) },
	}) do
		local cloud = makePart(parent, "BlockCloud", entry[2] * scale, CFrame.new(position + entry[1] * scale), C.White, Enum.Material.SmoothPlastic)
		cloud.Transparency = 0.06
	end
end

local function buildMountain(parent, position, size, variant)
	buildFloatingIsland(parent, "MountainIsland", position, size, variant, true)
	for level = 0, 7 do
		local width = size * (0.78 - level * 0.095)
		local height = 12 + level * 2
		makePart(parent, "MountainRock", Vector3.new(width, height, width), CFrame.new(position + Vector3.new(0, 7 + level * 10, 0)), level >= 4 and C.White or C.Stone, level >= 4 and Enum.Material.Snow or Enum.Material.Rock)
	end
end

local function buildEnvironment(parent)
	local random = Random.new(42024)
	for index = 1, 36 do
		local angle = random:NextNumber(0, math.pi * 2)
		local radius = random:NextNumber(340, 590)
		local width = random:NextNumber(30, 62)
		local position = Vector3.new(math.cos(angle) * radius, random:NextNumber(-35, 70), math.sin(angle) * radius - 20)
		local topY = buildFloatingIsland(parent, "Island", position, width, index, false)
		if index % 2 == 0 then
			buildTree(parent, Vector3.new(position.X, topY, position.Z), random:NextNumber(0.8, 1.35), index % 4 == 0)
		end
	end
	buildMountain(parent, Vector3.new(90, 5, -475), 94, 41)
	buildMountain(parent, Vector3.new(-360, -5, -360), 76, 42)
	buildMountain(parent, Vector3.new(410, -15, 160), 70, 43)
	for _ = 1, 20 do
		buildCloud(parent, Vector3.new(random:NextNumber(-620, 620), random:NextNumber(165, 245), random:NextNumber(-620, 500)), random:NextNumber(0.75, 1.5))
	end
end

local function setupLighting()
	Lighting.ClockTime = 14.5
	Lighting.Brightness = 2.4
	Lighting.Ambient = Color3.fromRGB(112, 124, 108)
	Lighting.OutdoorAmbient = Color3.fromRGB(150, 165, 160)
	Lighting.EnvironmentDiffuseScale = 0.5
	Lighting.EnvironmentSpecularScale = 0.2
	Lighting.ExposureCompensation = 0.12
	for _, name in ipairs({ "AeroAtmosphere", "AeroBloom", "AeroColor", "AeroSun" }) do
		local existing = Lighting:FindFirstChild(name)
		if existing then
			existing:Destroy()
		end
	end
	local atmosphere = Instance.new("Atmosphere")
	atmosphere.Name = "AeroAtmosphere"
	atmosphere.Density = 0.12
	atmosphere.Offset = 0.1
	atmosphere.Color = Color3.fromRGB(175, 215, 232)
	atmosphere.Decay = Color3.fromRGB(110, 145, 125)
	atmosphere.Glare = 0
	atmosphere.Haze = 0.35
	atmosphere.Parent = Lighting
	local color = Instance.new("ColorCorrectionEffect")
	color.Name = "AeroColor"
	color.Contrast = 0.04
	color.Saturation = 0.08
	color.TintColor = Color3.fromRGB(248, 250, 235)
	color.Parent = Lighting
end

function WorldBuilder.Build()
	table.clear(sweepers)
	local previous = Workspace:FindFirstChild("AeroRushWorld")
	if previous then
		previous:Destroy()
	end
	local world = Instance.new("Folder")
	world.Name = "AeroRushWorld"
	world.Parent = Workspace
	local decorations = Instance.new("Folder")
	decorations.Name = "Decorations"
	decorations.Parent = world
	local gatesFolder = Instance.new("Folder")
	gatesFolder.Name = "Gates"
	gatesFolder.Parent = world
	local obstacles = Instance.new("Folder")
	obstacles.Name = "Obstacles"
	obstacles.Parent = world
	local lobby = Instance.new("Folder")
	lobby.Name = "Lobby"
	lobby.Parent = world
	local drones = Instance.new("Folder")
	drones.Name = "Drones"
	drones.Parent = world
	local gates = {}
	for index, definition in ipairs(Track.Gates) do
		gates[index] = buildGate(gatesFolder, index, definition)
	end
	buildTrackBoundaries(decorations, gates)
	buildStartGantry(decorations, gates)
	buildTrackDecor(decorations, gates)
	buildObstacles(obstacles, gates)
	buildLobby(lobby)
	buildEnvironment(decorations)
	setupLighting()
	return { Root = world, Gates = gates, Obstacles = obstacles, Drones = drones, Lobby = lobby }
end

function WorldBuilder.Step(deltaTime)
	for _, sweeper in ipairs(sweepers) do
		sweeper.Angle = sweeper.Angle + sweeper.Speed * deltaTime
		sweeper.Part.CFrame = CFrame.new(sweeper.Center) * CFrame.Angles(0, sweeper.Angle, 0)
	end
end

return WorldBuilder
