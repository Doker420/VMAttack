-- Процедурный voxel-мир: блоки, острова и просторное лобби без неонового города.
local Lighting = game:GetService("Lighting")
local Workspace = game:GetService("Workspace")

local Shared = game:GetService("ReplicatedStorage"):WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Track = require(Shared:WaitForChild("Track"))

local WorldBuilder = {}

local C = {
	Grass = Color3.fromRGB(91, 141, 65),
	GrassLight = Color3.fromRGB(124, 166, 78),
	Dirt = Color3.fromRGB(117, 82, 52),
	Stone = Color3.fromRGB(112, 118, 115),
	StoneDark = Color3.fromRGB(67, 74, 72),
	Wood = Color3.fromRGB(139, 101, 61),
	WoodDark = Color3.fromRGB(83, 57, 35),
	Leaves = Color3.fromRGB(55, 112, 51),
	LeavesLight = Color3.fromRGB(83, 143, 63),
	Sand = Color3.fromRGB(196, 178, 120),
	White = Color3.fromRGB(236, 239, 222),
	Blue = Color3.fromRGB(73, 124, 158),
	Red = Color3.fromRGB(173, 76, 55),
	Gold = Color3.fromRGB(214, 170, 65),
}

local sweepers = {}

local function makePart(parent, name, size, cframe, color, material)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.CFrame = cframe
	part.Color = color or C.Stone
	part.Material = material or Enum.Material.SmoothPlastic
	part.Anchored = true
	part.CanCollide = false
	part.CanTouch = false
	part.CanQuery = false
	part.TopSurface = Enum.SurfaceType.Smooth
	part.BottomSurface = Enum.SurfaceType.Smooth
	part.Parent = parent
	return part
end

local function addBillboard(parent, name, title, subtitle, accent)
	local billboard = Instance.new("BillboardGui")
	billboard.Name = name
	billboard.Size = UDim2.fromOffset(250, 72)
	billboard.AlwaysOnTop = true
	billboard.MaxDistance = 460
	billboard.Parent = parent
	local heading = Instance.new("TextLabel")
	heading.Name = "Title"
	heading.Size = UDim2.new(1, 0, 0.56, 0)
	heading.BackgroundTransparency = 1
	heading.Font = Enum.Font.Code
	heading.Text = title
	heading.TextColor3 = accent
	heading.TextStrokeColor3 = C.StoneDark
	heading.TextStrokeTransparency = 0.25
	heading.TextScaled = true
	heading.Parent = billboard
	local detail = Instance.new("TextLabel")
	detail.Name = "Subtitle"
	detail.Position = UDim2.fromScale(0, 0.62)
	detail.Size = UDim2.new(1, 0, 0.3, 0)
	detail.BackgroundTransparency = 1
	detail.Font = Enum.Font.Code
	detail.Text = subtitle
	detail.TextColor3 = C.White
	detail.TextStrokeColor3 = C.StoneDark
	detail.TextStrokeTransparency = 0.35
	detail.TextScaled = true
	detail.Parent = billboard
	return billboard
end

local function addGateLabel(root, index, height)
	local accent = index == 1 and C.Gold or (index % 3 == 0 and C.Red or C.Blue)
	local labelPart = Instance.new("Part")
	labelPart.Name = "NumberAnchor"
	labelPart.Size = Vector3.one
	labelPart.Transparency = 1
	labelPart.Anchored = true
	labelPart.CanCollide = false
	labelPart.CanTouch = false
	labelPart.CanQuery = false
	labelPart.CFrame = root.CFrame * CFrame.new(0, height / 2 + 5, 0)
	labelPart.Parent = root.Parent
	addBillboard(labelPart, "GateNumber", string.format("GATE // %02d", index), index == 1 and "START // FINISH" or "CHECKPOINT", accent)
	local target = addBillboard(labelPart, "TargetTag", "NEXT TARGET", "", C.White)
	target.Name = "TargetTag"
	target.Size = UDim2.fromOffset(190, 44)
	target.StudsOffsetWorldSpace = Vector3.new(0, 7, 0)
	target.Enabled = false
end

local function buildGate(parent, index, definition)
	local cframe = Track.GetGateCFrame(index)
	local model = Instance.new("Model")
	model.Name = string.format("Gate_%02d", index)
	model:SetAttribute("Index", index)
	model:SetAttribute("Width", definition.Width)
	model:SetAttribute("Height", definition.Height)
	model.Parent = parent
	local root = makePart(model, "Root", Vector3.new(definition.Width, definition.Height, 2), cframe, C.StoneDark)
	root.Transparency = 1
	model.PrimaryPart = root

	local accent = index == 1 and C.Gold or (index % 3 == 0 and C.Red or C.Blue)
	local height = definition.Height
	local width = definition.Width
	local thickness = index == 1 and 2.4 or 1.8
	local field = makePart(model, "EnergyField", Vector3.new(width - 2, height - 2, 0.12), cframe, C.Blue, Enum.Material.Glass)
	field.Transparency = 0.96
	makePart(model, "Left", Vector3.new(thickness, height + 2, 2.4), cframe * CFrame.new(-width / 2, 0, 0), C.Stone, Enum.Material.Cobblestone)
	makePart(model, "Right", Vector3.new(thickness, height + 2, 2.4), cframe * CFrame.new(width / 2, 0, 0), C.Stone, Enum.Material.Cobblestone)
	makePart(model, "Top", Vector3.new(width + 2, thickness, 2.4), cframe * CFrame.new(0, height / 2, 0), C.Wood, Enum.Material.WoodPlanks)
	makePart(model, "Bottom", Vector3.new(width + 2, thickness, 2.4), cframe * CFrame.new(0, -height / 2, 0), C.Wood, Enum.Material.WoodPlanks)
	for _, x in ipairs({ -1, 1 }) do
		for _, y in ipairs({ -1, 1 }) do
			makePart(model, "CornerBlock", Vector3.new(3, 3, 3), cframe * CFrame.new(x * width / 2, y * height / 2, 0), accent, Enum.Material.Brick)
		end
	end
	addGateLabel(root, index, height)
	local approach = makePart(model, "ApproachAnchor", Vector3.one, cframe * CFrame.new(0, -height / 2 - 4, 26), C.Stone)
	approach.Transparency = 1
	local guide = addBillboard(approach, "ApproachLabel", string.format(">> GATE %02d <<", index), "ALIGN + HOLD COURSE", accent)
	guide.Size = UDim2.fromOffset(210, 54)
	return { Model = model, CFrame = cframe, Width = width, Height = height }
end

local function buildBoundarySegment(parent, startPosition, endPosition, accent)
	local direction = endPosition - startPosition
	local length = direction.Magnitude
	if length <= 28 then
		return
	end
	local unit = direction / length
	local segmentStart = startPosition + unit * 12
	local segmentEnd = endPosition - unit * 12
	local usable = length - 24
	local segmentCFrame = CFrame.lookAt(startPosition:Lerp(endPosition, 0.5), endPosition)
	local corridor = Config.Boundary.TrackRadius
	for _, side in ipairs({ -1, 1 }) do
		for _, height in ipairs({ -4, -1 }) do
			makePart(parent, "TrackFenceRail", Vector3.new(0.55, 0.55, usable), segmentCFrame * CFrame.new(side * corridor, height, 0), C.Wood, Enum.Material.WoodPlanks)
		end
		local postCount = math.max(1, math.floor(usable / 26))
		for postIndex = 0, postCount do
			local position = segmentStart:Lerp(segmentEnd, postIndex / postCount)
			local postCFrame = CFrame.lookAt(position, endPosition)
			makePart(parent, "TrackFencePost", Vector3.new(1.8, 9, 1.8), postCFrame * CFrame.new(side * corridor, -3, 0), C.Stone, Enum.Material.Cobblestone)
			makePart(parent, "TrackFenceCap", Vector3.new(2.2, 1, 2.2), postCFrame * CFrame.new(side * corridor, 2, 0), accent, Enum.Material.Brick)
		end
	end
	for _, vertical in ipairs({ -1, 1 }) do
		local marker = makePart(parent, "TrackLimitBlocks", Vector3.new(0.8, 0.8, usable), segmentCFrame * CFrame.new(0, vertical * corridor, 0), C.White, Enum.Material.Fabric)
		marker.Transparency = 0.38
	end
end

local function buildTrackBoundaries(parent, gates)
	for index, gate in ipairs(gates) do
		local nextGate = gates[index % #gates + 1]
		local accent = index == 1 and C.Gold or (index % 3 == 0 and C.Red or C.Blue)
		buildBoundarySegment(parent, gate.CFrame.Position, nextGate.CFrame.Position, accent)
	end
	buildBoundarySegment(parent, Track.StartApproach, gates[1].CFrame.Position, C.Blue)
end

local function buildStartGantry(parent, gates)
	local cframe = gates[1].CFrame * CFrame.new(0, 0, 24)
	for _, side in ipairs({ -1, 1 }) do
		makePart(parent, "StartPillar", Vector3.new(3, 32, 3), cframe * CFrame.new(side * 25, 0, 0), C.Stone, Enum.Material.Cobblestone)
		makePart(parent, "StartBanner", Vector3.new(1, 12, 0.6), cframe * CFrame.new(side * 24, 3, -1.8), side == 1 and C.Blue or C.Red, Enum.Material.Fabric)
	end
	makePart(parent, "StartBeam", Vector3.new(54, 3, 3), cframe * CFrame.new(0, 16, 0), C.Wood, Enum.Material.WoodPlanks)
	local sign = makePart(parent, "StartSign", Vector3.new(44, 8, 1), cframe * CFrame.new(0, 22, 0), C.WoodDark, Enum.Material.WoodPlanks)
	local surface = Instance.new("SurfaceGui")
	surface.Name = "StartDisplay"
	surface.Face = Enum.NormalId.Back
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 9
	surface.Parent = sign
	local title = Instance.new("TextLabel")
	title.Size = UDim2.new(1, 0, 0.58, 0)
	title.BackgroundTransparency = 1
	title.Font = Enum.Font.Code
	title.Text = "AERORUSH // BLOCKHAVEN"
	title.TextColor3 = C.White
	title.TextScaled = true
	title.Parent = surface
	local subtitle = Instance.new("TextLabel")
	subtitle.Position = UDim2.fromScale(0, 0.64)
	subtitle.Size = UDim2.new(1, 0, 0.25, 0)
	subtitle.BackgroundTransparency = 1
	subtitle.Font = Enum.Font.Code
	subtitle.Text = "START  ·  3 LAPS  ·  12 GATES"
	subtitle.TextColor3 = C.Gold
	subtitle.TextScaled = true
	subtitle.Parent = surface
end

local function buildTrackDecor(parent, gates)
	for index, gate in ipairs(gates) do
		local nextGate = gates[index % #gates + 1]
		local direction = nextGate.CFrame.Position - gate.CFrame.Position
		local arrows = math.max(1, math.floor(direction.Magnitude / 36))
		for arrowIndex = 1, arrows do
			local position = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, arrowIndex / (arrows + 1)) - Vector3.new(0, 13, 0)
			local cframe = CFrame.lookAt(position, position + direction)
			makePart(parent, "ChevronLeft", Vector3.new(7, 0.35, 1.4), cframe * CFrame.new(-2.5, 0, 0) * CFrame.Angles(0, math.rad(35), 0), C.Wood, Enum.Material.WoodPlanks)
			makePart(parent, "ChevronRight", Vector3.new(7, 0.35, 1.4), cframe * CFrame.new(2.5, 0, 0) * CFrame.Angles(0, math.rad(-35), 0), C.Wood, Enum.Material.WoodPlanks)
		end
		local islandY = gate.CFrame.Position.Y - gate.Height / 2 - 44
		local islandPosition = Vector3.new(gate.CFrame.Position.X, islandY, gate.CFrame.Position.Z)
		makePart(parent, "VoxelIslandGrass", Vector3.new(42, 3, 42), CFrame.new(islandPosition), C.Grass, Enum.Material.Grass)
		makePart(parent, "VoxelIslandDirt", Vector3.new(36, 8, 36), CFrame.new(islandPosition - Vector3.new(0, 5, 0)), C.Dirt, Enum.Material.Ground)
		makePart(parent, "VoxelIslandStone", Vector3.new(26, 10, 26), CFrame.new(islandPosition - Vector3.new(0, 13, 0)), C.Stone, Enum.Material.Rock)
	end
end

local function buildObstacles(parent, gates)
	for _, index in ipairs({ 2, 4, 6, 8, 10, 12 }) do
		local gate = gates[index]
		local nextGate = gates[index % #gates + 1]
		local middle = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, 0.5)
		local cframe = CFrame.lookAt(middle, nextGate.CFrame.Position)
		local side = index % 4 == 0 and -1 or 1
		local pylon = makePart(parent, "Pylon", Vector3.new(5, 28, 5), cframe * CFrame.new(side * 13, -3, 0), C.Stone, Enum.Material.Cobblestone)
		pylon.CanCollide = true
		pylon.CanQuery = true
		local stripe = makePart(parent, "PylonStripe", Vector3.new(5.3, 3, 5.3), pylon.CFrame, C.Red, Enum.Material.Brick)
		stripe.CanQuery = true
	end
	for order, index in ipairs({ 3, 5, 7, 9 }) do
		local gate = gates[index]
		local nextGate = gates[index % #gates + 1]
		local center = gate.CFrame.Position:Lerp(nextGate.CFrame.Position, 0.48) - Vector3.new(0, 2, 0)
		local beam = makePart(parent, "Sweeper", Vector3.new(30, 2.4, 2.4), CFrame.new(center), order % 2 == 0 and C.Red or C.Wood, order % 2 == 0 and Enum.Material.Brick or Enum.Material.WoodPlanks)
		beam.CanCollide = true
		beam.CanQuery = true
		table.insert(sweepers, { Part = beam, Center = center, Angle = order * 0.8, Speed = (order % 2 == 0 and -1 or 1) * (0.45 + order * 0.07) })
	end
end

local function buildTree(parent, position, scale)
	scale = scale or 1
	makePart(parent, "TreeTrunk", Vector3.new(2.4, 8, 2.4) * scale, CFrame.new(position + Vector3.new(0, 4 * scale, 0)), C.WoodDark, Enum.Material.Wood)
	makePart(parent, "TreeLeaves", Vector3.new(8, 5, 8) * scale, CFrame.new(position + Vector3.new(0, 9 * scale, 0)), C.Leaves, Enum.Material.Grass)
	makePart(parent, "TreeLeavesTop", Vector3.new(5, 4, 5) * scale, CFrame.new(position + Vector3.new(0, 12 * scale, 0)), C.LeavesLight, Enum.Material.Grass)
end

local function buildStall(parent, name, position, accent)
	local spawn = Track.LobbySpawn.Position
	local cframe = CFrame.lookAt(position, Vector3.new(spawn.X, position.Y, spawn.Z))
	local floor = makePart(parent, name .. "Floor", Vector3.new(20, 0.6, 16), cframe, C.Stone, Enum.Material.Cobblestone)
	floor.CanCollide = true
	local back = makePart(parent, name .. "Back", Vector3.new(20, 8, 1), cframe * CFrame.new(0, 4.2, 7.5), C.Wood, Enum.Material.WoodPlanks)
	back.CanCollide = true
	for _, side in ipairs({ -1, 1 }) do
		makePart(parent, name .. "Post", Vector3.new(1.2, 8, 1.2), cframe * CFrame.new(side * 9, 4.2, -6.5), C.WoodDark, Enum.Material.Wood)
	end
	makePart(parent, name .. "Roof", Vector3.new(22, 1.2, 18), cframe * CFrame.new(0, 8.7, 0), accent, Enum.Material.Brick)
	local counter = makePart(parent, name .. "Counter", Vector3.new(13, 2.6, 2), cframe * CFrame.new(0, 1.6, -3), C.WoodDark, Enum.Material.WoodPlanks)
	counter.CanCollide = true
	local sign = makePart(parent, name .. "Sign", Vector3.new(15, 3, 0.6), cframe * CFrame.new(0, 7, -7.8), C.StoneDark, Enum.Material.Cobblestone)
	local surface = Instance.new("SurfaceGui")
	surface.Face = Enum.NormalId.Front
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 12
	surface.Parent = sign
	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Font = Enum.Font.Code
	text.Text = string.upper(name)
	text.TextColor3 = C.White
	text.TextScaled = true
	text.Parent = surface
end

local function buildBench(parent, position, rotation)
	local cframe = CFrame.new(position) * CFrame.Angles(0, rotation or 0, 0)
	makePart(parent, "BenchSeat", Vector3.new(8, 0.8, 2.4), cframe * CFrame.new(0, 1.5, 0), C.Wood, Enum.Material.WoodPlanks)
	makePart(parent, "BenchBack", Vector3.new(8, 2.4, 0.7), cframe * CFrame.new(0, 2.7, 1), C.Wood, Enum.Material.WoodPlanks)
	for _, side in ipairs({ -1, 1 }) do
		makePart(parent, "BenchLeg", Vector3.new(0.8, 1.5, 1.8), cframe * CFrame.new(side * 3, 0.75, 0), C.WoodDark, Enum.Material.Wood)
	end
end

local function buildLobby(parent)
	local base = makePart(parent, "LobbyPlatform", Vector3.new(170, 8, 170), CFrame.new(0, 80, 338), C.Stone, Enum.Material.Cobblestone)
	base.CanCollide = true
	base.CanQuery = true
	local grass = makePart(parent, "LobbyGrass", Vector3.new(170, 0.4, 170), CFrame.new(0, 84, 338), C.Grass, Enum.Material.Grass)
	grass.CanCollide = true
	grass.CanQuery = true
	local plaza = makePart(parent, "SpawnPlaza", Vector3.new(42, 0.35, 42), CFrame.new(0, 84.3, 366), C.Stone, Enum.Material.Cobblestone)
	plaza.CanCollide = true
	makePart(parent, "MainPath", Vector3.new(12, 0.3, 150), CFrame.new(0, 84.3, 338), C.Sand, Enum.Material.Ground)
	makePart(parent, "CrossPath", Vector3.new(150, 0.3, 10), CFrame.new(0, 84.32, 366), C.Sand, Enum.Material.Ground)

	local spawn = Instance.new("SpawnLocation")
	spawn.Name = "LobbySpawn"
	spawn.Size = Vector3.new(10, 1, 10)
	spawn.CFrame = Track.LobbySpawn
	spawn.Anchored = true
	spawn.Neutral = true
	spawn.Enabled = true
	spawn.Duration = 0
	spawn.Color = C.Stone
	spawn.Material = Enum.Material.Cobblestone
	spawn.Parent = parent

	buildStall(parent, "BONUS", Vector3.new(-58, 84.3, 382), C.Blue)
	buildStall(parent, "LOOTBOXES", Vector3.new(58, 84.3, 382), C.Gold)
	buildStall(parent, "GARAGE", Vector3.new(-58, 84.3, 288), C.Red)
	buildStall(parent, "SUPPLY", Vector3.new(58, 84.3, 288), C.Blue)
	buildStall(parent, "TUNING", Vector3.new(0, 84.3, 404), C.GrassLight)
	for _, entry in ipairs({
		{ Vector3.new(-73, 84.2, 272), 1.1 }, { Vector3.new(73, 84.2, 272), 1 },
		{ Vector3.new(-74, 84.2, 328), 0.9 }, { Vector3.new(74, 84.2, 328), 1.1 },
		{ Vector3.new(-73, 84.2, 408), 1 }, { Vector3.new(73, 84.2, 408), 0.9 },
	}) do
		buildTree(parent, entry[1], entry[2])
	end
	buildBench(parent, Vector3.new(-20, 84.2, 390), 0)
	buildBench(parent, Vector3.new(20, 84.2, 390), 0)
	buildBench(parent, Vector3.new(-68, 84.2, 350), math.rad(90))
	buildBench(parent, Vector3.new(68, 84.2, 350), math.rad(-90))

	for _, side in ipairs({ -1, 1 }) do
		local railX = makePart(parent, "LobbyFenceX", Vector3.new(1, 2.4, 164), CFrame.new(side * 83, 86, 338), C.Wood, Enum.Material.WoodPlanks)
		railX.CanCollide = true
		local railZ = makePart(parent, "LobbyFenceZ", Vector3.new(164, 2.4, 1), CFrame.new(0, 86, 338 + side * 83), C.Wood, Enum.Material.WoodPlanks)
		railZ.CanCollide = true
		for offset = -80, 80, 20 do
			makePart(parent, "LobbyFencePost", Vector3.new(1.8, 5, 1.8), CFrame.new(side * 83, 86.5, 338 + offset), C.WoodDark, Enum.Material.Wood)
			makePart(parent, "LobbyFencePost", Vector3.new(1.8, 5, 1.8), CFrame.new(offset, 86.5, 338 + side * 83), C.WoodDark, Enum.Material.Wood)
		end
	end

	for _, side in ipairs({ -1, 1 }) do
		makePart(parent, "RaceArchPillar", Vector3.new(3, 15, 3), CFrame.new(side * 11, 91.7, 366), C.Stone, Enum.Material.Cobblestone)
	end
	makePart(parent, "RaceArchBeam", Vector3.new(25, 3, 3), CFrame.new(0, 99, 366), C.Wood, Enum.Material.WoodPlanks)
	local sign = makePart(parent, "LobbySign", Vector3.new(48, 11, 1), CFrame.new(0, 101, 420), C.WoodDark, Enum.Material.WoodPlanks)
	local surface = Instance.new("SurfaceGui")
	surface.Face = Enum.NormalId.Front
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 12
	surface.Parent = sign
	local title = Instance.new("TextLabel")
	title.Size = UDim2.fromScale(1, 0.62)
	title.BackgroundTransparency = 1
	title.Font = Enum.Font.Code
	title.Text = Config.GameName
	title.TextColor3 = C.White
	title.TextScaled = true
	title.Parent = surface
	local subtitle = Instance.new("TextLabel")
	subtitle.Position = UDim2.fromScale(0, 0.62)
	subtitle.Size = UDim2.fromScale(1, 0.25)
	subtitle.BackgroundTransparency = 1
	subtitle.Font = Enum.Font.Code
	subtitle.Text = "BLOCKHAVEN  ·  FREE LOBBY"
	subtitle.TextColor3 = C.Gold
	subtitle.TextScaled = true
	subtitle.Parent = surface
end

local function buildEnvironment(parent)
	local random = Random.new(42024)
	for index = 1, 44 do
		local angle = random:NextNumber(0, math.pi * 2)
		local radius = random:NextNumber(330, 570)
		local width = random:NextNumber(28, 62)
		local position = Vector3.new(math.cos(angle) * radius, random:NextNumber(-45, 65), math.sin(angle) * radius - 20)
		makePart(parent, "IslandGrass", Vector3.new(width, 4, width), CFrame.new(position), index % 3 == 0 and C.GrassLight or C.Grass, Enum.Material.Grass)
		makePart(parent, "IslandDirt", Vector3.new(width * 0.86, 10, width * 0.86), CFrame.new(position - Vector3.new(0, 7, 0)), C.Dirt, Enum.Material.Ground)
		makePart(parent, "IslandStone", Vector3.new(width * 0.62, 13, width * 0.62), CFrame.new(position - Vector3.new(0, 18, 0)), C.Stone, Enum.Material.Rock)
		if index % 2 == 0 then
			buildTree(parent, position + Vector3.new(0, 2, 0), random:NextNumber(0.8, 1.4))
		end
	end
	for _ = 1, 24 do
		local cloud = makePart(parent, "BlockCloud", Vector3.new(random:NextNumber(30, 80), random:NextNumber(5, 12), random:NextNumber(22, 60)), CFrame.new(random:NextNumber(-600, 600), random:NextNumber(150, 230), random:NextNumber(-600, 500)), C.White, Enum.Material.SmoothPlastic)
		cloud.Transparency = 0.12
	end
end

local function setupLighting()
	Lighting.ClockTime = 14.5
	Lighting.Brightness = 2
	Lighting.Ambient = Color3.fromRGB(95, 105, 95)
	Lighting.OutdoorAmbient = Color3.fromRGB(130, 145, 150)
	Lighting.EnvironmentDiffuseScale = 0.45
	Lighting.EnvironmentSpecularScale = 0.25
	Lighting.ExposureCompensation = 0
	for _, name in ipairs({ "AeroAtmosphere", "AeroBloom", "AeroColor", "AeroSun" }) do
		local existing = Lighting:FindFirstChild(name)
		if existing then
			existing:Destroy()
		end
	end
	local atmosphere = Instance.new("Atmosphere")
	atmosphere.Name = "AeroAtmosphere"
	atmosphere.Density = 0.18
	atmosphere.Offset = 0.1
	atmosphere.Color = Color3.fromRGB(175, 205, 215)
	atmosphere.Decay = Color3.fromRGB(110, 145, 125)
	atmosphere.Glare = 0
	atmosphere.Haze = 0.7
	atmosphere.Parent = Lighting
	local color = Instance.new("ColorCorrectionEffect")
	color.Name = "AeroColor"
	color.Contrast = 0.03
	color.Saturation = 0.04
	color.TintColor = Color3.fromRGB(245, 248, 235)
	color.Parent = Lighting
end

function WorldBuilder.Build()
	table.clear(sweepers)
	local previous = Workspace:FindFirstChild("AeroRushWorld")
	if previous then
		previous:Destroy()
	end
	local world = Instance.new("Folder")
	world.Name = "AeroRushWorld"
	world.Parent = Workspace
	local decorations = Instance.new("Folder")
	decorations.Name = "Decorations"
	decorations.Parent = world
	local gatesFolder = Instance.new("Folder")
	gatesFolder.Name = "Gates"
	gatesFolder.Parent = world
	local obstacles = Instance.new("Folder")
	obstacles.Name = "Obstacles"
	obstacles.Parent = world
	local lobby = Instance.new("Folder")
	lobby.Name = "Lobby"
	lobby.Parent = world
	local drones = Instance.new("Folder")
	drones.Name = "Drones"
	drones.Parent = world
	local gates = {}
	for index, definition in ipairs(Track.Gates) do
		gates[index] = buildGate(gatesFolder, index, definition)
	end
	buildTrackBoundaries(decorations, gates)
	buildStartGantry(decorations, gates)
	buildTrackDecor(decorations, gates)
	buildObstacles(obstacles, gates)
	buildLobby(lobby)
	buildEnvironment(decorations)
	setupLighting()
	return { Root = world, Gates = gates, Obstacles = obstacles, Drones = drones, Lobby = lobby }
end

function WorldBuilder.Step(deltaTime)
	for _, sweeper in ipairs(sweepers) do
		sweeper.Angle = sweeper.Angle + sweeper.Speed * deltaTime
		sweeper.Part.CFrame = CFrame.new(sweeper.Center) * CFrame.Angles(0, sweeper.Angle, 0)
	end
end

return WorldBuilder
