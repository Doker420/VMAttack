-- Интерактивное voxel-лобби: NPC, деревянные табло и мини-карта на 12 пилотов.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Track = require(Shared:WaitForChild("Track"))

local LobbyService = {}

local DataService
local DroneService
local RaceService
local remotes
local raceState
local screens = {}
local mini
local uiClock = 0
local miniClock = 0

local COLORS = {
	Navy = Color3.fromRGB(45, 52, 48),
	Panel = Color3.fromRGB(91, 67, 44),
	Card = Color3.fromRGB(102, 110, 93),
	Cyan = Color3.fromRGB(105, 158, 181),
	Pink = Color3.fromRGB(174, 83, 58),
	Purple = Color3.fromRGB(96, 134, 72),
	White = Color3.fromRGB(233, 235, 214),
	Muted = Color3.fromRGB(170, 164, 137),
	Gold = Color3.fromRGB(214, 170, 65),
}

local MINI_SCALE = 0.055

local function makePart(parent, name, size, cframe, color, material)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.CFrame = cframe
	part.Color = color or COLORS.Panel
	part.Material = material or Enum.Material.WoodPlanks
	part.Anchored = true
	part.CanCollide = false
	part.CanTouch = false
	part.CanQuery = false
	part.CastShadow = false
	part.Parent = parent
	return part
end

local function makeText(parent, name, text, size, position, textSize, color, font)
	local label = Instance.new("TextLabel")
	label.Name = name
	label.Size = size
	label.Position = position or UDim2.new()
	label.BackgroundTransparency = 1
	label.Font = font or Enum.Font.Code
	label.Text = text
	label.TextSize = textSize or 13
	label.TextColor3 = color or COLORS.White
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.TextYAlignment = Enum.TextYAlignment.Center
	label.TextTruncate = Enum.TextTruncate.AtEnd
	label.Parent = parent
	return label
end

local function buildScreen(parent, name, position, titleText, accent)
	local spawn = Track.LobbySpawn.Position
	local cframe = CFrame.lookAt(position, Vector3.new(spawn.X, position.Y, spawn.Z))
	local part = makePart(parent, name, Vector3.new(26, 15, 0.8), cframe, COLORS.Navy, Enum.Material.WoodPlanks)
	makePart(parent, name .. "Edge", Vector3.new(26.5, 0.3, 1), cframe * CFrame.new(0, 7.65, 0), accent, Enum.Material.SmoothPlastic)
	makePart(parent, name .. "Stand", Vector3.new(1.4, 7, 1.4), CFrame.new(position.X, 85.5, position.Z), COLORS.Panel, Enum.Material.WoodPlanks)

	local surface = Instance.new("SurfaceGui")
	surface.Name = "Display"
	surface.Face = Enum.NormalId.Front
	surface.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	surface.PixelsPerStud = 16
	surface.LightInfluence = 0
	surface.Parent = part
	local background = Instance.new("Frame")
	background.Size = UDim2.fromScale(1, 1)
	background.BackgroundColor3 = COLORS.Navy
	background.BorderSizePixel = 0
	background.Parent = surface

	makeText(background, "Title", titleText, UDim2.fromOffset(400, 26), UDim2.fromOffset(8, 5), 20, accent, Enum.Font.Code)
	local subtitle = makeText(background, "Subtitle", "WAITING FOR SERVER", UDim2.fromOffset(400, 16), UDim2.fromOffset(8, 34), 12, COLORS.Muted, Enum.Font.Code)
	local rows = {}
	for index = 1, Config.MaxRacers do
		local row = Instance.new("Frame")
		row.Name = string.format("Row%02d", index)
		row.Position = UDim2.fromOffset(8, 55 + (index - 1) * 14)
		row.Size = UDim2.fromOffset(400, 13)
		row.BackgroundColor3 = index % 2 == 0 and COLORS.Panel or COLORS.Card
		row.BackgroundTransparency = 0.12
		row.BorderSizePixel = 0
		row.Parent = background
		local place = makeText(row, "Place", string.format("%02d", index), UDim2.fromOffset(30, 13), UDim2.fromOffset(4, 0), 12, COLORS.Muted, Enum.Font.Code)
		local pilot = makeText(row, "Pilot", "—", UDim2.fromOffset(216, 13), UDim2.fromOffset(34, 0), 12, COLORS.White, Enum.Font.Code)
		local detail = makeText(row, "Detail", "", UDim2.fromOffset(142, 13), UDim2.fromOffset(254, 0), 11, COLORS.Cyan, Enum.Font.Code)
		detail.TextXAlignment = Enum.TextXAlignment.Right
		rows[index] = { Frame = row, Place = place, Pilot = pilot, Detail = detail }
	end
	return { Part = part, Subtitle = subtitle, Rows = rows }
end

local function buildNPC(parent, definition)
	local model = Instance.new("Model")
	model.Name = "NPC_" .. definition.Id
	local spawn = Track.LobbySpawn.Position
	local rootCFrame = CFrame.lookAt(definition.Position + Vector3.new(0, 3.6, 0), Vector3.new(spawn.X, definition.Position.Y + 3.6, spawn.Z))
	local root = makePart(model, "HumanoidRootPart", Vector3.new(2, 2, 2), rootCFrame, COLORS.Panel)
	root.Transparency = 1
	model.PrimaryPart = root
	makePart(model, "Torso", Vector3.new(3, 3.4, 1.8), rootCFrame, COLORS.Panel, Enum.Material.WoodPlanks)
	makePart(model, "ChestLight", Vector3.new(1.8, 0.35, 0.2), rootCFrame * CFrame.new(0, 0.4, -0.95), definition.Color, Enum.Material.SmoothPlastic)
	local head = makePart(model, "Head", Vector3.new(2.1, 1.8, 1.8), rootCFrame * CFrame.new(0, 2.8, 0), COLORS.Navy, Enum.Material.WoodPlanks)
	makePart(model, "Visor", Vector3.new(1.45, 0.65, 0.18), head.CFrame * CFrame.new(0, 0, -0.93), definition.Color, Enum.Material.SmoothPlastic)
	for _, side in ipairs({ -1, 1 }) do
		makePart(model, "Leg", Vector3.new(1.1, 2.5, 1.3), rootCFrame * CFrame.new(side * 0.75, -2.45, 0), COLORS.Panel, Enum.Material.WoodPlanks)
		makePart(model, "Foot", Vector3.new(1.25, 0.55, 1.8), rootCFrame * CFrame.new(side * 0.75, -3.75, -0.25), COLORS.Navy, Enum.Material.WoodPlanks)
		makePart(model, "Arm", Vector3.new(0.75, 3, 1), rootCFrame * CFrame.new(side * 1.95, -0.1, 0), COLORS.Panel, Enum.Material.WoodPlanks)
		makePart(model, "ArmLight", Vector3.new(0.82, 0.35, 1.05), rootCFrame * CFrame.new(side * 1.95, -0.9, 0), definition.Color, Enum.Material.SmoothPlastic)
	end

	local billboard = Instance.new("BillboardGui")
	billboard.Name = "NPCName"
	billboard.Size = UDim2.fromOffset(230, 54)
	billboard.StudsOffsetWorldSpace = Vector3.new(0, 2.1, 0)
	billboard.AlwaysOnTop = true
	billboard.MaxDistance = 90
	billboard.Parent = head
	makeText(billboard, "Title", definition.Name, UDim2.new(1, 0, 0.55, 0), UDim2.new(), 18, definition.Color, Enum.Font.Code).TextXAlignment = Enum.TextXAlignment.Center
	makeText(billboard, "Role", definition.Role, UDim2.new(1, 0, 0.35, 0), UDim2.fromScale(0, 0.62), 12, COLORS.White, Enum.Font.Code).TextXAlignment = Enum.TextXAlignment.Center

	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "Interact"
	prompt.ActionText = definition.Action == "StartRace" and "E // START" or "E // OPEN"
	prompt.ObjectText = definition.Name
	prompt.KeyboardKeyCode = Enum.KeyCode.E
	prompt.GamepadKeyCode = Enum.KeyCode.ButtonX
	prompt.HoldDuration = 0
	prompt.MaxActivationDistance = 11
	prompt.RequiresLineOfSight = false
	prompt.Parent = root
	prompt.Triggered:Connect(function(player)
		if player and player.Parent then
			if definition.Action == "StartRace" then
				RaceService.HandleLobbyAction(player, "StartRace")
			else
				remotes.LobbyAction:FireClient(player, "OpenPanel", definition.Tab)
			end
		end
	end)
	model.Parent = parent
end

local function miniPosition(worldPosition)
	return mini.Origin + (worldPosition - Track.WorldCenter) * MINI_SCALE
end

local function createMiniDrone(index)
	local model = Instance.new("Model")
	model.Name = string.format("MiniPilot_%02d", index)
	local accent = index % 3 == 0 and COLORS.Pink or (index % 2 == 0 and COLORS.Purple or COLORS.Cyan)
	local root = makePart(model, "Root", Vector3.new(0.65, 0.22, 0.9), CFrame.new(mini.Origin), accent, Enum.Material.SmoothPlastic)
	model.PrimaryPart = root
	for _, x in ipairs({ -0.43, 0.43 }) do
		for _, z in ipairs({ -0.43, 0.43 }) do
			makePart(model, "Rotor", Vector3.new(0.24, 0.08, 0.24), CFrame.new(mini.Origin + Vector3.new(x, 0.12, z)), COLORS.White, Enum.Material.SmoothPlastic)
		end
	end
	return model
end

local function buildMiniRace(parent)
	local folder = Instance.new("Folder")
	folder.Name = "MiniRace"
	folder.Parent = parent
	local base = makePart(folder, "HolotableBase", Vector3.new(40, 2.2, 40), CFrame.new(0, 85.1, 338), COLORS.Panel, Enum.Material.WoodPlanks)
	base.CanCollide = true
	base.CanQuery = true
	local glass = makePart(folder, "HolotableGlass", Vector3.new(39, 0.25, 39), CFrame.new(0, 86.35, 338), COLORS.Cyan, Enum.Material.Glass)
	glass.Transparency = 0.32
	for _, side in ipairs({ -1, 1 }) do
		makePart(folder, "HolotableEdgeX", Vector3.new(40, 0.3, 0.3), CFrame.new(0, 86.55, 338 + side * 20), side == 1 and COLORS.Cyan or COLORS.Pink, Enum.Material.SmoothPlastic)
		makePart(folder, "HolotableEdgeZ", Vector3.new(0.3, 0.3, 40), CFrame.new(side * 20, 86.55, 338), side == 1 and COLORS.Purple or COLORS.Cyan, Enum.Material.SmoothPlastic)
	end

	mini = {
		Origin = Vector3.new(0, 88, 338),
		DronesFolder = Instance.new("Folder"),
		Models = {},
	}
	mini.DronesFolder.Name = "MiniPilots"
	mini.DronesFolder.Parent = folder
	local trackFolder = Instance.new("Folder")
	trackFolder.Name = "MiniTrack"
	trackFolder.Parent = folder

	for index, gate in ipairs(Track.Gates) do
		local nextGate = Track.Gates[index % #Track.Gates + 1]
		local a = miniPosition(gate.Position)
		local b = miniPosition(nextGate.Position)
		local direction = b - a
		local accent = index == 1 and COLORS.Pink or (index % 3 == 0 and COLORS.Purple or COLORS.Cyan)
		local segment = makePart(trackFolder, "MiniSegment", Vector3.new(0.18, 0.18, direction.Magnitude), CFrame.lookAt((a + b) * 0.5, b), accent, Enum.Material.SmoothPlastic)
		segment.Transparency = 0.12
		local cframe = CFrame.lookAt(a, b)
		local width = gate.Width * MINI_SCALE
		local height = gate.Height * MINI_SCALE
		makePart(trackFolder, "MiniGateSide", Vector3.new(0.12, height, 0.12), cframe * CFrame.new(-width / 2, 0, 0), accent, Enum.Material.SmoothPlastic)
		makePart(trackFolder, "MiniGateSide", Vector3.new(0.12, height, 0.12), cframe * CFrame.new(width / 2, 0, 0), accent, Enum.Material.SmoothPlastic)
		makePart(trackFolder, "MiniGateTop", Vector3.new(width, 0.12, 0.12), cframe * CFrame.new(0, height / 2, 0), accent, Enum.Material.SmoothPlastic)
		makePart(trackFolder, "MiniGateBottom", Vector3.new(width, 0.12, 0.12), cframe * CFrame.new(0, -height / 2, 0), accent, Enum.Material.SmoothPlastic)
	end

	local anchor = makePart(folder, "MiniStatusAnchor", Vector3.one, CFrame.new(0, 96, 338), COLORS.Navy)
	anchor.Transparency = 1
	local billboard = Instance.new("BillboardGui")
	billboard.Name = "MiniStatus"
	billboard.Size = UDim2.fromOffset(300, 64)
	billboard.AlwaysOnTop = true
	billboard.MaxDistance = 150
	billboard.Parent = anchor
	makeText(billboard, "Title", "LIVE MAP RACE // 12", UDim2.new(1, 0, 0.55, 0), UDim2.new(), 22, COLORS.Cyan, Enum.Font.Code).TextXAlignment = Enum.TextXAlignment.Center
	mini.Status = makeText(billboard, "Status", "WAITING FOR PILOTS", UDim2.new(1, 0, 0.3, 0), UDim2.fromScale(0, 0.65), 13, COLORS.White, Enum.Font.Code)
	mini.Status.TextXAlignment = Enum.TextXAlignment.Center
	for index = 1, Config.MaxRacers do
		mini.Models[index] = createMiniDrone(index)
	end
end

local function getRacers()
	local racers = {}
	for _, player in ipairs(Players:GetPlayers()) do
		if player:GetAttribute("Racing") == true then
			table.insert(racers, {
				Player = player,
				UserId = player.UserId,
				Name = player.DisplayName,
				Place = player:GetAttribute("Place") or 0,
				Lap = player:GetAttribute("Lap") or 0,
				Gate = player:GetAttribute("Gate") or 0,
				Finished = player:GetAttribute("Finished") == true,
				FinishTime = player:GetAttribute("FinishTime") or 0,
				Speed = DroneService.GetSpeed(player),
			})
		end
	end
	table.sort(racers, function(a, b)
		local aPlace = a.Place > 0 and a.Place or 999
		local bPlace = b.Place > 0 and b.Place or 999
		if aPlace ~= bPlace then
			return aPlace < bPlace
		end
		return a.UserId < b.UserId
	end)
	return racers
end

local function getRoster()
	local roster = {}
	for _, player in ipairs(Players:GetPlayers()) do
		local data = DataService.Get(player)
		table.insert(roster, {
			Name = player.DisplayName,
			Rating = player:GetAttribute("Rating") or (data and data.Rating) or Config.Rating.StartingRating,
			Eliminations = player:GetAttribute("Eliminations") or (data and data.Eliminations) or 0,
			Wins = player:GetAttribute("Wins") or (data and data.Wins) or 0,
			Level = player:GetAttribute("Level") or 1,
		})
	end
	table.sort(roster, function(a, b)
		if a.Rating ~= b.Rating then
			return a.Rating > b.Rating
		end
		if a.Eliminations ~= b.Eliminations then
			return a.Eliminations > b.Eliminations
		end
		if a.Wins ~= b.Wins then
			return a.Wins > b.Wins
		end
		if a.Level ~= b.Level then
			return a.Level > b.Level
		end
		return a.Name < b.Name
	end)
	return roster
end

local function updateRows(screen, entries, kind)
	for index, row in ipairs(screen.Rows) do
		local entry = entries[index]
		row.Frame.Visible = entry ~= nil
		if entry then
			row.Place.Text = string.format("%02d", index)
			row.Place.TextColor3 = index <= 3 and COLORS.Gold or COLORS.Muted
			row.Pilot.Text = entry.Name
			if kind == "Race" then
				row.Detail.Text = entry.Finished and Config.FormatTime(entry.FinishTime) or string.format("L%d G%02d · %d", math.max(1, entry.Lap), entry.Gate, math.floor(entry.Speed * 1.2 + 0.5))
			else
				row.Detail.Text = string.format("%d R · %d KO", entry.Rating, entry.Eliminations)
			end
		end
	end
end

local function updateScreens()
	local phase = raceState:GetAttribute("Phase") or "Boot"
	local racers = getRacers()
	local roster = getRoster()
	screens.Standings.Subtitle.Text = string.format("%s · %d / 12 PILOTS", string.upper(phase), #racers)
	screens.Roster.Subtitle.Text = string.format("SERVER ELO · %d / 12 PLAYERS", #roster)
	updateRows(screens.Standings, racers, "Race")
	updateRows(screens.Roster, roster, "Roster")
end

local function updateMiniRace(racers)
	local phase = raceState:GetAttribute("Phase") or "Boot"
	mini.Status.Text = string.format("%s · %d / 12 PILOTS", string.upper(phase), #racers)
	for index, model in ipairs(mini.Models) do
		local entry = racers[index]
		local drone = entry and DroneService.GetModel(entry.Player)
		local root = drone and drone.PrimaryPart
		if root then
			local position = miniPosition(root.Position)
			model:PivotTo(CFrame.lookAt(position, position + root.CFrame.LookVector))
			model.Parent = mini.DronesFolder
		else
			model.Parent = nil
		end
	end
end

function LobbyService.Step(deltaTime)
	miniClock = miniClock + deltaTime
	uiClock = uiClock + deltaTime
	if miniClock >= 0.05 then
		miniClock = 0
		updateMiniRace(getRacers())
	end
	if uiClock >= 0.5 then
		uiClock = 0
		updateScreens()
	end
end

function LobbyService.Init(dependencies)
	DataService = dependencies.DataService
	DroneService = dependencies.DroneService
	RaceService = dependencies.RaceService
	remotes = dependencies.Remotes
	raceState = ReplicatedStorage:WaitForChild("AeroRushState")
	local folder = Instance.new("Folder")
	folder.Name = "LobbySystems"
	folder.Parent = dependencies.World.Lobby

	screens.Standings = buildScreen(folder, "LiveRaceScreen", Vector3.new(-43, 95, 348), "LIVE RACE // TOP 12", COLORS.Cyan)
	screens.Roster = buildScreen(folder, "PilotRatingScreen", Vector3.new(43, 95, 348), "PILOT RATING // ELO + DISABLES", COLORS.Purple)
	buildNPC(folder, { Id = "Nova", Name = "NOVA // VILLAGE BONUS", Role = "DAILY + REWARDS", Tab = "Bonus", Position = Vector3.new(-52.7, 85.05, 380.54), Color = COLORS.Cyan })
	buildNPC(folder, { Id = "Gear", Name = "GEAR // LOOTBOX KEEPER", Role = "LASERS + TRAPS", Tab = "Arsenal", Position = Vector3.new(52.7, 85.05, 380.54), Color = COLORS.Pink })
	buildNPC(folder, { Id = "Iris", Name = "IRIS // BLOCK STYLIST", Role = "SKINS + TRAILS", Tab = "Garage", Position = Vector3.new(-54.72, 85.05, 292.41), Color = COLORS.Purple })
	buildNPC(folder, { Id = "Orbit", Name = "ORBIT // SUPPLY", Role = "SHOP + CREDITS", Tab = "Shop", Position = Vector3.new(54.72, 85.05, 292.41), Color = COLORS.Gold })
	buildNPC(folder, { Id = "Piston", Name = "BLOCK // RACE START", Role = "SOLO + MULTIPLAYER", Action = "StartRace", Position = Vector3.new(-15, 84.9, 366), Color = COLORS.Gold })
	buildNPC(folder, { Id = "Volt", Name = "VOLT // TUNING HUT", Role = "UPGRADES + PRESETS", Tab = "Tuning", Position = Vector3.new(0, 85.05, 398.5), Color = COLORS.Gold })
	buildMiniRace(folder)
	updateScreens()
end

return LobbyService
