-- Магазин, гараж, ежедневные награды и задания.
local MarketplaceService = game:GetService("MarketplaceService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Catalog = require(Shared:WaitForChild("Catalog"))
local Gadgets = require(Shared:WaitForChild("Gadgets"))
local Tuning = require(Shared:WaitForChild("Tuning"))
local remotes = Shared:WaitForChild("Remotes")
local raceState = ReplicatedStorage:WaitForChild("AeroRushState")

local C = {
	Navy = Color3.fromRGB(38, 45, 39),
	Panel = Color3.fromRGB(69, 75, 59),
	Card = Color3.fromRGB(80, 88, 69),
	Cyan = Color3.fromRGB(105, 158, 181),
	Pink = Color3.fromRGB(174, 83, 58),
	Gold = Color3.fromRGB(214, 170, 65),
	White = Color3.fromRGB(235, 237, 216),
	Muted = Color3.fromRGB(170, 164, 137),
	Green = Color3.fromRGB(110, 155, 75),
}

local function create(className, properties, parent)
	local instance = Instance.new(className)
	for property, value in pairs(properties or {}) do
		instance[property] = value
	end
	instance.Parent = parent
	return instance
end

local function corner(parent, radius)
	create("UICorner", { CornerRadius = UDim.new(0, math.min(radius or 10, 3)) }, parent)
end

local function stroke(parent, color, transparency)
	return create("UIStroke", { Color = color, Transparency = transparency or 0.55, Thickness = 1 }, parent)
end

local function label(parent, text, size, position, textSize, color, font)
	return create("TextLabel", {
		Size = size,
		Position = position or UDim2.new(),
		BackgroundTransparency = 1,
		Text = text,
		TextColor3 = color or C.White,
		TextSize = textSize or 15,
		Font = font or Enum.Font.Code,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextYAlignment = Enum.TextYAlignment.Center,
	}, parent)
end

local function button(parent, text, size, position, color)
	local result = create("TextButton", {
		Size = size,
		Position = position or UDim2.new(),
		BackgroundColor3 = color or C.Card,
		Text = text,
		TextColor3 = color == C.Cyan and C.Navy or C.White,
		TextSize = 13,
		Font = Enum.Font.Code,
		AutoButtonColor = true,
	}, parent)
	corner(result, 9)
	return result
end

local screen = create("ScreenGui", {
	Name = "AeroRushMeta",
	ResetOnSpawn = false,
	IgnoreGuiInset = true,
	DisplayOrder = 15,
	ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
}, playerGui)

local profile = {
	Credits = 0,
	Tech = 0,
	CoinBalance = 0,
	LifetimeCoins = 0,
	BestCoinCombo = 0,
	TuningPreset = "Balanced",
	UpgradeLevels = { Engine = 0, Battery = 0, Handling = 0 },
	Wins = 0,
	Races = 0,
	Rating = 1000,
	PeakRating = 1000,
	RatingMatches = 0,
	Eliminations = 0,
	LastRatingDelta = 0,
	XP = 0,
	Level = 1,
	BoostCreditRaces = 0,
	BoostCreditMultiplier = 2,
	OwnedCosmetics = {},
	Passes = {},
	SelectedSkin = "SkinCyan",
	SelectedTrail = "TrailCyan",
	DailyClaims = 0,
	LastDailyClaim = 0,
	QuestProgress = {},
	QuestRewards = {},
	FriendBonus = 0,
	ServerTime = 0,
	StudioTest = false,
	OwnedGadgets = {},
	SelectedAttack = "PulseLaser",
	SelectedDefense = "RepairPulse",
	CaseTokens = 0,
	CaseProgress = 0,
	CasesOpened = 0,
	LegendaryPity = 0,
}
local serverOffset = 0
local actualPrices = {}
local currentTab = "Shop"

local profileCard = create("Frame", {
	Name = "Profile",
	AnchorPoint = Vector2.new(1, 0),
	Position = UDim2.new(1, -22, 0, 20),
	Size = UDim2.fromOffset(292, 66),
	BackgroundColor3 = C.Navy,
	BackgroundTransparency = 0.1,
}, screen)
corner(profileCard, 12)
local profileStroke = stroke(profileCard, C.Cyan, 0.65)
local levelLabel = label(profileCard, "УР. 1", UDim2.fromOffset(64, 26), UDim2.fromOffset(14, 8), 18, C.Cyan, Enum.Font.Code)
local creditsLabel = label(profileCard, "0 CR", UDim2.fromOffset(104, 26), UDim2.fromOffset(94, 8), 17, C.White, Enum.Font.Code)
creditsLabel.TextXAlignment = Enum.TextXAlignment.Right
local ratingLabel = label(profileCard, "1000 R", UDim2.fromOffset(76, 26), UDim2.fromOffset(202, 8), 16, C.Gold, Enum.Font.Code)
ratingLabel.TextXAlignment = Enum.TextXAlignment.Right
local boostLabel = label(profileCard, "ПРОФИЛЬ ПИЛОТА", UDim2.fromOffset(260, 20), UDim2.fromOffset(14, 38), 11, C.Muted, Enum.Font.Code)

local menu = create("Frame", { Name = "Menu", Size = UDim2.fromOffset(168, 240), Position = UDim2.fromOffset(22, 260), BackgroundTransparency = 1 }, screen)
local menuScale = create("UIScale", {}, menu)
local shopButton = button(menu, "МАГАЗИН", UDim2.fromOffset(160, 40), UDim2.fromOffset(0, 0), C.Cyan)
local bonusButton = button(menu, "БОНУСЫ", UDim2.fromOffset(160, 40), UDim2.fromOffset(0, 48), C.Card)
stroke(bonusButton, C.Cyan, 0.65)
local garageButton = button(menu, "ГАРАЖ", UDim2.fromOffset(160, 40), UDim2.fromOffset(0, 96), C.Card)
stroke(garageButton, C.Pink, 0.65)
local arsenalButton = button(menu, "АРСЕНАЛ", UDim2.fromOffset(160, 40), UDim2.fromOffset(0, 144), C.Card)
stroke(arsenalButton, C.Gold, 0.65)
local tuningButton = button(menu, "ТЮНИНГ", UDim2.fromOffset(160, 40), UDim2.fromOffset(0, 192), C.Card)
stroke(tuningButton, C.Green, 0.65)
local dailyDot = label(bonusButton, "!", UDim2.fromOffset(24, 24), UDim2.new(1, -28, 0, 4), 16, C.Gold, Enum.Font.Code)
dailyDot.TextXAlignment = Enum.TextXAlignment.Center
dailyDot.BackgroundTransparency = 0
dailyDot.BackgroundColor3 = C.Navy
corner(dailyDot, 12)

local overlay = create("Frame", { Size = UDim2.fromScale(1, 1), BackgroundColor3 = C.Navy, BackgroundTransparency = 0.28, Visible = false, Active = true }, screen)
local modal = create("Frame", { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(760, 570), BackgroundColor3 = C.Panel, BackgroundTransparency = 0.02 }, overlay)
corner(modal, 18)
stroke(modal, C.Cyan, 0.35)
local modalScale = create("UIScale", {}, modal)
local title = label(modal, "МАГАЗИН", UDim2.fromOffset(570, 40), UDim2.fromOffset(28, 20), 29, C.White, Enum.Font.Code)
local closeButton = button(modal, "×", UDim2.fromOffset(44, 40), UDim2.fromOffset(686, 22), C.Card)
closeButton.TextSize = 25
local tabs = create("Frame", { Size = UDim2.fromOffset(704, 38), Position = UDim2.fromOffset(28, 76), BackgroundTransparency = 1 }, modal)
local tabShop = button(tabs, "ROBUX", UDim2.fromOffset(128, 38), UDim2.fromOffset(0, 0), C.Cyan)
local tabGarage = button(tabs, "ГАРАЖ", UDim2.fromOffset(128, 38), UDim2.fromOffset(136, 0), C.Card)
local tabTuning = button(tabs, "ТЮНИНГ", UDim2.fromOffset(128, 38), UDim2.fromOffset(272, 0), C.Card)
local tabBonus = button(tabs, "БОНУСЫ", UDim2.fromOffset(128, 38), UDim2.fromOffset(408, 0), C.Card)
local tabArsenal = button(tabs, "АРСЕНАЛ", UDim2.fromOffset(128, 38), UDim2.fromOffset(544, 0), C.Card)
local content = create("ScrollingFrame", {
	Position = UDim2.fromOffset(28, 134),
	Size = UDim2.fromOffset(704, 366),
	BackgroundTransparency = 1,
	BorderSizePixel = 0,
	CanvasSize = UDim2.new(),
	AutomaticCanvasSize = Enum.AutomaticSize.Y,
	ScrollBarThickness = 5,
	ScrollBarImageColor3 = C.Cyan,
}, modal)
local disclosure = label(modal, "Покупки необязательны · платных кейсов нет · тюнинг только за TECH из монет и финишей · Robux не улучшает характеристики", UDim2.fromOffset(704, 38), UDim2.fromOffset(28, 516), 11, C.Muted)
disclosure.TextWrapped = true

local function serverNow()
	return os.time() + serverOffset
end

local function dailyAvailable()
	return profile.LastDailyClaim == 0 or serverNow() - profile.LastDailyClaim >= Config.DailyCooldown
end

local function updateProfileCard()
	levelLabel.Text = "УР. " .. tostring(profile.Level)
	creditsLabel.Text = tostring(math.floor(profile.Credits)) .. " CR"
	ratingLabel.Text = tostring(math.floor(profile.Rating or 1000)) .. " R"
	boostLabel.Text = profile.BoostCreditRaces > 0 and string.format("2× КРЕДИТЫ · %d ФИНИШЕЙ", profile.BoostCreditRaces) or string.format("%d МОНЕТ · %d TECH", profile.CoinBalance or 0, profile.Tech or 0)
	boostLabel.TextColor3 = profile.BoostCreditRaces > 0 and C.Gold or C.Muted
	profileStroke.Color = profile.Passes.AeroClub and C.Gold or C.Cyan
	dailyDot.Visible = dailyAvailable()
end

local order = 0
local function resetContent()
	content:ClearAllChildren()
	order = 0
	create("UIListLayout", { Padding = UDim.new(0, 8), SortOrder = Enum.SortOrder.LayoutOrder }, content)
	content.CanvasPosition = Vector2.zero
end

local function arrange(gui)
	order = order + 1
	gui.LayoutOrder = order
	return gui
end

local function section(text)
	local header = arrange(label(content, text, UDim2.new(1, -8, 0, 30), UDim2.new(), 13, C.Cyan, Enum.Font.Code))
	header.BackgroundTransparency = 0.15
	header.BackgroundColor3 = C.Navy
	corner(header, 7)
end

local function setTabColors()
	for _, entry in ipairs({ { tabShop, "Shop" }, { tabGarage, "Garage" }, { tabTuning, "Tuning" }, { tabBonus, "Bonus" }, { tabArsenal, "Arsenal" } }) do
		local active = entry[2] == currentTab
		entry[1].BackgroundColor3 = active and C.Cyan or C.Card
		entry[1].TextColor3 = active and C.Navy or C.White
	end
end

local render

local function renderShop()
	title.Text = "МАГАЗИН AERORUSH"
	for _, item in ipairs(Catalog.ShopItems) do
		local row = arrange(create("Frame", { Size = UDim2.new(1, -8, 0, 94), BackgroundColor3 = C.Card, BackgroundTransparency = 0.05 }, content))
		corner(row, 11)
		local tag = label(row, item.Tag, UDim2.fromOffset(62, 48), UDim2.fromOffset(12, 23), 14, item.Action == "Donation" and C.Gold or C.Cyan, Enum.Font.Code)
		tag.TextXAlignment = Enum.TextXAlignment.Center
		tag.BackgroundTransparency = 0.08
		tag.BackgroundColor3 = C.Navy
		corner(tag, 9)
		label(row, item.Name, UDim2.fromOffset(440, 25), UDim2.fromOffset(88, 10), 16, C.White, Enum.Font.Code)
		local description = label(row, item.Description, UDim2.fromOffset(448, 48), UDim2.fromOffset(88, 39), 12, C.Muted)
		description.TextWrapped = true
		description.TextYAlignment = Enum.TextYAlignment.Top

		local owned = item.Kind == "GamePass" and profile.Passes[item.Id]
		local available = item.ProductId > 0 or profile.StudioTest
		local price = actualPrices[item.Id] or item.PriceRobux
		local purchase = button(row, owned and "КУПЛЕНО" or (available and (profile.StudioTest and "ТЕСТ · " or "") .. price .. " R$" or "СКОРО"), UDim2.fromOffset(132, 44), UDim2.fromOffset(552, 25), owned and C.Card or C.Cyan)
		purchase.AutoButtonColor = not owned and available
		if not owned and available then
			purchase.Activated:Connect(function()
				remotes.ShopAction:FireServer("Purchase", item.Id)
			end)
		end
	end
end

local function cosmeticOwned(cosmetic)
	return cosmetic.Free
		or profile.OwnedCosmetics[cosmetic.Id]
		or (cosmetic.UnlockLevel and profile.Level >= cosmetic.UnlockLevel)
		or (cosmetic.UnlockCoins and (profile.LifetimeCoins or 0) >= cosmetic.UnlockCoins)
		or (cosmetic.UnlockRaces and (profile.Races or 0) >= cosmetic.UnlockRaces)
		or (cosmetic.GamePass and profile.Passes[cosmetic.GamePass])
		or false
end

local function renderCosmetic(cosmetic)
	local row = arrange(create("Frame", { Size = UDim2.new(1, -8, 0, 74), BackgroundColor3 = C.Card, BackgroundTransparency = 0.05 }, content))
	corner(row, 10)
	local colorA = cosmetic.Accent or cosmetic.ColorA
	local colorB = cosmetic.Secondary or cosmetic.ColorB
	local swatch = create("Frame", { Size = UDim2.fromOffset(48, 48), Position = UDim2.fromOffset(12, 13), BackgroundColor3 = colorA, BorderSizePixel = 0 }, row)
	corner(swatch, 10)
	create("Frame", { Size = UDim2.fromOffset(18, 18), Position = UDim2.fromOffset(24, 24), BackgroundColor3 = colorB, BorderSizePixel = 0 }, swatch)
	local modelName = cosmetic.Type == "Skin" and (cosmetic.Model or "Quad") or "СЛЕД"
	label(row, cosmetic.Name .. "  ·  " .. modelName, UDim2.fromOffset(350, 25), UDim2.fromOffset(76, 9), 15, C.White, Enum.Font.Code)
	local requirement = "Game Pass"
	if cosmetic.Free then
		requirement = "Бесплатно"
	elseif cosmetic.CreditPrice then
		requirement = cosmetic.CreditPrice .. " кредитов"
	elseif cosmetic.UnlockCoins then
		requirement = string.format("Собери %d монет всего", cosmetic.UnlockCoins)
	elseif cosmetic.UnlockRaces then
		requirement = string.format("Финишируй %d раз", cosmetic.UnlockRaces)
	elseif cosmetic.UnlockLevel then
		requirement = "Открывается на уровне " .. cosmetic.UnlockLevel
	elseif cosmetic.GamePass then
		requirement = ((Catalog.GetShopItem(cosmetic.GamePass) or {}).Name or "Game Pass")
	end
	label(row, requirement, UDim2.fromOffset(390, 22), UDim2.fromOffset(76, 39), 12, C.Muted)

	local owned = cosmeticOwned(cosmetic)
	local selected = profile.SelectedSkin == cosmetic.Id or profile.SelectedTrail == cosmetic.Id
	local action = button(row, "", UDim2.fromOffset(136, 40), UDim2.fromOffset(548, 17), selected and C.Card or (owned and C.Cyan or C.Card))
	if selected then
		action.Text = "ВЫБРАНО"
	elseif owned then
		action.Text = "НАДЕТЬ"
		action.Activated:Connect(function()
			remotes.ShopAction:FireServer("Equip", cosmetic.Id)
		end)
	elseif cosmetic.CreditPrice then
		action.Text = cosmetic.CreditPrice .. " CR"
		action.TextColor3 = C.Gold
		action.Activated:Connect(function()
			remotes.ShopAction:FireServer("BuyCosmetic", cosmetic.Id)
		end)
	elseif cosmetic.GamePass then
		action.Text = "МАГАЗИН"
		action.Activated:Connect(function()
			currentTab = "Shop"
			render()
		end)
	elseif cosmetic.UnlockCoins then
		action.Text = string.format("%d МОНЕТ", cosmetic.UnlockCoins)
		action.TextSize = 11
	elseif cosmetic.UnlockRaces then
		action.Text = string.format("%d ФИНИШЕЙ", cosmetic.UnlockRaces)
		action.TextSize = 11
	else
		action.Text = "УР. " .. tostring(cosmetic.UnlockLevel)
	end
end

local function renderGarage()
	title.Text = "ГАРАЖ И СТИЛЬ"
	section("СКИНЫ ДРОНА")
	for _, cosmetic in ipairs(Catalog.Cosmetics) do
		if cosmetic.Type == "Skin" then
			renderCosmetic(cosmetic)
		end
	end
	section("СЛЕДЫ ДВИГАТЕЛЕЙ")
	for _, cosmetic in ipairs(Catalog.Cosmetics) do
		if cosmetic.Type == "Trail" then
			renderCosmetic(cosmetic)
		end
	end
end

local function renderArsenal()
	title.Text = "АРСЕНАЛ И ЛУТБОКСЫ"
	section("ЛУТБОКС · 25 МОНЕТ ИЛИ 1 ИГРОВОЙ ЖЕТОН")
	local caseCard = arrange(create("Frame", { Size = UDim2.new(1, -8, 0, 144), BackgroundColor3 = C.Card }, content))
	corner(caseCard, 4)
	stroke(caseCard, C.Gold, 0.65)
	label(caseCard, string.format("МОНЕТ: %d  ·  ЖЕТОНОВ: %d", profile.CoinBalance or 0, profile.CaseTokens or 0), UDim2.fromOffset(500, 28), UDim2.fromOffset(18, 10), 17, C.Gold, Enum.Font.Code)
	label(caseCard, string.format("Шансы: зелёный %d%% · синий %d%% · легендарный %d%%", Gadgets.Case.Odds.Green, Gadgets.Case.Odds.Blue, Gadgets.Case.Odds.Legendary), UDim2.fromOffset(500, 24), UDim2.fromOffset(18, 44), 13, C.White, Enum.Font.Code)
	label(caseCard, string.format("До гарантии легендарного: не более %d открытий · дубликат = кредиты", math.max(1, Gadgets.Case.LegendaryPity - (profile.LegendaryPity or 0))), UDim2.fromOffset(500, 24), UDim2.fromOffset(18, 72), 12, C.Muted)
	label(caseCard, "Монетки собираются на трассе · платных лутбоксов нет", UDim2.fromOffset(500, 34), UDim2.fromOffset(18, 103), 11, C.Cyan)
	local open = button(caseCard, (profile.CaseTokens or 0) > 0 and "1 ЖЕТОН" or "НЕТ ЖЕТОНА", UDim2.fromOffset(140, 40), UDim2.fromOffset(538, 38), (profile.CaseTokens or 0) > 0 and C.Gold or C.Card)
	if (profile.CaseTokens or 0) > 0 then
		open.Activated:Connect(function()
			open.Text = "ОТКРЫВАЕМ…"
			remotes.CombatAction:FireServer("OpenCase")
		end)
	end
	local coinOpen = button(caseCard, string.format("%d МОНЕТ", Gadgets.Case.CoinPrice), UDim2.fromOffset(140, 40), UDim2.fromOffset(538, 88), (profile.CoinBalance or 0) >= Gadgets.Case.CoinPrice and C.Green or C.Card)
	coinOpen.Activated:Connect(function()
		coinOpen.Text = "ОТКРЫВАЕМ…"
		remotes.CombatAction:FireServer("OpenCaseCoins")
	end)

	section("ГАДЖЕТЫ · F — АТАКА · G — ЗАЩИТА")
	for _, gadget in ipairs(Gadgets.List) do
		local row = arrange(create("Frame", { Size = UDim2.new(1, -8, 0, 92), BackgroundColor3 = C.Card }, content))
		corner(row, 10)
		local swatch = create("Frame", { Size = UDim2.fromOffset(54, 54), Position = UDim2.fromOffset(12, 19), BackgroundColor3 = C.Navy, BorderSizePixel = 0 }, row)
		corner(swatch, 10)
		stroke(swatch, gadget.Color, 0.2)
		local rarityLetter = gadget.Rarity == "Legendary" and "L" or (gadget.Rarity == "Blue" and "B" or "G")
		local icon = label(swatch, rarityLetter, UDim2.fromScale(1, 1), UDim2.new(), 25, gadget.Color, Enum.Font.Code)
		icon.TextXAlignment = Enum.TextXAlignment.Center
		label(row, gadget.Name .. " · " .. gadget.RarityName, UDim2.fromOffset(430, 25), UDim2.fromOffset(82, 8), 15, gadget.Color, Enum.Font.Code)
		local description = label(row, gadget.Description, UDim2.fromOffset(448, 42), UDim2.fromOffset(82, 36), 12, C.Muted)
		description.TextWrapped = true
		description.TextYAlignment = Enum.TextYAlignment.Top
		local owned = gadget.Free or profile.OwnedGadgets[gadget.Id] or (gadget.UnlockRaces and (profile.Races or 0) >= gadget.UnlockRaces)
		local selected = profile.SelectedAttack == gadget.Id or profile.SelectedDefense == gadget.Id
		local action = button(row, "", UDim2.fromOffset(126, 42), UDim2.fromOffset(552, 25), selected and C.Card or (owned and gadget.Color or C.Card))
		if selected then
			action.Text = gadget.Slot == "Attack" and "НА F" or "НА G"
			action.TextColor3 = gadget.Color
		elseif owned then
			action.Text = gadget.Slot == "Attack" and "ВЫБРАТЬ F" or "ВЫБРАТЬ G"
			action.TextColor3 = C.Navy
			action.Activated:Connect(function()
				remotes.CombatAction:FireServer("Equip", gadget.Id)
			end)
		else
			action.Text = gadget.UnlockRaces .. " ФИН. / КЕЙС"
			action.TextSize = 11
		end
	end
end

local function renderTuning()
	title.Text = "ТЮНИНГ И УЛУЧШЕНИЯ"
	local stats = Tuning.GetStats(profile)
	local summary = arrange(create("Frame", { Size = UDim2.new(1, -8, 0, 112), BackgroundColor3 = C.Card }, content))
	corner(summary, 12)
	stroke(summary, C.Green, 0.55)
	label(summary, string.format("%d TECH", profile.Tech or 0), UDim2.fromOffset(330, 34), UDim2.fromOffset(18, 10), 25, C.Gold, Enum.Font.Code)
	label(summary, string.format("Монет всего: %d · лучшая серия ×%d", profile.LifetimeCoins or 0, profile.BestCoinCombo or 0), UDim2.fromOffset(350, 22), UDim2.fromOffset(18, 49), 13, C.White, Enum.Font.Code)
	label(summary, "TECH добывается только в игре: монетки + финиши. Не продаётся за Robux или кредиты.", UDim2.fromOffset(650, 22), UDim2.fromOffset(18, 79), 11, C.Muted)
	label(summary, string.format("СКР %d%% · BOOST %d%% · БАТАРЕЯ %d%%", math.floor(stats.Speed * 100 + 0.5), math.floor(stats.BoostSpeed * 100 + 0.5), math.floor(stats.Capacity * 100 + 0.5)), UDim2.fromOffset(300, 48), UDim2.fromOffset(384, 14), 12, C.Cyan, Enum.Font.Code)

	section("ПРЕСЕТЫ · ПЛЮСЫ И МИНУСЫ · ПРИМЕНЕНИЕ НА СЛЕДУЮЩЕМ ДРОНЕ")
	for _, preset in ipairs(Tuning.Presets) do
		local row = arrange(create("Frame", { Size = UDim2.new(1, -8, 0, 74), BackgroundColor3 = C.Card }, content))
		corner(row, 10)
		local selected = profile.TuningPreset == preset.Id
		label(row, preset.Name, UDim2.fromOffset(180, 25), UDim2.fromOffset(16, 9), 16, selected and C.Green or C.White, Enum.Font.Code)
		local description = label(row, preset.Description, UDim2.fromOffset(510, 28), UDim2.fromOffset(16, 39), 12, C.Muted)
		description.TextWrapped = true
		local action = button(row, selected and "ВЫБРАНО" or "НАСТРОИТЬ", UDim2.fromOffset(136, 40), UDim2.fromOffset(542, 17), selected and C.Card or C.Cyan)
		if not selected then
			action.Activated:Connect(function()
				remotes.TuningAction:FireServer("EquipPreset", preset.Id)
			end)
		end
	end

	section("МОДУЛИ · 3 УРОВНЯ · ПОСТОЯННЫЕ УЛУЧШЕНИЯ ЗА TECH")
	for _, module in ipairs(Tuning.Modules) do
		local level = Tuning.GetLevel(profile, module.Id)
		local row = arrange(create("Frame", { Size = UDim2.new(1, -8, 0, 94), BackgroundColor3 = C.Card }, content))
		corner(row, 10)
		label(row, module.Name, UDim2.fromOffset(350, 25), UDim2.fromOffset(16, 9), 16, C.White, Enum.Font.Code)
		label(row, string.format("УР. %d / %d", level, Tuning.MaxModuleLevel), UDim2.fromOffset(110, 24), UDim2.fromOffset(424, 10), 13, level == Tuning.MaxModuleLevel and C.Green or C.Cyan, Enum.Font.Code)
		local description = label(row, module.Description, UDim2.fromOffset(500, 36), UDim2.fromOffset(16, 42), 12, C.Muted)
		description.TextWrapped = true
		for index = 1, Tuning.MaxModuleLevel do
			local pip = create("Frame", { Size = UDim2.fromOffset(28, 7), Position = UDim2.fromOffset(16 + (index - 1) * 34, 78), BackgroundColor3 = index <= level and C.Green or C.Navy, BorderSizePixel = 0 }, row)
			corner(pip, 3)
		end
		local action = button(row, "", UDim2.fromOffset(136, 42), UDim2.fromOffset(542, 26), level == Tuning.MaxModuleLevel and C.Card or C.Green)
		if level == Tuning.MaxModuleLevel then
			action.Text = "МАКСИМУМ"
		else
			local cost = Tuning.ModuleCosts[level + 1]
			action.Text = cost .. " TECH"
			action.TextColor3 = (profile.Tech or 0) >= cost and C.Navy or C.Gold
			action.Activated:Connect(function()
				remotes.TuningAction:FireServer("Upgrade", module.Id)
			end)
		end
	end
end

local function renderBonus()
	title.Text = "БЕСПЛАТНЫЕ БОНУСЫ"
	local day = profile.DailyClaims % #Catalog.DailyRewards + 1
	local reward = Catalog.DailyRewards[day]
	local daily = arrange(create("Frame", { Size = UDim2.new(1, -8, 0, 104), BackgroundColor3 = C.Card }, content))
	corner(daily, 12)
	label(daily, "ЕЖЕДНЕВНЫЙ ПОДАРОК · ДЕНЬ " .. day, UDim2.fromOffset(450, 28), UDim2.fromOffset(18, 12), 18, C.Gold, Enum.Font.Code)
	label(daily, string.format("+%d кредитов · +50 XP%s%s", reward.Credits, reward.BoostRaces and " · бустер" or "", reward.CaseTokens and (" · +" .. reward.CaseTokens .. " жетон") or ""), UDim2.fromOffset(500, 26), UDim2.fromOffset(18, 50), 13, C.White, Enum.Font.Code)
	label(daily, "Серия не сгорает, если пропустить день.", UDim2.fromOffset(460, 20), UDim2.fromOffset(18, 77), 11, C.Muted)
	local claim = button(daily, "ПОЛУЧИТЬ", UDim2.fromOffset(144, 46), UDim2.fromOffset(536, 29), dailyAvailable() and C.Cyan or C.Card)
	if dailyAvailable() then
		claim.Activated:Connect(function()
			remotes.EngagementAction:FireServer("ClaimDaily")
		end)
	else
		local remaining = math.max(0, Config.DailyCooldown - (serverNow() - profile.LastDailyClaim))
		claim.Text = string.format("%02d:%02d:%02d", math.floor(remaining / 3600), math.floor(remaining % 3600 / 60), remaining % 60)
	end

	local level = arrange(create("Frame", { Size = UDim2.new(1, -8, 0, 82), BackgroundColor3 = C.Card }, content))
	corner(level, 12)
	label(level, "ПРОКАЧКА · УРОВЕНЬ " .. profile.Level, UDim2.fromOffset(400, 26), UDim2.fromOffset(18, 10), 17, C.Cyan, Enum.Font.Code)
	local currentLevelXP = Catalog.XPForLevel(profile.Level)
	local progress = math.clamp((profile.XP - currentLevelXP) / 500, 0, 1)
	label(level, string.format("%d / 500 XP до следующего уровня", math.floor(progress * 500)), UDim2.fromOffset(400, 20), UDim2.fromOffset(18, 47), 12, C.Muted)
	local back = create("Frame", { Size = UDim2.fromOffset(250, 12), Position = UDim2.fromOffset(430, 35), BackgroundColor3 = C.Navy, BorderSizePixel = 0 }, level)
	corner(back, 6)
	local bar = create("Frame", { Size = UDim2.fromScale(progress, 1), BackgroundColor3 = C.Cyan, BorderSizePixel = 0 }, back)
	corner(bar, 6)

	local social = arrange(create("Frame", { Size = UDim2.new(1, -8, 0, 72), BackgroundColor3 = C.Card }, content))
	corner(social, 12)
	label(social, string.format("БОНУС ЗА ДРУЗЕЙ · +%d%% КРЕДИТОВ", math.floor(profile.FriendBonus * 100)), UDim2.fromOffset(500, 26), UDim2.fromOffset(18, 9), 16, C.Green, Enum.Font.Code)
	label(social, "+10% за каждого друга на сервере, максимум +30%. Только валюта для стиля.", UDim2.fromOffset(650, 25), UDim2.fromOffset(18, 39), 12, C.Muted)

	section("ЗАДАНИЯ НА СЕГОДНЯ · НАГРАДА ВЫДАЁТСЯ АВТОМАТИЧЕСКИ")
	for _, quest in ipairs(Catalog.Quests) do
		local row = arrange(create("Frame", { Size = UDim2.new(1, -8, 0, 72), BackgroundColor3 = C.Card }, content))
		corner(row, 10)
		local complete = profile.QuestRewards[quest.Id] == true
		local value = math.min(quest.Target, math.floor((profile.QuestProgress[quest.Id] or 0) * 10) / 10)
		label(row, quest.Name, UDim2.fromOffset(360, 24), UDim2.fromOffset(16, 9), 15, complete and C.Green or C.White, Enum.Font.Code)
		label(row, quest.Description, UDim2.fromOffset(400, 22), UDim2.fromOffset(16, 39), 12, C.Muted)
		label(row, complete and "ВЫПОЛНЕНО" or string.format("%s / %d", tostring(value), quest.Target), UDim2.fromOffset(135, 22), UDim2.fromOffset(430, 12), 13, complete and C.Green or C.Cyan, Enum.Font.Code)
		label(row, "+" .. quest.Reward .. " CR", UDim2.fromOffset(110, 24), UDim2.fromOffset(568, 33), 14, C.Gold, Enum.Font.Code)
	end
end

render = function()
	setTabColors()
	resetContent()
	if currentTab == "Shop" then
		renderShop()
	elseif currentTab == "Garage" then
		renderGarage()
	elseif currentTab == "Tuning" then
		renderTuning()
	elseif currentTab == "Arsenal" then
		renderArsenal()
	else
		renderBonus()
	end
end

local function metaAllowed()
	return raceState:GetAttribute("Phase") == "Intermission"
		or player:GetAttribute("Racing") ~= true
		or player:GetAttribute("Finished") == true
end

local function openPanel(tab)
	if not metaAllowed() then
		return
	end
	currentTab = tab
	overlay.Visible = true
	render()
end

shopButton.Activated:Connect(function()
	openPanel("Shop")
end)
garageButton.Activated:Connect(function()
	openPanel("Garage")
end)
bonusButton.Activated:Connect(function()
	openPanel("Bonus")
end)
arsenalButton.Activated:Connect(function()
	openPanel("Arsenal")
end)
tuningButton.Activated:Connect(function()
	openPanel("Tuning")
end)
tabShop.Activated:Connect(function()
	currentTab = "Shop"
	render()
end)
tabGarage.Activated:Connect(function()
	currentTab = "Garage"
	render()
end)
tabTuning.Activated:Connect(function()
	currentTab = "Tuning"
	render()
end)
tabBonus.Activated:Connect(function()
	currentTab = "Bonus"
	render()
end)
tabArsenal.Activated:Connect(function()
	currentTab = "Arsenal"
	render()
end)
closeButton.Activated:Connect(function()
	overlay.Visible = false
end)
remotes.LobbyAction.OnClientEvent:Connect(function(action, tab)
	if action == "OpenPanel" and type(tab) == "string" then
		openPanel(tab)
	end
end)

local revealOverlay = create("Frame", { Size = UDim2.fromScale(1, 1), BackgroundColor3 = C.Navy, BackgroundTransparency = 0.18, Visible = false, Active = true }, screen)
local revealCard = create("Frame", { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(500, 260), BackgroundColor3 = C.Panel }, revealOverlay)
corner(revealCard, 18)
local revealScale = create("UIScale", {}, revealCard)
local revealStroke = stroke(revealCard, C.Gold, 0.1)
local revealRarity = label(revealCard, "ЛЕГЕНДАРНЫЙ ГАДЖЕТ", UDim2.fromOffset(440, 24), UDim2.fromOffset(30, 24), 13, C.Gold, Enum.Font.Code)
local revealName = label(revealCard, "ГАДЖЕТ", UDim2.fromOffset(440, 58), UDim2.fromOffset(30, 57), 34, C.White, Enum.Font.Code)
local revealDescription = label(revealCard, "", UDim2.fromOffset(440, 56), UDim2.fromOffset(30, 121), 14, C.Muted)
revealDescription.TextWrapped = true
revealDescription.TextYAlignment = Enum.TextYAlignment.Top
local revealClose = button(revealCard, "В АРСЕНАЛ", UDim2.fromOffset(440, 46), UDim2.fromOffset(30, 194), C.Cyan)
revealClose.Activated:Connect(function()
	revealOverlay.Visible = false
end)
revealRarity.TextXAlignment = Enum.TextXAlignment.Center
revealName.TextXAlignment = Enum.TextXAlignment.Center

remotes.CaseOpened.OnClientEvent:Connect(function(result)
	local gadget = Gadgets.Get(result.GadgetId)
	revealRarity.Text = gadget.RarityName .. " ГАДЖЕТ"
	revealRarity.TextColor3 = gadget.Color
	revealName.Text = gadget.Name
	revealName.TextColor3 = gadget.Color
	revealDescription.Text = result.Duplicate and string.format("Дубликат: +%d кредитов. %s", result.Compensation or 0, gadget.Description) or ("Новый гаджет! " .. gadget.Description)
	revealStroke.Color = gadget.Color
	revealOverlay.Visible = true
end)

remotes.ProfileUpdate.OnClientEvent:Connect(function(newProfile)
	profile = newProfile
	serverOffset = (profile.ServerTime or os.time()) - os.time()
	updateProfileCard()
	if overlay.Visible then
		render()
	end
end)

local welcome
local function updateVisibility()
	local allowed = metaAllowed()
	local welcomeVisible = welcome and welcome.Visible or false
	profileCard.Visible = not welcomeVisible
	menu.Visible = allowed and not welcomeVisible
	if not allowed or welcomeVisible then
		overlay.Visible = false
		revealOverlay.Visible = false
	end
end

raceState:GetAttributeChangedSignal("Phase"):Connect(updateVisibility)
player:GetAttributeChangedSignal("Racing"):Connect(updateVisibility)
player:GetAttributeChangedSignal("Finished"):Connect(updateVisibility)
UserInputService.InputBegan:Connect(function(input, processed)
	if revealOverlay.Visible then
		return
	end
	if not processed and input.KeyCode == Enum.KeyCode.M then
		if overlay.Visible then
			overlay.Visible = false
		else
			openPanel("Shop")
		end
	end
end)

local camera = Workspace.CurrentCamera
local function updateScale()
	if camera then
		local viewport = camera.ViewportSize
		modalScale.Scale = math.min(1, (viewport.X - 24) / 760, (viewport.Y - 24) / 570)
		revealScale.Scale = math.min(1, (viewport.X - 24) / 500, (viewport.Y - 24) / 260)
		local compact = viewport.Y < 620
		menuScale.Scale = compact and math.max(0.55, math.min(1, (viewport.Y - 112) / 240)) or 1
		menu.Position = compact and UDim2.fromOffset(22, 98) or UDim2.fromOffset(22, 260)
	end
end
if camera then
	camera:GetPropertyChangedSignal("ViewportSize"):Connect(updateScale)
end
updateScale()

task.spawn(function()
	local coreHud = playerGui:WaitForChild("AeroRushHUD", 10)
	welcome = coreHud and coreHud:FindFirstChild("WelcomeOverlay")
	if welcome then
		welcome:GetPropertyChangedSignal("Visible"):Connect(updateVisibility)
	end
	updateVisibility()
end)

for _, item in ipairs(Catalog.ShopItems) do
	if item.ProductId > 0 then
		task.spawn(function()
			local ok, info = pcall(function()
				return MarketplaceService:GetProductInfo(item.ProductId, item.Kind == "GamePass" and Enum.InfoType.GamePass or Enum.InfoType.Product)
			end)
			if ok and info.PriceInRobux then
				actualPrices[item.Id] = info.PriceInRobux
				if overlay.Visible and currentTab == "Shop" then
					render()
				end
			end
		end)
	end
end

updateProfileCard()
updateVisibility()
remotes.EngagementAction:FireServer("Refresh")
