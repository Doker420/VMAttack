-- AERORUSH client: HUD, камера, ввод и локальные визуальные эффекты.
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local Shared = ReplicatedStorage:WaitForChild("AeroRush")
local Config = require(Shared:WaitForChild("Config"))
local Track = require(Shared:WaitForChild("Track"))
local Gadgets = require(Shared:WaitForChild("Gadgets"))
local remotes = Shared:WaitForChild("Remotes")
local raceState = ReplicatedStorage:WaitForChild("AeroRushState")

local COLORS = {
	Navy = Color3.fromRGB(38, 45, 39),
	Panel = Color3.fromRGB(69, 75, 59),
	Cyan = Color3.fromRGB(105, 158, 181),
	Pink = Color3.fromRGB(174, 83, 58),
	Purple = Color3.fromRGB(96, 134, 72),
	White = Color3.fromRGB(235, 237, 216),
	Muted = Color3.fromRGB(170, 164, 137),
	Yellow = Color3.fromRGB(214, 170, 65),
}

local function create(className, properties, parent)
	local instance = Instance.new(className)
	for property, value in pairs(properties or {}) do
		instance[property] = value
	end
	instance.Parent = parent
	return instance
end

local function corner(parent, radius)
	return create("UICorner", { CornerRadius = UDim.new(0, math.min(radius or 10, 3)) }, parent)
end

local function stroke(parent, color, transparency)
	return create("UIStroke", {
		Color = color or COLORS.Cyan,
		Transparency = transparency or 0.55,
		Thickness = 1,
	}, parent)
end

local function textLabel(parent, name, text, size, position, fontSize, color, font)
	return create("TextLabel", {
		Name = name,
		Size = size,
		Position = position or UDim2.new(),
		BackgroundTransparency = 1,
		Font = font or Enum.Font.Code,
		Text = text,
		TextColor3 = color or COLORS.White,
		TextSize = fontSize or 16,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextYAlignment = Enum.TextYAlignment.Center,
	}, parent)
end

local screen = create("ScreenGui", {
	Name = "AeroRushHUD",
	ResetOnSpawn = false,
	IgnoreGuiInset = true,
	DisplayOrder = 20,
	ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
}, playerGui)

local speedFX = create("Frame", {
	Name = "SpeedLines",
	Size = UDim2.fromScale(1, 1),
	BackgroundTransparency = 1,
	Visible = false,
}, screen)
local speedStreaks = {}
for index = 1, 14 do
	local left = index % 2 == 0
	local x = left and (0.018 + (index % 5) * 0.008) or (0.982 - (index % 5) * 0.008)
	local streak = create("Frame", {
		AnchorPoint = Vector2.new(0.5, 0.5),
		Position = UDim2.fromScale(x, index / 14),
		Size = UDim2.fromOffset(2, 46 + (index * 17) % 78),
		Rotation = left and -12 or 12,
		BackgroundColor3 = index % 3 == 0 and COLORS.Pink or COLORS.Cyan,
		BackgroundTransparency = 0.65,
		BorderSizePixel = 0,
	}, speedFX)
	table.insert(speedStreaks, { Frame = streak, X = x, Offset = index / 14, Rate = 0.72 + (index % 4) * 0.13 })
end

-- Бренд и название трассы.
local brand = create("Frame", {
	Name = "Brand",
	Size = UDim2.fromOffset(258, 66),
	Position = UDim2.fromOffset(22, 20),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.12,
}, screen)
corner(brand, 12)
stroke(brand, COLORS.Cyan, 0.72)
create("Frame", { Size = UDim2.fromOffset(4, 42), Position = UDim2.fromOffset(12, 12), BackgroundColor3 = COLORS.Cyan, BorderSizePixel = 0 }, brand)
textLabel(brand, "Title", Config.GameName, UDim2.fromOffset(220, 33), UDim2.fromOffset(27, 7), 27, COLORS.White, Enum.Font.Code)
textLabel(brand, "Track", Config.TrackName .. "  /  MULTIPLAYER", UDim2.fromOffset(225, 22), UDim2.fromOffset(29, 39), 11, COLORS.Cyan, Enum.Font.Code)

-- Текущая фаза матча.
local phasePill = create("Frame", {
	Name = "Phase",
	AnchorPoint = Vector2.new(0.5, 0),
	Position = UDim2.new(0.5, 0, 0, 20),
	Size = UDim2.fromOffset(310, 58),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.12,
}, screen)
corner(phasePill, 29)
stroke(phasePill, COLORS.Purple, 0.65)
local phaseTitle = textLabel(phasePill, "Title", "ПОДГОТОВКА", UDim2.new(1, -20, 0, 25), UDim2.fromOffset(10, 5), 14, COLORS.White, Enum.Font.Code)
phaseTitle.TextXAlignment = Enum.TextXAlignment.Center
local phaseDetail = textLabel(phasePill, "Detail", "Синхронизация...", UDim2.new(1, -20, 0, 20), UDim2.fromOffset(10, 30), 12, COLORS.Muted)
phaseDetail.TextXAlignment = Enum.TextXAlignment.Center

local lobbyPanel = create("Frame", {
	Name = "LobbyDock",
	AnchorPoint = Vector2.new(0.5, 0),
	Position = UDim2.new(0.5, 0, 0, 136),
	Size = UDim2.fromOffset(326, 154),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.08,
	Visible = false,
}, screen)
corner(lobbyPanel, 4)
stroke(lobbyPanel, COLORS.Cyan, 0.35)
local lobbyTitle = textLabel(lobbyPanel, "Title", "ЛОББИ · ВЫБОР ЗАЕЗДА", UDim2.fromOffset(296, 24), UDim2.fromOffset(14, 7), 13, COLORS.White, Enum.Font.Code)
lobbyTitle.TextXAlignment = Enum.TextXAlignment.Center
local joinRaceButton = create("TextButton", { Size = UDim2.fromOffset(140, 42), Position = UDim2.fromOffset(14, 38), BackgroundColor3 = COLORS.Panel, Text = "В ОЧЕРЕДЬ", Font = Enum.Font.Code, TextSize = 12, TextColor3 = COLORS.White }, lobbyPanel)
corner(joinRaceButton, 3)
local startRaceButton = create("TextButton", { Size = UDim2.fromOffset(140, 42), Position = UDim2.fromOffset(172, 38), BackgroundColor3 = COLORS.Cyan, Text = "СТАРТ · 1 ИГРОК", Font = Enum.Font.Code, TextSize = 12, TextColor3 = COLORS.Navy }, lobbyPanel)
corner(startRaceButton, 3)
local lobbyDetail = textLabel(lobbyPanel, "Detail", "Оставайся, тюнингуй и открывай кейсы", UDim2.fromOffset(296, 48), UDim2.fromOffset(14, 91), 11, COLORS.Muted, Enum.Font.Code)
lobbyDetail.TextXAlignment = Enum.TextXAlignment.Center
lobbyDetail.TextWrapped = true
joinRaceButton.Activated:Connect(function()
	local queued = player:GetAttribute("Queued") == true
	remotes.LobbyAction:FireServer(queued and "LeaveQueue" or "JoinRace")
end)
startRaceButton.Activated:Connect(function()
	remotes.LobbyAction:FireServer("StartRace")
end)

-- Круг, следующий гейт и время.
local raceStats = create("Frame", {
	Name = "RaceStats",
	Size = UDim2.fromOffset(238, 146),
	Position = UDim2.fromOffset(22, 98),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.16,
	Visible = false,
}, screen)
corner(raceStats, 12)
stroke(raceStats, COLORS.Cyan, 0.78)
local lapLabel = textLabel(raceStats, "Lap", "КРУГ 1 / 3", UDim2.fromOffset(205, 29), UDim2.fromOffset(16, 10), 22, COLORS.White, Enum.Font.Code)
local gateLabel = textLabel(raceStats, "Gate", "СЛЕДУЮЩИЙ ГЕЙТ 02 / 12", UDim2.fromOffset(205, 20), UDim2.fromOffset(16, 42), 12, COLORS.Cyan, Enum.Font.Code)
local timerLabel = textLabel(raceStats, "Timer", "00:00.000", UDim2.fromOffset(205, 34), UDim2.fromOffset(16, 67), 26, COLORS.White, Enum.Font.Code)
local bestLabel = textLabel(raceStats, "Best", "ЛУЧШИЙ КРУГ  --:--.---", UDim2.fromOffset(205, 20), UDim2.fromOffset(16, 108), 12, COLORS.Muted)
local distanceLabel = textLabel(raceStats, "Distance", "", UDim2.fromOffset(205, 18), UDim2.fromOffset(16, 126), 11, COLORS.Muted)

local coinPanel = create("Frame", {
	Name = "CoinRush",
	Size = UDim2.fromOffset(238, 70),
	Position = UDim2.fromOffset(22, 252),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.12,
	Visible = false,
}, screen)
corner(coinPanel, 12)
local coinStroke = stroke(coinPanel, COLORS.Yellow, 0.5)
local coinScale = create("UIScale", {}, coinPanel)
local coinCount = textLabel(coinPanel, "Count", "0 / 24 МОНЕТ", UDim2.fromOffset(204, 28), UDim2.fromOffset(16, 7), 19, COLORS.Yellow, Enum.Font.Code)
local comboLabel = textLabel(coinPanel, "Combo", "TECH + BOOST ЗА КАЖДУЮ", UDim2.fromOffset(204, 20), UDim2.fromOffset(16, 36), 11, COLORS.White, Enum.Font.Code)
local comboBack = create("Frame", { Size = UDim2.fromOffset(204, 5), Position = UDim2.fromOffset(16, 59), BackgroundColor3 = Color3.fromRGB(48, 42, 45), BorderSizePixel = 0 }, coinPanel)
corner(comboBack, 2)
local comboBar = create("Frame", { Size = UDim2.fromScale(0, 1), BackgroundColor3 = COLORS.Yellow, BorderSizePixel = 0 }, comboBack)
corner(comboBar, 2)
local coinPulse = 0

local boundaryFX = create("Frame", { Name = "BoundaryWarning", Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1, Visible = false }, screen)
local boundaryStroke = stroke(boundaryFX, COLORS.Pink, 1)
boundaryStroke.Thickness = 10
local boundaryText = textLabel(boundaryFX, "Text", "ГРАНИЦА ТРАССЫ · ВЕРНИСЬ В КОРИДОР", UDim2.fromOffset(560, 42), UDim2.new(0.5, -280, 0, 222), 15, COLORS.Pink, Enum.Font.Code)
boundaryText.TextXAlignment = Enum.TextXAlignment.Center
boundaryText.BackgroundColor3 = COLORS.Navy
boundaryText.BackgroundTransparency = 0.18
corner(boundaryText, 12)

-- Блочный компас обязательного гейта: работает и когда цель находится за спиной.
local navigationPanel = create("Frame", {
	Name = "GateNavigator",
	AnchorPoint = Vector2.new(0.5, 0),
	Position = UDim2.new(0.5, 0, 0, 140),
	Size = UDim2.fromOffset(300, 68),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.08,
	Visible = false,
}, screen)
corner(navigationPanel, 4)
local navigationStroke = stroke(navigationPanel, COLORS.Yellow, 0.25)
local navigationArrow = textLabel(navigationPanel, "Arrow", "▲", UDim2.fromOffset(62, 58), UDim2.fromOffset(10, 5), 46, COLORS.Yellow, Enum.Font.Code)
navigationArrow.TextXAlignment = Enum.TextXAlignment.Center
local navigationTitle = textLabel(navigationPanel, "Title", "ГЕЙТ 02 / 12", UDim2.fromOffset(210, 26), UDim2.fromOffset(78, 8), 17, COLORS.White, Enum.Font.Code)
local navigationDetail = textLabel(navigationPanel, "Detail", "ВПЕРЁД", UDim2.fromOffset(210, 22), UDim2.fromOffset(78, 38), 12, COLORS.Muted, Enum.Font.Code)

-- Общая live-таблица.
local leaderboard = create("Frame", {
	Name = "Leaderboard",
	AnchorPoint = Vector2.new(1, 0),
	Position = UDim2.new(1, -22, 0, 98),
	Size = UDim2.fromOffset(292, 396),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.14,
	Visible = false,
}, screen)
corner(leaderboard, 12)
stroke(leaderboard, COLORS.Purple, 0.75)
textLabel(leaderboard, "Header", "LIVE  /  ПОЗИЦИИ", UDim2.fromOffset(260, 28), UDim2.fromOffset(14, 7), 13, COLORS.Cyan, Enum.Font.Code)
local leaderboardList = create("Frame", { Size = UDim2.fromOffset(266, 348), Position = UDim2.fromOffset(12, 40), BackgroundTransparency = 1 }, leaderboard)
create("UIListLayout", { Padding = UDim.new(0, 4), SortOrder = Enum.SortOrder.LayoutOrder }, leaderboardList)
local leaderboardRows = {}
for index = 1, Config.MaxRacers do
	local row = create("Frame", {
		Size = UDim2.new(1, 0, 0, 25),
		BackgroundColor3 = COLORS.Panel,
		BackgroundTransparency = 0.18,
		Visible = false,
		LayoutOrder = index,
	}, leaderboardList)
	corner(row, 5)
	local place = textLabel(row, "Place", tostring(index), UDim2.fromOffset(28, 25), UDim2.fromOffset(7, 0), 13, COLORS.Muted, Enum.Font.Code)
	local name = textLabel(row, "Pilot", "", UDim2.fromOffset(137, 25), UDim2.fromOffset(37, 0), 12, COLORS.White, Enum.Font.Code)
	name.TextTruncate = Enum.TextTruncate.AtEnd
	local detail = textLabel(row, "Detail", "", UDim2.fromOffset(80, 25), UDim2.fromOffset(180, 0), 10, COLORS.Muted)
	detail.TextXAlignment = Enum.TextXAlignment.Right
	leaderboardRows[index] = { Row = row, Place = place, Name = name, Detail = detail }
end

-- Большой центральный отсчёт.
local countdown = textLabel(screen, "Countdown", "", UDim2.fromOffset(620, 150), UDim2.new(0.5, -310, 0.34, -75), 104, COLORS.White, Enum.Font.Code)
countdown.TextXAlignment = Enum.TextXAlignment.Center
countdown.TextStrokeColor3 = COLORS.Navy
countdown.TextStrokeTransparency = 0.25
countdown.Visible = false
local countdownSub = textLabel(screen, "CountdownSub", "", UDim2.fromOffset(500, 36), UDim2.new(0.5, -250, 0.34, 72), 16, COLORS.Cyan, Enum.Font.Code)
countdownSub.TextXAlignment = Enum.TextXAlignment.Center
countdownSub.Visible = false

-- Скорость и заряд ускорения.
local speedPanel = create("Frame", {
	Name = "Speed",
	AnchorPoint = Vector2.new(0.5, 1),
	Position = UDim2.new(0.5, 0, 1, -24),
	Size = UDim2.fromOffset(264, 116),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.12,
	Visible = false,
}, screen)
corner(speedPanel, 14)
stroke(speedPanel, COLORS.Cyan, 0.7)
local speedValue = textLabel(speedPanel, "Value", "0", UDim2.fromOffset(168, 58), UDim2.fromOffset(16, 4), 48, COLORS.White, Enum.Font.Code)
local speedUnit = textLabel(speedPanel, "Unit", "КМ/Ч", UDim2.fromOffset(58, 24), UDim2.fromOffset(184, 26), 12, COLORS.Cyan, Enum.Font.Code)
local boostCaption = textLabel(speedPanel, "BoostCaption", "BOOST", UDim2.fromOffset(130, 18), UDim2.fromOffset(17, 69), 11, COLORS.Muted, Enum.Font.Code)
local boostNumber = textLabel(speedPanel, "BoostNumber", "100%", UDim2.fromOffset(80, 18), UDim2.fromOffset(166, 69), 11, COLORS.Cyan, Enum.Font.Code)
boostNumber.TextXAlignment = Enum.TextXAlignment.Right
local boostBack = create("Frame", { Size = UDim2.fromOffset(230, 9), Position = UDim2.fromOffset(17, 94), BackgroundColor3 = Color3.fromRGB(34, 47, 68), BorderSizePixel = 0 }, speedPanel)
corner(boostBack, 5)
local boostBar = create("Frame", { Size = UDim2.fromScale(1, 1), BackgroundColor3 = COLORS.Cyan, BorderSizePixel = 0 }, boostBack)
corner(boostBar, 5)

local healthPanel = create("Frame", {
	Name = "DroneHealth",
	AnchorPoint = Vector2.new(0.5, 1),
	Position = UDim2.new(0.5, 0, 1, -150),
	Size = UDim2.fromOffset(264, 50),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.1,
	Visible = false,
}, screen)
corner(healthPanel, 12)
stroke(healthPanel, Color3.fromRGB(54, 64, 103), 0.3)
textLabel(healthPanel, "Caption", "ПРОЧНОСТЬ ДРОНА", UDim2.new(1, -20, 0, 18), UDim2.fromOffset(10, 4), 11, COLORS.White, Enum.Font.Code)
local healthBack = create("Frame", {
	Position = UDim2.fromOffset(12, 25),
	Size = UDim2.new(1, -24, 0, 12),
	BackgroundColor3 = Color3.fromRGB(35, 39, 60),
	BorderSizePixel = 0,
}, healthPanel)
corner(healthBack, 6)
local healthBar = create("Frame", { Size = UDim2.fromScale(1, 1), BackgroundColor3 = COLORS.Cyan, BorderSizePixel = 0 }, healthBack)
corner(healthBar, 6)
local healthText = textLabel(healthBack, "Value", "100", UDim2.fromScale(1, 1), UDim2.new(), 11, COLORS.White, Enum.Font.Code)
healthText.TextXAlignment = Enum.TextXAlignment.Center
local shieldLabel = textLabel(healthPanel, "Shield", "", UDim2.fromOffset(100, 18), UDim2.new(1, -110, 0, 4), 11, COLORS.Cyan, Enum.Font.Code)
shieldLabel.TextXAlignment = Enum.TextXAlignment.Right

local gadgetPanel = create("Frame", {
	Name = "GadgetControls",
	AnchorPoint = Vector2.new(0.5, 1),
	Position = UDim2.new(0.5, 154, 1, -24),
	Size = UDim2.fromOffset(170, 168),
	BackgroundTransparency = 1,
	Visible = false,
}, screen)
local blasterButton = create("TextButton", {
	Name = "PulseBlaster",
	Size = UDim2.new(1, 0, 0, 52),
	BackgroundColor3 = COLORS.Panel,
	Font = Enum.Font.Code,
	Text = "ЛКМ · BLASTER",
	TextColor3 = COLORS.White,
	TextSize = 13,
	AutoButtonColor = true,
}, gadgetPanel)
corner(blasterButton, 12)
stroke(blasterButton, COLORS.White, 0.25)
local attackButton = create("TextButton", {
	Name = "AttackGadget",
	Position = UDim2.fromOffset(0, 60),
	Size = UDim2.new(1, 0, 0, 52),
	BackgroundColor3 = COLORS.Panel,
	Font = Enum.Font.Code,
	Text = "F · ИМПУЛЬС",
	TextColor3 = COLORS.Cyan,
	TextSize = 13,
	AutoButtonColor = true,
}, gadgetPanel)
corner(attackButton, 12)
stroke(attackButton, COLORS.Cyan, 0.25)
local defenseButton = create("TextButton", {
	Name = "DefenseGadget",
	Position = UDim2.fromOffset(0, 120),
	Size = UDim2.new(1, 0, 0, 52),
	BackgroundColor3 = COLORS.Panel,
	Font = Enum.Font.Code,
	Text = "G · РЕМОНТ",
	TextColor3 = COLORS.Cyan,
	TextSize = 13,
	AutoButtonColor = true,
}, gadgetPanel)
corner(defenseButton, 12)
stroke(defenseButton, COLORS.Cyan, 0.25)
if UserInputService.TouchEnabled then
	gadgetPanel.Position = UDim2.new(0.5, 0, 1, -212)
end

local controlsHint = create("Frame", {
	Size = UDim2.fromOffset(390, 62),
	Position = UDim2.new(0, 22, 1, -82),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.28,
}, screen)
corner(controlsHint, 10)
local controlsLine1 = textLabel(controlsHint, "Line1", "WASD / Q E / SPACE CTRL — полёт · ЛКМ — BLASTER", UDim2.fromOffset(370, 22), UDim2.fromOffset(12, 8), 11, COLORS.White, Enum.Font.Code)
local controlsLine2 = textLabel(controlsHint, "Line2", "SHIFT — boost · F/G — гаджеты · R — reset", UDim2.fromOffset(370, 20), UDim2.fromOffset(12, 33), 10, COLORS.Muted)

blasterButton.Activated:Connect(function()
	remotes.CombatAction:FireServer("FireBlaster")
end)
attackButton.Activated:Connect(function()
	remotes.CombatAction:FireServer("UseAttack")
end)
defenseButton.Activated:Connect(function()
	remotes.CombatAction:FireServer("UseDefense")
end)

-- Два оригинальных локальных саундтрека: у каждого игрока свой звук и свой mute.
local musicButton = create("TextButton", {
	Name = "MusicToggle",
	AnchorPoint = Vector2.new(0.5, 0),
	Position = UDim2.new(0.5, 0, 0, 86),
	Size = UDim2.fromOffset(202, 38),
	BackgroundColor3 = COLORS.Navy,
	BackgroundTransparency = 0.16,
	Text = "",
	Font = Enum.Font.Code,
	TextSize = 12,
	TextColor3 = COLORS.Cyan,
	AutoButtonColor = true,
}, screen)
corner(musicButton, 19)
stroke(musicButton, COLORS.Cyan, 0.6)

local function audioId(value)
	local text = tostring(value or "")
	if text:match("^[1-9]%d*$") then
		return "rbxassetid://" .. text
	elseif text:match("^rbxassetid://[1-9]%d*$") then
		return text
	end
	return ""
end

local function makeMusic(name, id, volume)
	return create("Sound", {
		Name = name,
		SoundId = audioId(id),
		Volume = 0,
		Looped = true,
		PlaybackSpeed = 1,
		Archivable = false,
	}, SoundService), volume
end

local lobbyMusic, lobbyMusicVolume = makeMusic("AeroRushLobbyMusic", Config.Music.LobbySoundId, Config.Music.LobbyVolume)
local raceMusic, raceMusicVolume = makeMusic("AeroRushRaceMusic", Config.Music.RaceSoundId, Config.Music.RaceVolume)
local musicTracks = {
	{ Sound = lobbyMusic, Volume = lobbyMusicVolume, Race = false },
	{ Sound = raceMusic, Volume = raceMusicVolume, Race = true },
}
local musicEnabled = Config.Music.DefaultEnabled ~= false

local function refreshMusicButton()
	local prefix = UserInputService.TouchEnabled and "♪" or "N  ·  ♪"
	musicButton.Text = prefix .. (musicEnabled and "  МУЗЫКА: ВКЛ" or "  МУЗЫКА: ВЫКЛ")
	musicButton.TextColor3 = musicEnabled and COLORS.Cyan or COLORS.Muted
end

local function toggleMusic()
	musicEnabled = not musicEnabled
	refreshMusicButton()
end
musicButton.Activated:Connect(toggleMusic)
refreshMusicButton()

local function updateMusic(deltaTime)
	local phase = raceState:GetAttribute("Phase")
	local raceMode = (phase == "Countdown" or phase == "Racing")
		and player:GetAttribute("Racing") == true
		and player:GetAttribute("Finished") ~= true
	local blend = math.min(1, deltaTime * 3.2)
	for _, track in ipairs(musicTracks) do
		local sound = track.Sound
		local target = (musicEnabled and track.Race == raceMode) and track.Volume or 0
		if sound.SoundId ~= "" and target > 0 and not sound.IsPlaying then
			sound:Play()
		end
		sound.Volume = sound.Volume + (target - sound.Volume) * blend
		if target == 0 and sound.Volume < 0.003 then
			sound.Volume = 0
			if sound.IsPlaying then
				sound:Stop()
			end
		end
	end
end

local resetButton = create("TextButton", {
	Name = "Reset",
	AnchorPoint = Vector2.new(1, 1),
	Position = UDim2.new(1, -22, 1, -26),
	Size = UDim2.fromOffset(128, 44),
	BackgroundColor3 = COLORS.Panel,
	BackgroundTransparency = 0.08,
	Text = "R  /  RESET",
	Font = Enum.Font.Code,
	TextSize = 13,
	TextColor3 = COLORS.White,
	AutoButtonColor = true,
	Visible = false,
}, screen)
corner(resetButton, 10)
stroke(resetButton, COLORS.Pink, 0.55)
resetButton.Activated:Connect(function()
	remotes.Reset:FireServer()
end)
UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed then
		return
	end
	if input.UserInputType == Enum.UserInputType.MouseButton1 or input.KeyCode == Enum.KeyCode.V or input.KeyCode == Enum.KeyCode.ButtonR2 then
		remotes.CombatAction:FireServer("FireBlaster")
	elseif input.KeyCode == Enum.KeyCode.R or input.KeyCode == Enum.KeyCode.ButtonY then
		remotes.Reset:FireServer()
	elseif input.KeyCode == Enum.KeyCode.N or input.KeyCode == Enum.KeyCode.ButtonL3 then
		toggleMusic()
	elseif input.KeyCode == Enum.KeyCode.F or input.KeyCode == Enum.KeyCode.ButtonR1 then
		remotes.CombatAction:FireServer("UseAttack")
	elseif input.KeyCode == Enum.KeyCode.G or input.KeyCode == Enum.KeyCode.ButtonL1 then
		remotes.CombatAction:FireServer("UseDefense")
	end
end)

local hitMarker = textLabel(screen, "HitMarker", "◆", UDim2.fromOffset(70, 70), UDim2.new(0.5, -35, 0.5, -35), 38, COLORS.Cyan, Enum.Font.Code)
hitMarker.TextXAlignment = Enum.TextXAlignment.Center
hitMarker.TextStrokeColor3 = COLORS.Navy
hitMarker.TextStrokeTransparency = 0.2
hitMarker.Visible = false
local hitMarkerSerial = 0

local notification = textLabel(screen, "Notification", "", UDim2.fromOffset(600, 44), UDim2.new(0.5, -300, 0, 92), 16, COLORS.White, Enum.Font.Code)
notification.TextXAlignment = Enum.TextXAlignment.Center
notification.BackgroundTransparency = 0.16
notification.BackgroundColor3 = COLORS.Navy
notification.Visible = false
corner(notification, 12)
notification.TextWrapped = true
local notificationQueue = {}
local notificationWorking = false
local function showNotification(text, kind)
	if #notificationQueue >= 8 then
		table.remove(notificationQueue, 1)
	end
	table.insert(notificationQueue, { Text = text, Kind = kind })
	if notificationWorking then
		return
	end
	notificationWorking = true
	task.spawn(function()
		while #notificationQueue > 0 do
			local item = table.remove(notificationQueue, 1)
			notification.Text = item.Text
			notification.TextColor3 = item.Kind == "success" and COLORS.Cyan or (item.Kind == "warning" and COLORS.Yellow or COLORS.White)
			notification.Visible = true
			task.wait(item.Kind == "checkpoint" and 1 or 3.2)
		end
		notification.Visible = false
		notificationWorking = false
	end)
end

-- Таблица результатов.
local resultsOverlay = create("Frame", { Name = "ResultsOverlay", Size = UDim2.fromScale(1, 1), BackgroundColor3 = COLORS.Navy, BackgroundTransparency = 0.35, Visible = false, Active = true }, screen)
local resultsModal = create("Frame", { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(570, 492), BackgroundColor3 = COLORS.Panel, BackgroundTransparency = 0.03 }, resultsOverlay)
corner(resultsModal, 18)
stroke(resultsModal, COLORS.Cyan, 0.35)
local resultsTitle = textLabel(resultsModal, "Title", "РЕЗУЛЬТАТЫ", UDim2.fromOffset(510, 48), UDim2.fromOffset(28, 20), 32, COLORS.White, Enum.Font.Code)
local resultsSubtitle = textLabel(resultsModal, "Subtitle", Config.TrackName, UDim2.fromOffset(510, 24), UDim2.fromOffset(30, 68), 13, COLORS.Cyan, Enum.Font.Code)
local resultHeaders = textLabel(resultsModal, "Headers", "МЕСТО        ПИЛОТ                              ВРЕМЯ          KO / ЛУЧШИЙ КРУГ", UDim2.fromOffset(510, 24), UDim2.fromOffset(30, 108), 11, COLORS.Muted, Enum.Font.Code)
resultHeaders.TextXAlignment = Enum.TextXAlignment.Left
local resultsList = create("ScrollingFrame", {
	Position = UDim2.fromOffset(28, 140),
	Size = UDim2.fromOffset(514, 270),
	BackgroundTransparency = 1,
	BorderSizePixel = 0,
	CanvasSize = UDim2.new(),
	AutomaticCanvasSize = Enum.AutomaticSize.Y,
	ScrollBarThickness = 4,
	ScrollBarImageColor3 = COLORS.Cyan,
}, resultsModal)
create("UIListLayout", { Padding = UDim.new(0, 5), SortOrder = Enum.SortOrder.LayoutOrder }, resultsList)
local resultRows = {}
for index = 1, Config.MaxRacers do
	local row = create("Frame", { Size = UDim2.new(1, -8, 0, 38), BackgroundColor3 = COLORS.Navy, BackgroundTransparency = 0.12, LayoutOrder = index, Visible = false }, resultsList)
	corner(row, 7)
	local place = textLabel(row, "Place", "", UDim2.fromOffset(60, 38), UDim2.fromOffset(12, 0), 15, COLORS.Cyan, Enum.Font.Code)
	local name = textLabel(row, "Name", "", UDim2.fromOffset(175, 38), UDim2.fromOffset(72, 0), 14, COLORS.White, Enum.Font.Code)
	name.TextTruncate = Enum.TextTruncate.AtEnd
	local time = textLabel(row, "Time", "", UDim2.fromOffset(120, 38), UDim2.fromOffset(252, 0), 12, COLORS.White, Enum.Font.Code)
	local best = textLabel(row, "Best", "", UDim2.fromOffset(120, 38), UDim2.fromOffset(382, 0), 11, COLORS.Muted)
	resultRows[index] = { Row = row, Place = place, Name = name, Time = time, Best = best }
end
local closeResults = create("TextButton", { AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 430), Size = UDim2.fromOffset(220, 42), BackgroundColor3 = COLORS.Cyan, Text = "ГОТОВ К РЕВАНШУ", Font = Enum.Font.Code, TextSize = 14, TextColor3 = COLORS.Navy }, resultsModal)
corner(closeResults, 10)
closeResults.Activated:Connect(function()
	resultsOverlay.Visible = false
end)

local ownResultSummary = ""
local function showResults(results)
	local ownPlace = 0
	ownResultSummary = ""
	for index, entry in ipairs(results) do
		local row = resultRows[index]
		if row then
			row.Row.Visible = true
			row.Place.Text = entry.Finished and ("#" .. entry.Place) or "DNF"
			row.Name.Text = entry.Name
			row.Time.Text = entry.Finished and Config.FormatTime(entry.FinishTime) or "—"
			row.Best.Text = string.format("%d KO · %s", entry.Eliminations or 0, Config.FormatTime(entry.BestLap))
			row.Name.TextColor3 = entry.UserId == player.UserId and COLORS.Cyan or (entry.AeroClub and COLORS.Yellow or COLORS.White)
			if entry.UserId == player.UserId then
				ownPlace = entry.Finished and entry.Place or 0
				if entry.Rated then
					local sign = entry.RatingDelta > 0 and "+" or ""
					ownResultSummary = string.format("РЕЙТИНГ %d (%s%d) · ВЫВЕДЕНО %d", entry.Rating, sign, entry.RatingDelta, entry.Eliminations or 0)
				else
					ownResultSummary = string.format("РЕЙТИНГ %d · БЕЗ ELO · ВЫВЕДЕНО %d", entry.Rating or 1000, entry.Eliminations or 0)
				end
			end
		end
	end
	for index = #results + 1, Config.MaxRacers do
		resultRows[index].Row.Visible = false
	end
	resultsTitle.Text = ownPlace == 1 and "ПОБЕДА!" or "РЕЗУЛЬТАТЫ"
	resultsTitle.TextColor3 = ownPlace == 1 and COLORS.Cyan or COLORS.White
	resultsSubtitle.Text = ownResultSummary ~= "" and ownResultSummary or Config.TrackName
	resultsOverlay.Visible = true
end

-- Короткое обучение при первом входе.
local helpOverlay = create("Frame", { Name = "WelcomeOverlay", Size = UDim2.fromScale(1, 1), BackgroundColor3 = COLORS.Navy, BackgroundTransparency = 0.25, Visible = true, Active = true }, screen)
local helpModal = create("Frame", { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(600, 430), BackgroundColor3 = COLORS.Panel, BackgroundTransparency = 0.02 }, helpOverlay)
corner(helpModal, 18)
stroke(helpModal, COLORS.Cyan, 0.35)
textLabel(helpModal, "Eyebrow", "ДОБРО ПОЖАЛОВАТЬ В BLOCKHAVEN", UDim2.fromOffset(540, 24), UDim2.fromOffset(30, 26), 12, COLORS.Cyan, Enum.Font.Code)
textLabel(helpModal, "Title", "ГОНКИ НА ДРОНАХ", UDim2.fromOffset(540, 52), UDim2.fromOffset(28, 56), 34, COLORS.White, Enum.Font.Code)
local helpBody = UserInputService.TouchEnabled
	and "Левый стик — движение и поворот по трассе.\nКнопки справа — высота и ускорение.\nBLASTER — базовый огонь, ниже — два гаджета.\nПроходи гейты по порядку. Монеты дают TECH и boost.\nЭнергетический коридор не даст улететь с трассы."
	or "WASD — движение   Q / E — поворот   SPACE / CTRL — высота\nSHIFT — ускорение   R — вернуться к последнему гейту\nЛКМ / V / R2 — blaster   F / G / R1 / L1 — гаджеты\nПроходи гейты по порядку. Монеты дают TECH и boost.\nЭнергетический коридор не даст улететь с трассы."
local helpText = textLabel(helpModal, "Body", helpBody, UDim2.fromOffset(530, 145), UDim2.fromOffset(30, 128), 17, COLORS.White, Enum.Font.Code)
helpText.TextWrapped = true
helpText.TextYAlignment = Enum.TextYAlignment.Top
local tip = textLabel(helpModal, "Tip", "Сервер управляет физикой и гейтами — все пилоты соревнуются в одном живом заезде.", UDim2.fromOffset(530, 54), UDim2.fromOffset(30, 286), 13, COLORS.Muted)
tip.TextWrapped = true
local flyButton = create("TextButton", { Position = UDim2.fromOffset(30, 358), Size = UDim2.fromOffset(540, 46), BackgroundColor3 = COLORS.Cyan, Text = "ГОТОВ К СТАРТУ", Font = Enum.Font.Code, TextSize = 15, TextColor3 = COLORS.Navy }, helpModal)
corner(flyButton, 10)
flyButton.Activated:Connect(function()
	helpOverlay.Visible = false
end)

-- Сенсорное управление: левый стик и три кнопки справа.
local touchMove = Vector2.zero
local touchFlags = { Up = false, Down = false, Boost = false }
local touchControls = create("Frame", { Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1, Visible = UserInputService.TouchEnabled }, screen)
local joystick = create("Frame", { AnchorPoint = Vector2.new(0, 1), Position = UDim2.new(0, 24, 1, -104), Size = UDim2.fromOffset(142, 142), BackgroundColor3 = COLORS.Navy, BackgroundTransparency = 0.35, Active = true }, touchControls)
corner(joystick, 71)
stroke(joystick, COLORS.Cyan, 0.55)
local knob = create("Frame", { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(58, 58), BackgroundColor3 = COLORS.Cyan, BackgroundTransparency = 0.18 }, joystick)
corner(knob, 29)
local joystickInput

local function updateJoystick(input)
	local center = Vector2.new(joystick.AbsolutePosition.X + joystick.AbsoluteSize.X / 2, joystick.AbsolutePosition.Y + joystick.AbsoluteSize.Y / 2)
	local position = Vector2.new(input.Position.X, input.Position.Y)
	local delta = position - center
	local radius = math.max(30, joystick.AbsoluteSize.X * 0.34)
	if delta.Magnitude > radius then
		delta = delta.Unit * radius
	end
	touchMove = Vector2.new(delta.X / radius, -delta.Y / radius)
	knob.Position = UDim2.new(0.5, delta.X, 0.5, delta.Y)
end

joystick.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
		joystickInput = input
		updateJoystick(input)
	end
end)
UserInputService.InputChanged:Connect(function(input)
	if input == joystickInput then
		updateJoystick(input)
	end
end)
UserInputService.InputEnded:Connect(function(input)
	if input == joystickInput then
		joystickInput = nil
		touchMove = Vector2.zero
		knob.Position = UDim2.fromScale(0.5, 0.5)
	end
end)

local function actionButton(text, position, color, action)
	local button = create("TextButton", { AnchorPoint = Vector2.new(1, 1), Position = position, Size = UDim2.fromOffset(82, 68), BackgroundColor3 = COLORS.Navy, BackgroundTransparency = 0.22, Text = text, Font = Enum.Font.Code, TextSize = 14, TextColor3 = color, AutoButtonColor = false, Active = true }, touchControls)
	corner(button, 16)
	stroke(button, color, 0.4)
	button.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.Touch or input.UserInputType == Enum.UserInputType.MouseButton1 then
			touchFlags[action] = true
			button.BackgroundTransparency = 0
		end
	end)
	button.InputEnded:Connect(function()
		touchFlags[action] = false
		button.BackgroundTransparency = 0.22
	end)
	return button
end

actionButton("ВВЕРХ", UDim2.new(1, -24, 1, -232), COLORS.Cyan, "Up")
actionButton("ВНИЗ", UDim2.new(1, -24, 1, -104), COLORS.White, "Down")
actionButton("BOOST", UDim2.new(1, -118, 1, -168), COLORS.Pink, "Boost")

if UserInputService.TouchEnabled then
	controlsHint.Visible = false
	resetButton.Position = UDim2.new(1, -218, 1, -30)
end

-- Подсветка только следующего обязательного гейта.
local targetHighlight = create("Highlight", { FillColor = COLORS.Yellow, FillTransparency = 0.9, OutlineColor = COLORS.Yellow, OutlineTransparency = 0, DepthMode = Enum.HighlightDepthMode.AlwaysOnTop, Enabled = false }, Workspace)
local highlightedGate
local highlightedField
local function setTargetTag(gate, enabled)
	local anchor = gate and gate:FindFirstChild("NumberAnchor")
	local tag = anchor and anchor:FindFirstChild("TargetTag")
	if tag then
		tag.Enabled = enabled
	end
end

local function updateTargetHighlight()
	local gateIndex = player:GetAttribute("Gate") or 0
	local world = Workspace:FindFirstChild("AeroRushWorld")
	local gates = world and world:FindFirstChild("Gates")
	local gate = gates and gates:FindFirstChild(string.format("Gate_%02d", gateIndex))
	if gate ~= highlightedGate then
		setTargetTag(highlightedGate, false)
		if highlightedField then
			highlightedField.Transparency = 0.97
		end
		highlightedGate = gate
		highlightedField = gate and gate:FindFirstChild("EnergyField")
		targetHighlight.Adornee = gate
	end
	targetHighlight.Enabled = gate ~= nil and player:GetAttribute("Racing") == true and not player:GetAttribute("Finished")
	setTargetTag(gate, targetHighlight.Enabled)
	if highlightedField then
		highlightedField.Transparency = targetHighlight.Enabled and (0.9 + math.sin(os.clock() * 4) * 0.03) or 0.97
	end
end

local function getOwnDrone()
	local world = Workspace:FindFirstChild("AeroRushWorld")
	local drones = world and world:FindFirstChild("Drones")
	local model = drones and drones:FindFirstChild("Drone_" .. player.UserId)
	if model and model.PrimaryPart then
		return model
	end
	return nil
end

local function updateLeaderboard(entries)
	leaderboard.Visible = #entries > 0
	for index, row in ipairs(leaderboardRows) do
		local entry = entries[index]
		row.Row.Visible = entry ~= nil
		if entry then
			row.Place.Text = "#" .. entry.Place
			row.Place.TextColor3 = entry.Place == 1 and COLORS.Yellow or COLORS.Muted
			row.Name.Text = entry.Name
			row.Name.TextColor3 = entry.UserId == player.UserId and COLORS.Cyan or (entry.AeroClub and COLORS.Yellow or COLORS.White)
			row.Detail.Text = entry.Finished and Config.FormatTime(entry.FinishTime) or string.format("%d/%d · %d KO", entry.Lap, entry.Gate, entry.Eliminations or 0)
		end
	end
end

remotes.Leaderboard.OnClientEvent:Connect(updateLeaderboard)
remotes.Notify.OnClientEvent:Connect(showNotification)
remotes.Results.OnClientEvent:Connect(showResults)
remotes.Celebration.OnClientEvent:Connect(function(userId, displayName)
	showNotification("ПОБЕДИТЕЛЬ: " .. tostring(displayName), "success")
	local world = Workspace:FindFirstChild("AeroRushWorld")
	local drones = world and world:FindFirstChild("Drones")
	local drone = drones and drones:FindFirstChild("Drone_" .. tostring(userId))
	local root = drone and drone.PrimaryPart
	if not root then
		return
	end
	local attachment = Instance.new("Attachment")
	attachment.Parent = root
	local particles = Instance.new("ParticleEmitter")
	particles.Name = "WinnerConfetti"
	particles.Rate = 0
	particles.Lifetime = NumberRange.new(1.5, 3.5)
	particles.Speed = NumberRange.new(9, 18)
	particles.SpreadAngle = Vector2.new(180, 180)
	particles.Rotation = NumberRange.new(0, 360)
	particles.RotSpeed = NumberRange.new(-220, 220)
	particles.Size = NumberSequence.new(0.32)
	particles.Color = ColorSequence.new(COLORS.Cyan, COLORS.Pink)
	particles.LightEmission = 0.45
	particles.Parent = attachment
	particles:Emit(110)
	task.delay(6, function()
		attachment:Destroy()
	end)
end)
local function temporaryPart(shape, size, cframe, color, transparency, lifetime)
	local part = Instance.new("Part")
	part.Shape = shape
	part.Size = size
	part.CFrame = cframe
	part.Color = color
	part.Material = Enum.Material.Neon
	part.Transparency = transparency
	part.Anchored = true
	part.CanCollide = false
	part.CanQuery = false
	part.CanTouch = false
	part.CastShadow = false
	part.Parent = Workspace
	task.delay(lifetime, function()
		part:Destroy()
	end)
	return part
end

local function burstAt(position, color, count)
	local anchor = temporaryPart(Enum.PartType.Block, Vector3.one, CFrame.new(position), color, 1, 1.2)
	local attachment = create("Attachment", {}, anchor)
	local particles = create("ParticleEmitter", {
		Rate = 0,
		Lifetime = NumberRange.new(0.45, 1.0),
		Speed = NumberRange.new(5, 13),
		SpreadAngle = Vector2.new(180, 180),
		Rotation = NumberRange.new(0, 360),
		RotSpeed = NumberRange.new(-240, 240),
		Size = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0.34),
			NumberSequenceKeypoint.new(1, 0),
		}),
		Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0.08),
			NumberSequenceKeypoint.new(1, 1),
		}),
		Color = ColorSequence.new(color, COLORS.White),
		LightEmission = 0.9,
	}, attachment)
	particles:Emit(count or 24)
	local ring = temporaryPart(Enum.PartType.Ball, Vector3.one * 1.2, CFrame.new(position), color, 0.35, 0.5)
	task.spawn(function()
		local started = os.clock()
		while ring.Parent and os.clock() - started < 0.45 do
			local progress = (os.clock() - started) / 0.45
			ring.Size = Vector3.one * (1.2 + progress * 8.8)
			ring.Transparency = 0.35 + progress * 0.65
			RunService.RenderStepped:Wait()
		end
	end)
end

remotes.CoinFX.OnClientEvent:Connect(function(effect)
	if type(effect) ~= "table" or not effect.Position then
		return
	end
	burstAt(effect.Position, COLORS.Yellow, 26)
	if effect.UserId == player.UserId then
		coinPulse = 1
	end
end)

remotes.CombatFX.OnClientEvent:Connect(function(effect)
	if type(effect) ~= "table" then
		return
	end
	local color = effect.Color or COLORS.Cyan
	if effect.Kind == "Beam" then
		local direction = effect.Destination - effect.Origin
		local length = direction.Magnitude
		if length > 0 and length < 200 then
			local width = effect.Width or 0.35
			temporaryPart(Enum.PartType.Block, Vector3.new(width, width, length), CFrame.lookAt((effect.Origin + effect.Destination) * 0.5, effect.Destination), color, 0.12, 0.16)
		end
	elseif effect.Kind == "Elimination" then
		if effect.Position then
			burstAt(effect.Position, COLORS.Pink, 48)
		end
	elseif effect.Kind == "HitMarker" then
		hitMarkerSerial = hitMarkerSerial + 1
		local serial = hitMarkerSerial
		hitMarker.Visible = true
		task.delay(0.16, function()
			if hitMarkerSerial == serial then
				hitMarker.Visible = false
			end
		end)
	elseif effect.Kind == "Burst" then
		local radius = math.clamp(effect.Radius or 4, 1, 28)
		temporaryPart(Enum.PartType.Ball, Vector3.one * radius * 2, CFrame.new(effect.Position), color, 0.72, 0.24)
	elseif effect.Kind == "Repair" then
		local world = Workspace:FindFirstChild("AeroRushWorld")
		local drones = world and world:FindFirstChild("Drones")
		local drone = drones and drones:FindFirstChild("Drone_" .. tostring(effect.UserId))
		if drone and drone.PrimaryPart then
			local light = Instance.new("PointLight")
			light.Color = color
			light.Brightness = 3
			light.Range = 16
			light.Parent = drone.PrimaryPart
			task.delay(1, function()
				light:Destroy()
			end)
		end
	end
end)

remotes.Checkpoint.OnClientEvent:Connect(function(passed, nextGate, lap)
	local world = Workspace:FindFirstChild("AeroRushWorld")
	local gates = world and world:FindFirstChild("Gates")
	local gate = gates and gates:FindFirstChild(string.format("Gate_%02d", passed))
	local root = gate and gate.PrimaryPart
	if root then
		burstAt(root.Position, passed == 1 and COLORS.Pink or COLORS.Cyan, 30)
	end
	if passed == 1 then
		showNotification(string.format("КРУГ %d / %d", math.min(lap, Config.Laps), Config.Laps), "success")
	else
		showNotification(string.format("ГЕЙТ %02d  →  %02d", passed, nextGate), "checkpoint")
	end
end)

raceState:GetAttributeChangedSignal("Phase"):Connect(function()
	if raceState:GetAttribute("Phase") == "Intermission" then
		resultsOverlay.Visible = false
		updateLeaderboard({})
	end
end)

local function keyDown(...)
	for _, key in ipairs({ ... }) do
		if UserInputService:IsKeyDown(key) then
			return true
		end
	end
	return false
end

local function gamepadStick(keyCode)
	for _, input in ipairs(UserInputService:GetGamepadState(Enum.UserInputType.Gamepad1)) do
		if input.KeyCode == keyCode then
			return input.Position
		end
	end
	return Vector3.zero
end

local inputClock = 0
local function sendInput(deltaTime)
	inputClock = inputClock + deltaTime
	if inputClock < 1 / 30 then
		return
	end
	inputClock = 0
	if raceState:GetAttribute("Phase") ~= "Racing" or not player:GetAttribute("Racing") or player:GetAttribute("Finished") then
		return
	end
	if helpOverlay.Visible or resultsOverlay.Visible or UserInputService:GetFocusedTextBox() then
		return
	end

	local leftStick = gamepadStick(Enum.KeyCode.Thumbstick1)
	local rightStick = gamepadStick(Enum.KeyCode.Thumbstick2)
	local x = (keyDown(Enum.KeyCode.D, Enum.KeyCode.Right) and 1 or 0) - (keyDown(Enum.KeyCode.A, Enum.KeyCode.Left) and 1 or 0)
	local y = (keyDown(Enum.KeyCode.W, Enum.KeyCode.Up) and 1 or 0) - (keyDown(Enum.KeyCode.S, Enum.KeyCode.Down) and 1 or 0)
	x = math.clamp(x + leftStick.X, -1, 1)
	y = math.clamp(y + touchMove.Y + leftStick.Y, -1, 1)
	local yaw = (keyDown(Enum.KeyCode.E) and 1 or 0) - (keyDown(Enum.KeyCode.Q) and 1 or 0)
	-- На сенсорном экране горизонталь стика работает как руль, поэтому трасса проходится без отдельных кнопок Q/E.
	yaw = math.clamp(yaw + rightStick.X + touchMove.X, -1, 1)
	remotes.Input:FireServer({
		X = x,
		Y = y,
		Yaw = yaw,
		Up = keyDown(Enum.KeyCode.Space, Enum.KeyCode.ButtonA) or touchFlags.Up,
		Down = keyDown(Enum.KeyCode.LeftControl, Enum.KeyCode.ButtonB) or touchFlags.Down,
		Boost = keyDown(Enum.KeyCode.LeftShift, Enum.KeyCode.ButtonX) or touchFlags.Boost,
	})
end

local cameraFollowing = false
local function updateCamera(deltaTime, ownDrone)
	local camera = Workspace.CurrentCamera
	if not camera then
		return
	end
	if ownDrone and player:GetAttribute("Racing") and raceState:GetAttribute("Phase") ~= "Intermission" then
		local root = ownDrone.PrimaryPart
		camera.CameraType = Enum.CameraType.Scriptable
		local speed = ownDrone:GetAttribute("Speed") or 0
		local desiredPosition = root.Position + root.CFrame:VectorToWorldSpace(Vector3.new(0, 6.5, 18))
		local lookAt = root.Position + root.CFrame.LookVector * 18 + Vector3.new(0, 1.5, 0)
		local target = CFrame.lookAt(desiredPosition, lookAt)
		if cameraFollowing then
			camera.CFrame = camera.CFrame:Lerp(target, 1 - math.exp(-deltaTime * 10))
		else
			camera.CFrame = target
		end
		camera.FieldOfView = camera.FieldOfView + ((70 + math.min(16, speed * 0.11)) - camera.FieldOfView) * (1 - math.exp(-deltaTime * 5))
		cameraFollowing = true
	elseif cameraFollowing then
		cameraFollowing = false
		camera.FieldOfView = 70
		camera.CameraType = Enum.CameraType.Custom
		local character = player.Character
		local humanoid = character and character:FindFirstChildOfClass("Humanoid")
		if humanoid then
			camera.CameraSubject = humanoid
		end
	end
end

local coinAnimations = {}
local droneAppearances = {}
local function animateWorldModels()
	local clock = os.clock()
	local liveCoins = {}
	for _, model in ipairs(CollectionService:GetTagged("AeroRushCoin")) do
		local root = model.PrimaryPart
		if model.Parent and root then
			liveCoins[model] = true
			local version = model:GetAttribute("SpawnVersion") or 0
			local animation = coinAnimations[model]
			if not animation or animation.Version ~= version then
				local base = root.CFrame
				local position = model:GetAttribute("BasePosition")
				local look = model:GetAttribute("BaseLook")
				local up = model:GetAttribute("BaseUp")
				if position and look then
					base = up and CFrame.lookAt(position, position + look, up) or CFrame.lookAt(position, position + look)
				end
				animation = { Version = version, Base = base, Started = clock }
				coinAnimations[model] = animation
			end
			local phase = model:GetAttribute("Phase") or 0
			local bob = math.sin(clock * 2.5 + phase) * 0.45
			model:PivotTo(animation.Base * CFrame.new(0, bob, 0) * CFrame.Angles(0, clock * 2.4 + phase, 0))
			local age = clock - animation.Started
			if age < 0.45 then
				local progress = math.clamp(age / 0.45, 0, 1)
				local scale = progress < 0.75 and (progress / 0.75) * 1.12 or 1.12 - ((progress - 0.75) / 0.25) * 0.12
				model:ScaleTo(math.max(0.05, scale))
			end
		end
	end
	for model in pairs(coinAnimations) do
		if not liveCoins[model] then
			coinAnimations[model] = nil
		end
	end

	local liveDrones = {}
	for _, model in ipairs(CollectionService:GetTagged("AeroRushDrone")) do
		local root = model.PrimaryPart
		if model.Parent and root then
			liveDrones[model] = true
			if not droneAppearances[model] then
				droneAppearances[model] = true
				local light = root:FindFirstChildOfClass("PointLight")
				burstAt(root.Position, light and light.Color or COLORS.Cyan, 22)
			end
		end
	end
	for model in pairs(droneAppearances) do
		if not liveDrones[model] then
			droneAppearances[model] = nil
		end
	end

	for _, wing in ipairs(CollectionService:GetTagged("AeroRushWing")) do
		local model = wing:FindFirstAncestorOfClass("Model")
		local root = model and model.PrimaryPart
		if root and wing.Parent then
			local offset = Vector3.new(wing:GetAttribute("OffsetX") or 0, wing:GetAttribute("OffsetY") or 0, wing:GetAttribute("OffsetZ") or 0)
			local side = wing:GetAttribute("FlexSide") or 1
			local speed = model:GetAttribute("Speed") or 0
			local flex = side * (math.sin(clock * 7 + offset.Z) * 0.025 + math.min(0.12, speed * 0.0008))
			wing.CFrame = root.CFrame * CFrame.new(offset) * CFrame.Angles(0, wing:GetAttribute("BaseY") or 0, (wing:GetAttribute("BaseZ") or 0) + flex)
		end
	end
end

local rotorAngle = 0
local hudClock = 0
local function updateHUD(deltaTime, ownDrone)
	hudClock = hudClock + deltaTime
	if hudClock < 0.05 then
		return
	end
	hudClock = 0
	local phase = raceState:GetAttribute("Phase") or "Intermission"
	local racing = player:GetAttribute("Racing") == true
	local finished = player:GetAttribute("Finished") == true
	local now = Workspace:GetServerTimeNow()
	local remaining = math.max(0, math.ceil((raceState:GetAttribute("PhaseEndsAt") or now) - now))
	local queueCount = raceState:GetAttribute("Queued") or 0

	if phase == "Intermission" then
		phaseTitle.Text = "СВОБОДНОЕ ЛОББИ"
		phaseDetail.Text = queueCount > 0 and string.format("В очереди %d · старт через %d сек", queueCount, remaining) or "СТАРТ по кнопке · даже один пилот"
	elseif phase == "Countdown" then
		phaseTitle.Text = "ПИЛОТЫ НА СТАРТЕ"
		phaseDetail.Text = Config.TrackName
	elseif phase == "Racing" then
		phaseTitle.Text = "ЗАЕЗД В РЕАЛЬНОМ ВРЕМЕНИ"
		phaseDetail.Text = string.format("Осталось %02d:%02d", math.floor(remaining / 60), remaining % 60)
	else
		phaseTitle.Text = "ФИНИШ"
		phaseDetail.Text = string.format("Новый заезд через %d сек", remaining)
	end

	lobbyPanel.Visible = phase == "Intermission" and not racing and not helpOverlay.Visible and not resultsOverlay.Visible
	joinRaceButton.Text = player:GetAttribute("Queued") == true and "ВЫЙТИ ИЗ ОЧЕРЕДИ" or "В ОЧЕРЕДЬ"
	lobbyDetail.Text = queueCount > 0 and string.format("Очередь: %d · настройки доступны до старта", queueCount) or "Нет обязательного таймера · кейсы за монетки в арсенале"
	controlsHint.Visible = not UserInputService.TouchEnabled and not finished and (not racing or phase == "Racing") and not helpOverlay.Visible and not resultsOverlay.Visible
	if not racing then
		controlsLine1.Text = "WASD — ходьба · E — NPC · лавки слева"
		controlsLine2.Text = "Тюнинг и кейсы доступны до входа в гонку"
	else
		controlsLine1.Text = "WASD / Q E / SPACE CTRL — полёт · ЛКМ — BLASTER"
		controlsLine2.Text = "SHIFT — boost · F/G — гаджеты · R — reset"
	end

	local currentCamera = Workspace.CurrentCamera
	local compactFinished = finished and currentCamera and currentCamera.ViewportSize.Y < 620 or false
	raceStats.Visible = racing and phase ~= "Intermission" and not compactFinished
	speedPanel.Visible = racing and phase ~= "Intermission" and not finished
	resetButton.Visible = racing and phase == "Racing" and not finished
	healthPanel.Visible = racing and phase == "Racing" and not finished and not helpOverlay.Visible and not resultsOverlay.Visible
	gadgetPanel.Visible = racing and phase == "Racing" and not finished and not helpOverlay.Visible and not resultsOverlay.Visible
	countdown.Visible = phase == "Countdown"
	countdownSub.Visible = phase == "Countdown"
	if phase == "Countdown" then
		local value = raceState:GetAttribute("Countdown") or 0
		countdown.Text = value > 0 and tostring(value) or "ВПЕРЁД!"
		countdown.TextColor3 = value <= 1 and COLORS.Cyan or COLORS.White
		countdownSub.Text = "ДЕРЖИ КУРС НА ПЕРВЫЙ ГЕЙТ"
	end

	coinPanel.Visible = racing and phase == "Racing" and not finished and not helpOverlay.Visible and not resultsOverlay.Visible
	local raceCoins = player:GetAttribute("RaceCoins") or 0
	local combo = player:GetAttribute("CoinCombo") or 0
	local comboRemaining = math.clamp(((player:GetAttribute("CoinComboEndsAt") or 0) - now) / Config.Coins.ComboDuration, 0, 1)
	coinCount.Text = string.format("%d / %d МОНЕТ", raceCoins, Config.Coins.MaxPerRacer)
	comboLabel.Text = combo > 1 and string.format("СЕРИЯ ×%d · TECH + BOOST", combo) or "TECH + BOOST ЗА КАЖДУЮ"
	comboLabel.TextColor3 = combo >= 5 and COLORS.Yellow or COLORS.White
	comboBar.Size = UDim2.fromScale(combo > 0 and comboRemaining or 0, 1)
	coinStroke.Transparency = combo >= 5 and 0.08 or 0.5
	coinPulse = math.max(0, coinPulse - deltaTime * 4)
	coinScale.Scale = 1 + coinPulse * 0.12

	local boundaryWarning = ownDrone and (ownDrone:GetAttribute("BoundaryWarning") or 0) or 0
	boundaryFX.Visible = racing and phase == "Racing" and not finished and boundaryWarning > 0.02 and not helpOverlay.Visible and not resultsOverlay.Visible
	boundaryStroke.Transparency = 1 - boundaryWarning * 0.75
	boundaryText.TextTransparency = math.max(0, 1 - boundaryWarning * 1.8)

	local lap = player:GetAttribute("Lap") or 1
	local gate = player:GetAttribute("Gate") or 2
	lapLabel.Text = string.format("КРУГ %d / %d", math.max(1, lap), Config.Laps)
	gateLabel.Text = string.format("СЛЕДУЮЩИЙ ГЕЙТ %02d / %02d", gate, #Track.Gates)
	local elapsed = math.max(0, now - (raceState:GetAttribute("RaceStartAt") or now))
	if finished and (player:GetAttribute("FinishTime") or 0) > 0 then
		elapsed = player:GetAttribute("FinishTime")
	end
	if phase == "Racing" or phase == "PostRace" then
		timerLabel.Text = string.format("%02d:%06.3f", math.floor(elapsed / 60), elapsed % 60)
	else
		timerLabel.Text = "00:00.000"
	end
	bestLabel.Text = "ЛУЧШИЙ КРУГ  " .. Config.FormatTime(player:GetAttribute("RaceBestLap") or 0)

	local health = math.clamp(player:GetAttribute("DroneHealth") or 100, 0, 100)
	local shield = math.max(0, player:GetAttribute("DroneShield") or 0)
	healthBar.Size = UDim2.fromScale(health / 100, 1)
	healthBar.BackgroundColor3 = health <= 30 and COLORS.Pink or (health <= 60 and COLORS.Yellow or COLORS.Cyan)
	healthText.Text = tostring(math.ceil(health))
	shieldLabel.Text = shield > 0 and ("ЩИТ " .. math.ceil(shield)) or ""
	local attack = Gadgets.Get(player:GetAttribute("SelectedAttack")) or Gadgets.Get("PulseLaser")
	local defense = Gadgets.Get(player:GetAttribute("SelectedDefense")) or Gadgets.Get("RepairPulse")
	local attackCooldown = math.max(0, player:GetAttribute("AttackCooldown") or 0)
	local defenseCooldown = math.max(0, player:GetAttribute("DefenseCooldown") or 0)
	local blasterCooldown = math.max(0, player:GetAttribute("BlasterCooldown") or 0)
	local blasterKey = UserInputService.TouchEnabled and "ОГОНЬ" or "ЛКМ"
	blasterButton.Text = blasterCooldown > 0.05 and string.format("%s · %.1f С", blasterKey, blasterCooldown) or (blasterKey .. " · BLASTER")
	blasterButton.TextColor3 = blasterCooldown > 0.05 and COLORS.Muted or COLORS.White
	local attackKey = UserInputService.TouchEnabled and "АТАКА" or "F"
	local defenseKey = UserInputService.TouchEnabled and "ЗАЩИТА" or "G"
	attackButton.Text = attackCooldown > 0.05 and string.format("%s · %.1f С", attackKey, attackCooldown) or (attackKey .. " · " .. attack.Name)
	defenseButton.Text = defenseCooldown > 0.05 and string.format("%s · %.1f С", defenseKey, defenseCooldown) or (defenseKey .. " · " .. defense.Name)
	attackButton.TextColor3 = attack.Color
	defenseButton.TextColor3 = defense.Color

	if ownDrone then
		local speed = ownDrone:GetAttribute("Speed") or 0
		local boost = ownDrone:GetAttribute("Boost") or 0
		speedValue.Text = tostring(math.floor(speed * 1.2 + 0.5))
		local boostCapacity = ownDrone:GetAttribute("BoostCapacity") or Config.Drone.BoostCapacity
		boostBar.Size = UDim2.fromScale(math.clamp(boost / boostCapacity, 0, 1), 1)
		boostNumber.Text = string.format("%d/%d", math.floor(boost + 0.5), math.floor(boostCapacity + 0.5))
		boostBar.BackgroundColor3 = boost < 25 and COLORS.Pink or COLORS.Cyan
		if highlightedGate and highlightedGate.PrimaryPart then
			distanceLabel.Text = string.format("ДО ЦЕЛИ  %d М", math.floor((ownDrone.PrimaryPart.Position - highlightedGate.PrimaryPart.Position).Magnitude + 0.5))
		else
			distanceLabel.Text = ""
		end
	end

	navigationPanel.Visible = racing and phase == "Racing" and not finished and ownDrone ~= nil and highlightedGate ~= nil and highlightedGate.PrimaryPart ~= nil and not helpOverlay.Visible and not resultsOverlay.Visible
	if navigationPanel.Visible then
		local root = ownDrone.PrimaryPart
		local target = highlightedGate.PrimaryPart.Position
		local object = root.CFrame:PointToObjectSpace(target)
		local bearing = math.atan2(object.X, -object.Z)
		local distance = (target - root.Position).Magnitude
		navigationArrow.Rotation = math.deg(bearing)
		navigationTitle.Text = string.format("ГЕЙТ %02d / %02d", gate, #Track.Gates)
		local direction = "ВПЕРЁД"
		if math.abs(bearing) > 2.35 then
			direction = "РАЗВОРОТ"
		elseif bearing > 0.35 then
			direction = "ВПРАВО"
		elseif bearing < -0.35 then
			direction = "ВЛЕВО"
		end
		local vertical = object.Y > 7 and " · ВВЕРХ" or (object.Y < -7 and " · ВНИЗ" or "")
		local guardAt = ownDrone:GetAttribute("GateGuardAt") or 0
		local guarded = guardAt > 0 and Workspace:GetServerTimeNow() - guardAt < 1.2
		navigationDetail.Text = guarded and "ВОЗВРАТ КО ВХОДУ В ГЕЙТ" or string.format("%d М · %s%s", math.floor(distance + 0.5), direction, vertical)
		navigationDetail.TextColor3 = guarded and COLORS.Pink or COLORS.Muted
		navigationStroke.Color = guarded and COLORS.Pink or COLORS.Yellow
	end

	if phase == "PostRace" then
		local summary = ownResultSummary ~= "" and ownResultSummary or Config.TrackName
		resultsSubtitle.Text = string.format("%s · реванш через %d сек", summary, remaining)
	end
	touchControls.Visible = UserInputService.TouchEnabled and racing and phase == "Racing" and not finished and not helpOverlay.Visible and not resultsOverlay.Visible
end

RunService.RenderStepped:Connect(function(deltaTime)
	local ownDrone = getOwnDrone()
	sendInput(deltaTime)
	updateCamera(deltaTime, ownDrone)
	updateTargetHighlight()
	updateMusic(deltaTime)
	animateWorldModels()
	local currentSpeed = ownDrone and ownDrone:GetAttribute("Speed") or 0
	local showSpeedFX = currentSpeed > 112 and player:GetAttribute("Racing") == true and not player:GetAttribute("Finished")
	speedFX.Visible = showSpeedFX
	if showSpeedFX then
		local clock = os.clock()
		for _, streak in ipairs(speedStreaks) do
			local phase = (clock * streak.Rate + streak.Offset) % 1.15 - 0.075
			streak.Frame.Position = UDim2.fromScale(streak.X, phase)
			streak.Frame.BackgroundTransparency = 0.45 + math.clamp(phase, 0, 1) * 0.35
		end
	end
	updateHUD(deltaTime, ownDrone)

	rotorAngle = rotorAngle + deltaTime * 34
	for _, blade in ipairs(CollectionService:GetTagged("AeroRushRotor")) do
		local model = blade:FindFirstAncestorOfClass("Model")
		local root = model and model.PrimaryPart
		if root and blade.Parent then
			local offset = Vector3.new(blade:GetAttribute("OffsetX") or 0, blade:GetAttribute("OffsetY") or 0, blade:GetAttribute("OffsetZ") or 0)
			local direction = (blade:GetAttribute("RotorIndex") or 0) % 2 == 0 and -1 or 1
			blade.CFrame = root.CFrame * CFrame.new(offset) * CFrame.Angles(0, rotorAngle * direction, 0)
		end
	end
end)
