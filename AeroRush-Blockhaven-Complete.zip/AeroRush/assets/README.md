# Релизные материалы

- `Icon.png` — квадратная voxel-иконка 512×512 для Roblox Creator Dashboard.
- `Thumbnail.png` — обложка Blockhaven 1920×1080 для страницы опыта.
- `AeroRushKeyArt.png` — исходная voxel-иллюстрация 1376×768 без названия игры.
- `music/AeroRush_Lobby_SkywayAfterglow.wav` — оригинальный loop лобби, 38,4 с.
- `music/AeroRush_Race_NeonSlipstream.wav` — оригинальный loop заезда, 51,2 с.
- `music/generate_music.py` и `music/manifest.json` — исходник синтеза, параметры и контрольные SHA-256.

Внутриигровая графика не загружает эти изображения как текстуры: `Thumbnail.png` и `AeroRushKeyArt.png` используются как визуальный референс. Процедурные модели повторяют сине-оранжевый деревянный дрон с квадратными роторами, каменные арки с золотыми номерами, полосатые лавки, многослойные острова, заборы, деревья, горы и облака.

Музыку нужно загрузить в Roblox как два Audio assets и вписать их ID в `Config.Music`; подробная инструкция находится в корневом `README.md`.
